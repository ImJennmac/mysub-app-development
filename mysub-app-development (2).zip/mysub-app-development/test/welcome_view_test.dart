// import 'package:flutter/material.dart';
// import 'package:flutter_test/flutter_test.dart';
// import 'package:mysub/ui/view/login_view.dart';
// import 'package:mysub/ui/view/registration/registration_view.dart';
// import 'package:mysub/ui/view/welcome_view.dart';

// /// This file contains Unit Tests of the Welcome View.
// /// More specifically, we test that the correct widgets
// /// are rendered and the user can navigate to the Login
// /// and Registration View Correctly.
// ///
// /// A fake route is used for mocking the navigation, since
// /// this is just an Unit Test.
// void main() {
//   // Fixes RenderFlex overflowed issue.
//   // See https://github.com/aleksanderwozniak/table_calendar/issues/38
//   final TestWidgetsFlutterBinding binding = TestWidgetsFlutterBinding.ensureInitialized();
//   const Size SURFACE_SIZE = Size(860, 860);
//   testWidgets("Welcome View can navigate to Login View", (WidgetTester tester) async {
//     // This has to be done in test.
//     await binding.setSurfaceSize(SURFACE_SIZE);
//     // Button that will navigate to the login view
//     final Finder logInNavButton = find.byKey(WelcomeView.LOG_IN_BUTTON_KEY);
//     // Render View
//     await tester.pumpWidget(
//       MaterialApp(
//         home: const WelcomeView(),
//         onGenerateRoute: (RouteSettings settings) {
//           if (settings.name == LoginView.id) {
//             return MaterialPageRoute<Text>(builder: (_) => const Text("Login View"));
//           } else {
//             throw ("You cannot go to ${settings.name} from the Welcome View. This is a bug");
//           }
//         },
//       ),
//     );
//     // First we check that the buttons exists
//     expect(logInNavButton, findsOneWidget);
//     // Navigate to the Login View
//     await tester.tap(logInNavButton);
//     await tester.pumpAndSettle(); // Await tap animation
//     // After we tapped log in and we navigate to log in
//     // this button should no longer exist.
//     expect(logInNavButton, findsNothing);
//     // This is the text from the login view
//     expect(find.textContaining("Login View"), findsOneWidget);
//   });

//   testWidgets("Welcome View can navigate to Registration View", (WidgetTester tester) async {
//     // This has to be done in test.
//     await binding.setSurfaceSize(SURFACE_SIZE);
//     // Button that will navigate to the registration view
//     final Finder signUpButton = find.byKey(WelcomeView.SIGN_UP_BUTTON_KEY);
//     // Render View
//     await tester.pumpWidget(
//       MaterialApp(
//         home: const WelcomeView(),
//         onGenerateRoute: (RouteSettings settings) {
//           if (settings.name == RegistrationView.id) {
//             return MaterialPageRoute<Text>(builder: (_) => const Text("Registration View"));
//           } else {
//             throw ("You cannot go to ${settings.name} from the Welcome View. This is a bug");
//           }
//         },
//       ),
//     );
//     await tester.pumpAndSettle();
//     // First we check that the buttons exists
//     expect(signUpButton, findsOneWidget);
//     // Navigate to the Registration View
//     await tester.tap(signUpButton);
//     await tester.pumpAndSettle(); // Await tap animation
//     // After we tapped log in and we navigate to log in
//     // this button should no longer exist.
//     expect(signUpButton, findsNothing);
//     // This is the text from the login view
//     expect(find.textContaining("Registration View"), findsOneWidget);
//   });
// }

void main() {}

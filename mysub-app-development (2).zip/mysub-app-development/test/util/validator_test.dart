// All Rights Reserved (ARR)
// Copyright (c) 2022 NotSuitable Group LTD
// Created with love by the team at NSG.

// This file is used for testing input validation.
import 'package:flutter_test/flutter_test.dart';
import 'package:mysub/common/util/validator.dart';
//import 'package:mysub/config.dart';

void main() {
  //final AppConfig config = AppConfig(EnvType.TESTING);
  // This group will check empty inputs.
  group("Input not empty", () {
    // Given input is not empty, success.
    test("The validator outputs null if the text is not empty", () {
      expect(Validator.validateNotEmpty("Example"), isNull);
    });
    // Given input is empty, a message will be returned.
    test("The validator outputs a message if the text is empty", () {
      expect(Validator.validateNotEmpty(""), isA<String>());
    });

    // This test will check that the given email is a valid one.
    test("Valid Email", () {
      expect(Validator.validateEmail(""), isA<String>());
      expect(Validator.validateEmail("example@gmail.com"), isNull);
      expect(Validator.validateEmail("myemail.com"), isA<String>());
    });
    // This test will check that the given password is a valid one.
    // With a valid password we mean:
    // - A password with at least 8 characters
    // - A password with at least 1 number
    // - A password with a special character
    // - A password with box uppercase and lowercase letters.
    test("Valid Password", () {
      // Not only numbers
      expect(Validator.validatePassword("12345678"), isA<String>());
      // Not only letters
      expect(Validator.validatePassword("abcdefgh"), isA<String>());
      // No empty spaces
      expect(Validator.validatePassword("        "), isA<String>());
      // This will fail because its missing the special character.
      expect(Validator.validatePassword("thisIsApw123"), isA<String>());
      // Meets all the requirements.
      expect(Validator.validatePassword("@thisIsApw123"), isNull);
    });

    // This test will assert that the passwords comparison are working.
    test("Passwords Match", () {
      // Success, both passwords are equal.
      expect(Validator.doPasswordsMatch("123", "123"), isNull);
      // Fails, there is an input mismatch.
      expect(Validator.doPasswordsMatch("@pw123", "pw123"), isA<String>());
    });
    test("Valid name and username", () {
      // Only letters allowed for real name
      expect(Validator.validateRealName("Marcos"), isNull);
      expect(Validator.validateRealName("Marcos1"), isA<String>());
      expect(Validator.validateUsername("Daniking123"), isNull);
      // Minimum allowed length is 4
      expect(Validator.validateUsername("abc"), isA<String>());
    });
  });
}

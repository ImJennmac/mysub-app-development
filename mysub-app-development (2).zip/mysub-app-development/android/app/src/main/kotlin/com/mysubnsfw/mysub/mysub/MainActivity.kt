package com.mysubnsfw.mysub.mysub

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

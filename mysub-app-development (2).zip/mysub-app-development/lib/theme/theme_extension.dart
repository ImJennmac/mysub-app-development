import 'package:flutter/material.dart';

class CustomThemeExtension extends ThemeExtension<CustomThemeExtension> {
  final Color? cardColorDarker;

  const CustomThemeExtension({
    required this.cardColorDarker,
  });

  @override
  ThemeExtension<CustomThemeExtension> copyWith({
    Color? cardColorDarker,
  }) {
    return CustomThemeExtension(
      cardColorDarker: cardColorDarker ?? this.cardColorDarker,
    );
  }

  @override
  ThemeExtension<CustomThemeExtension> lerp(
      ThemeExtension<CustomThemeExtension>? other,
      double t,
      ) {
    if (other is! CustomThemeExtension) {
      return this;
    }
    return CustomThemeExtension(
      cardColorDarker: Color.lerp(cardColorDarker, other.cardColorDarker, t),
    );
  }
}

extension ColorExtension on Color {
  Color darken([double amount = .1]) {
    assert(amount >= 0 && amount <= 1);

    final hsl = HSLColor.fromColor(this);
    final hslDark = hsl.withLightness((hsl.lightness - amount).clamp(0.0, 1.0));

    return hslDark.toColor();
  }
}

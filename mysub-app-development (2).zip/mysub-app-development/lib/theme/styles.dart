import 'package:flutter/material.dart';
import 'package:mysub/theme/colors.dart';

const TextStyle kHeadline1 = TextStyle(
  fontSize: 28,
  fontWeight: FontWeight.bold,
);

const TextStyle kHeadline2 = TextStyle(
  fontSize: 24,
  color: kDarkColor,
  fontWeight: FontWeight.bold,
);

const TextStyle kHeadline3 = TextStyle(
  fontSize: 22,
  color: kDarkColor,
  fontWeight: FontWeight.bold,
);

const TextStyle kSubtitle1 = TextStyle(
  fontSize: 20,
);

const TextStyle kSubtitle2 = TextStyle(
  fontSize: 18,
);

const TextStyle kSubtitle3 = TextStyle(
  fontSize: 16,
);

const TextStyle kBody1 = TextStyle(
  fontSize: 18,
);

const TextStyle kBody2 = TextStyle(
  fontSize: 16,
);

const TextStyle kBody3 = TextStyle(
  fontSize: 14,
);

final ButtonStyle kPrimaryTextButton = TextButton.styleFrom(
  backgroundColor: kPrimaryColor,
  foregroundColor: Colors.white,
  padding: const EdgeInsets.symmetric(vertical: 12),
  shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(5.0),
  ),
);

final ButtonStyle kPrimaryOutlinedButton = OutlinedButton.styleFrom(
  padding: const EdgeInsets.symmetric(vertical: 12),
  foregroundColor: kPrimaryColor,
  side: const BorderSide(
    color: kPrimaryColor,
  ),
  textStyle: kSubtitle1,
  shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(5.0),
  ),
);

const TextStyle kHintTextStyle = TextStyle(
  fontSize: 16,
  color: Colors.grey,
  fontStyle: FontStyle.italic,
);

const InputDecorationTheme kPrimaryInputTheme = InputDecorationTheme(
  enabledBorder: OutlineInputBorder(
    borderSide: BorderSide(color: kDarkColor),
    borderRadius: BorderRadius.all(Radius.circular(8)),
  ),
  focusedBorder: OutlineInputBorder(
    borderSide: BorderSide(color: kPrimaryColor, width: 2),
    borderRadius: BorderRadius.all(Radius.circular(8)),
  ),
  errorBorder: OutlineInputBorder(
    borderSide: BorderSide(color: kDangerColor),
    borderRadius: BorderRadius.all(Radius.circular(8)),
  ),
  focusedErrorBorder: OutlineInputBorder(
    borderSide: BorderSide(color: kDangerColor, width: 2),
    borderRadius: BorderRadius.all(Radius.circular(8)),
  ),
  hintStyle: kHintTextStyle,
  contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
);

InputDecorationTheme kPrimaryInputThemeDark = InputDecorationTheme(
  enabledBorder: const OutlineInputBorder(
    borderSide: BorderSide(color: backgroundLight),
    borderRadius: BorderRadius.all(Radius.circular(8)),
  ),
  focusedBorder: const OutlineInputBorder(
    borderSide: BorderSide(color: kPrimaryColorDark, width: 2),
    borderRadius: BorderRadius.all(Radius.circular(8)),
  ),
  errorBorder: const OutlineInputBorder(
    borderSide: BorderSide(color: kDangerColor),
    borderRadius: BorderRadius.all(Radius.circular(8)),
  ),
  focusedErrorBorder: const OutlineInputBorder(
    borderSide: BorderSide(color: kDangerColor, width: 2),
    borderRadius: BorderRadius.all(Radius.circular(8)),
  ),
  hintStyle: TextStyle(
    fontSize: 16,
    color: Colors.grey[400],
    fontStyle: FontStyle.italic,
  ),
  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
);

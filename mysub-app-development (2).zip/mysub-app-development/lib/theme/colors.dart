import 'package:flutter/animation.dart';

// Light Theme Colours
const Color backgroundLight = Color(0xFFFFFFFF);
const Color kPrimaryColor = Color.fromRGBO(236, 25, 66, 1.0);
const Color kPrimaryLighter = Color.fromARGB(255, 248, 81, 113);
const Color kSelectedButtonColor = Color.fromRGBO(199, 23, 57, 1.0);

const Color navBarLight = Color.fromRGBO(243, 240, 242, 1.0);

// Dark Theme Colours
const Color backgroundDark = Color(0xFF121212);
const Color kPrimaryColorDark = Color.fromRGBO(236, 25, 66, 1.0);
const Color kPrimaryLighterDark = Color.fromARGB(255, 248, 81, 113);
const Color kSelectedButtonColorDark = Color.fromRGBO(199, 23, 57, 1.0);

const Color navBarDark = Color(0xFF151515);

// Other Colours
const Color kDangerColor = Color(0xFFDD5353);
const Color kDarkColor = Color.fromRGBO(25, 25, 34, 1.0);

// Button Colours
const Color boxGray = Color(0xFFF3F0F2);
const Color arrowGray = Color(0xFFDEDEDE);

// New container background colors
const Color containerBackgroundLight = Color(0xFFF3F0F2);
const Color containerBackgroundDark = Color(0xFF1E1E1E);
const Color containerBackgroundLighter = Color(0xFFE5E5E5);
const Color containerBackgroundDarker = Color(0xFF151515);



// Subtext Colours
const Color subtextLight = Color(0xFF151515);
const Color subtextDark = Color(0xFFDEDEDE);

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class ThemeNotifier extends StateNotifier<ThemeMode> {
  ThemeNotifier() : super(ThemeMode.system);

  ThemeMode get theme => state;

  set theme(ThemeMode themeMode) {
    state = themeMode;
  }

  void toggleTheme() {
    state = state == ThemeMode.system
        ? ThemeMode.light
        : state == ThemeMode.light
        ? ThemeMode.dark
        : ThemeMode.system;
  }
}

final themeProvider = StateNotifierProvider<ThemeNotifier, ThemeMode>((ref) {
  return ThemeNotifier();
});

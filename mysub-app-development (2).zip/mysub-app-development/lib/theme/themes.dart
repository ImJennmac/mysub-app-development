import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mysub/theme/colors.dart';
import 'package:mysub/theme/styles.dart';
import 'package:mysub/theme/theme_extension.dart';

// DO NOT override textButtonTheme here as it will change other native
// buttons as well (such as select text menu). Instead pass in the kPrimaryTextButton
// for each button that you might want with that style.
// textButtonTheme: TextButtonThemeData(
//   style: kPrimaryTextButton,
// ),

final lightTheme = ThemeData(
  fontFamily: GoogleFonts.inter().fontFamily,
  primaryColor: kPrimaryColor,
  scaffoldBackgroundColor: backgroundLight,
  cardColor: containerBackgroundLight,
  iconTheme: const IconThemeData(color: kDarkColor),
  colorScheme: const ColorScheme.light(
    primary: kPrimaryColor,
    secondary: kPrimaryColor,
    surface: containerBackgroundLight,
    error: kPrimaryColor,
    onPrimary: Colors.black,
    onSurface: kDarkColor,
  ),
  textTheme: TextTheme(
    displayLarge: kSubtitle1.copyWith(color: kDarkColor),
    displayMedium: kSubtitle2.copyWith(color: kDarkColor),
    displaySmall: kSubtitle3.copyWith(color: kDarkColor),
    titleLarge: kHeadline1.copyWith(color: kDarkColor),
    titleMedium: kHeadline2.copyWith(color: kDarkColor),
    titleSmall: kHeadline3.copyWith(color: kDarkColor),
    bodyMedium: kBody2.copyWith(color: kDarkColor),
    bodySmall: kBody3.copyWith(color: kDarkColor),
    bodyLarge: kBody1.copyWith(color: kDarkColor),
    headlineLarge:kBody1.copyWith(color: kDarkColor),
    headlineMedium: kBody1.copyWith(color: kDarkColor),
    headlineSmall: kBody1.copyWith(color: kDarkColor),
  ),
  bottomNavigationBarTheme: const BottomNavigationBarThemeData(
    backgroundColor: navBarLight,
    selectedItemColor: Colors.black,
    unselectedItemColor: Colors.black,
  ),
  outlinedButtonTheme: OutlinedButtonThemeData(
    style: kPrimaryOutlinedButton,
  ),
  inputDecorationTheme: kPrimaryInputTheme,
  appBarTheme: const AppBarTheme(color: kPrimaryColor, elevation: 2.0, centerTitle: true),
  textSelectionTheme: TextSelectionThemeData(
    cursorColor: kPrimaryColor,
    selectionHandleColor: kPrimaryColor,
    selectionColor: kPrimaryColor.withOpacity(0.65),
  ),
  extensions: const [
    CustomThemeExtension(
      cardColorDarker: containerBackgroundLighter,
    ),
  ],
);

final darkTheme = ThemeData(
  fontFamily: GoogleFonts.inter().fontFamily,
  primaryColor: kPrimaryColorDark,
  scaffoldBackgroundColor: backgroundDark,
  cardColor: containerBackgroundDark,
  iconTheme: const IconThemeData(color: backgroundLight),
  colorScheme: const ColorScheme.dark(
    primary: kPrimaryColorDark,
    secondary: kPrimaryColorDark,
    surface: containerBackgroundDark,
    error: kPrimaryColor,
    onPrimary: Colors.white,
    onError: Colors.white,
  ),
  bottomNavigationBarTheme: const BottomNavigationBarThemeData(
    backgroundColor: navBarDark,
    selectedItemColor: Colors.white,
    unselectedItemColor: Colors.white,
  ),
  textTheme: TextTheme(
    displayLarge: kSubtitle1.copyWith(color: backgroundLight),
    displayMedium: kSubtitle2.copyWith(color: backgroundLight),
    displaySmall: kSubtitle3.copyWith(color: backgroundLight),
    titleLarge: kHeadline1.copyWith(color: backgroundLight),
    titleMedium: kHeadline2.copyWith(color: backgroundLight),
    titleSmall: kHeadline3.copyWith(color: backgroundLight),
    bodyMedium: kBody2.copyWith(color: subtextDark),
    bodySmall: kBody3.copyWith(color: subtextDark),
    bodyLarge: kBody1.copyWith(color: subtextDark),
  ),
  outlinedButtonTheme: OutlinedButtonThemeData(
    style: kPrimaryOutlinedButton,
  ),
  inputDecorationTheme: kPrimaryInputThemeDark,
  appBarTheme: const AppBarTheme(color: kPrimaryColorDark, elevation: 2.0, centerTitle: true),
  textSelectionTheme: TextSelectionThemeData(
    cursorColor: kPrimaryColorDark,
    selectionHandleColor: kPrimaryColorDark,
    selectionColor: kPrimaryColorDark.withOpacity(0.65),
  ),
  extensions: const [
    CustomThemeExtension(
      cardColorDarker: containerBackgroundDarker,
    ),
  ],
);

import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:logger/logger.dart';
import 'package:mysub/common/util/logger/logger.dart';
import 'package:mysub/common/util/logger/provider_logger.dart';
import 'package:mysub/config.dart';
import 'package:mysub/mysub.dart';

final Logger logger = MySubLogger.getLogger('init');

Future<void> run(EnvType env) async {
  await dotenv.load();
  final appEnvironment = AppConfig(env);
  logger
      .i("Initializing MySub in ${appEnvironment.env.name.toLowerCase()} mode");
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    name: "mysubProdApp",
    options: AppConfig.firebaseSettings,
  );

  FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);

  await SystemChrome.setPreferredOrientations(
    <DeviceOrientation>[
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ],
  );

  runApp(
    ProviderScope(
      observers: [ProviderLogger()],
      child: const MySub(),
    ),
  );
}

@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  print(message.notification!.title.toString());
  print(message.notification!.body.toString());

  AwesomeNotifications().createNotificationFromJsonData(message.data);
}

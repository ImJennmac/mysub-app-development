import 'package:mysub/config.dart';
import 'package:mysub/init/init.dart';

void main(List<String> args) {
  run(EnvType.DEVELOPMENT);
}

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fpdart/fpdart.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/identifier.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/extensions.dart';
import 'package:mysub/common/util/helpers.dart';
import 'package:mysub/common/util/types.dart';
import 'package:mysub/features/auth/views/email_verification_view.dart';
import 'package:mysub/features/homepage/home/home_view.dart';
import 'package:mysub/features/landing/landing_view.dart';
import 'package:mysub/repositories/impl/auth_repository.dart';
import 'package:mysub/repositories/impl/user_repository.dart';

final initProvider = FutureProvider.family<OptionalUser, Identifier>((ref, tuple) async {
  final optionalUser = await ref.watch(userRepositoryProvider).read(tuple);
  return optionalUser.match(
    (err) => const Option.none(),
    (userModel) {
      final user = Option.of(userModel);
      ref.watch(userProvider.notifier).state = user;
      return user;
    },
  );
});

class StartUp extends ConsumerWidget {
  const StartUp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AsyncValue<Option<User>> authState = ref.watch(authStateChangesProvider);
    // This will run when the auth state changes.
    return authState.when(
      data: (optionalUser) => optionalUser.match(
        () => const LandingView(),
        (user) {
          final init = ref.watch(initProvider(user.toIdentifier()));
          
          if (!user.emailVerified) {
            return const EmailVerificationView();
          }
          return init.when(
            data: (model) {
              if (model.isNone()) {
                return const LandingView();
              }
              return const HomeView();
            },
            error: displayError,
            loading: () => buildLoadingPage(),
          );
        },
      ),
      error: displayError,
      loading: () => buildLoadingPage(),
    );
  }

  Widget displayError(Object error, StackTrace stackTrace) {
    return Scaffold(
      body: Center(
        child: Text(error.toString()),
      ),
    );
  }
}

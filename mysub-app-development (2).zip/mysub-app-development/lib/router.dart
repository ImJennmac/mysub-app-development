import 'package:flutter/material.dart';
import 'package:mysub/common/util/logger/logger.dart';
import 'package:mysub/features/auth/views/email_verification_view.dart';
import 'package:mysub/features/auth/views/login_view.dart';
import 'package:mysub/features/auth/views/recovery_view.dart';
import 'package:mysub/features/auth/views/signup_view.dart';
import 'package:mysub/features/explore/habits/habits_view.dart';
import 'package:mysub/features/explore/habits/pages/habits_history.dart';
import 'package:mysub/features/explore/notes/noteshome_view.dart';
import 'package:mysub/features/explore/notes/pages/limits_view.dart';
import 'package:mysub/features/explore/notes/pages/notes_view.dart';
import 'package:mysub/features/explore/notes/pages/rules_view.dart';
import 'package:mysub/features/explore/punishments/pages/all_punishment_history.dart';
import 'package:mysub/features/explore/punishments/punishments_view.dart';
import 'package:mysub/features/explore/rewards/pages/reward_history.dart';
import 'package:mysub/features/explore/rewards/rewards_view.dart';
import 'package:mysub/features/homepage/home/home_view.dart';
import 'package:mysub/features/homepage/profile/profile_view.dart';
import 'package:mysub/features/homepage/settings/pages/account-delete/account_delete_page.dart';
import 'package:mysub/features/homepage/settings/pages/premium/plan_selector.dart';
import 'package:mysub/features/homepage/settings/pages/premium/premium.dart';
import 'package:mysub/features/homepage/settings/pages/support.dart';
import 'package:mysub/features/homepage/settings/pages/user-account/account_settings_page.dart';
import 'package:mysub/features/homepage/settings/pages/user-account/password_settings_page.dart';
import 'package:mysub/features/homepage/settings/pages/user-settings/change_theme.dart';
import 'package:mysub/features/homepage/settings/pages/user-settings/discreet_mode.dart';
import 'package:mysub/features/homepage/settings/pages/user-settings/notifications.dart';
import 'package:mysub/features/homepage/settings/pages/user-settings/passcode.dart';
import 'package:mysub/features/homepage/settings/settings_view.dart';
import 'package:mysub/features/landing/landing_view.dart';
import 'package:mysub/features/partners/pages/partner_page.dart';
import 'package:mysub/features/partners/pages/sent_requests.dart';

Route<dynamic> generateRoutes(RouteSettings settings) {
  MySubLogger.getLogger('router').d('Navigating to route: ${settings.name}');
  switch (settings.name) {
    case "/":
    case LandingView.id:
      return _createRoute(const LandingView());
    case LoginView.id:
      return _createRoute(const LoginView());
    case SignUpView.id:
      return _createRoute(const SignUpView());
    case HomeView.id:
      return _createRoute(const HomeView());
    case RecoveryView.id:
      final email = settings.arguments! as String;
      return _createRoute(RecoveryView(email));
    case EmailVerificationView.id:
      return _createRoute(const EmailVerificationView());
    case SettingsView.id:
      return _createRoute(const SettingsView());
    case AccountSettingsPage.id:
      return _createRoute(const AccountSettingsPage());
    case PasswordSettingsPage.id:
      return _createRoute(const PasswordSettingsPage());
    case DeleteAccountPage.id:
      return _createRoute(const DeleteAccountPage());
    case PunishmentsView.id:
      return _createRoute(const PunishmentsView());
    case HabitsView.id:
      return _createRoute(const HabitsView());
    case NotesHomeView.id:
      return _createRoute(const NotesHomeView());
    case RulesView.id:
      return _createRoute(const RulesView());
    case NotesView.id:
      return _createRoute(const NotesView());
    case LimitsView.id:
      return _createRoute(const LimitsView());
    case RewardsView.id:
      return _createRoute(const RewardsView());
    case ProfileView.id:
      return _createRoute(const ProfileView());
    case PartnerPage.id:
      final onPartnerSelected = settings.arguments! as Future<void> Function(String);
      return _createRoute(PartnerPage(onPartnerSelected: onPartnerSelected));
    case RewardsHistory.id:
      return _createRoute(const RewardsHistory());
    case PunishmentHistory.id:
      return _createRoute(const PunishmentHistory());
    case SentRequestsPage.id:
      return _createRoute(const SentRequestsPage());
    case SupportPage.id:
      return _createRoute(const SupportPage());
    case PremiumPage.id:
      return _createRoute(const PremiumPage());
    case PremiumPlanPage.id:
      return _createRoute(const PremiumPlanPage());
    case ChangeThemePage.id:
      return _createRoute(const ChangeThemePage());
    case PasscodePage.id:
      return _createRoute(const PasscodePage());
    case NotificationsPage.id:
      return _createRoute(const NotificationsPage());
    case DiscreetModePage.id:
      return _createRoute(const DiscreetModePage());
    case HabitsHistory.id:
      return _createRoute(const HabitsHistory());
    default:
      return _createRoute(
        const Scaffold(
          body: Center(
            child: Text("No view has been defined for this route"),
          ),
        ),
      );
  }
}

Route<Widget> _createRoute(
    Widget child,
    ) {
  return MaterialPageRoute<Widget>(
    builder: (_) => child,
  );
}

// All Rights Reserved (ARR)
// Copyright (c) 2024 NotSuitable Group LTD
// Created with love by the team at NSG.

class HabitsModel {
  String id;
  String title;
  String description;
  String amount;
  String frequency;
  String timeCompletion;
  String pointsGain;
  String pointsLost;


  HabitsModel({
    required this.id,
    required this.title,
    required this.description,
    required this.amount,
    required this.frequency,
    required this.timeCompletion,
    required this.pointsGain,
    required this.pointsLost,
  });
}

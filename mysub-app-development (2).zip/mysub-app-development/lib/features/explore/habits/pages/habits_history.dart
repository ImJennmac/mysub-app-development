import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/button/backarrow.dart';
import 'package:mysub/common/util/navbar/navbar.dart';

class HabitsHistory extends ConsumerStatefulWidget {
  static const String id = "habitshistory";
  const HabitsHistory({super.key});

  @override
  ConsumerState<HabitsHistory> createState() => _HabitsHistoryState();
}

class _HabitsHistoryState extends ConsumerState<HabitsHistory> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final optionalUser = ref.watch(userProvider);
    final theme = Theme.of(context);

    return optionalUser.match(
          () => const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      ),
          (user) {
        return Scaffold(
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const BackArrow(),
                      Expanded(
                        child: Center(
                          child: Text(
                            "Habits History",
                            style: theme.textTheme.titleMedium,
                          ),
                        ),
                      ),
                      const SizedBox(width: 48),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Text(
                    "Here is your Habits History!",
                    style: theme.textTheme.displayMedium,
                  ),
                ],
              ),
            ),
          ),
          bottomNavigationBar: const NavBar(),
        );
      },
    );
  }
}

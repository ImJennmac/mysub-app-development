import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/button/homebutton.dart';
import 'package:mysub/common/util/button/plusbutton.dart';
import 'package:mysub/common/util/navbar/navbar.dart';
import 'package:mysub/features/explore/habits/model/habits_model.dart';
import 'package:mysub/features/explore/habits/pages/habits_history.dart';
import 'package:mysub/features/explore/habits/widgets/habit_screen.dart';
import 'package:mysub/features/explore/habits/widgets/habits_card.dart';

class HabitsView extends ConsumerStatefulWidget {
  static const String id = "habitsview";
  const HabitsView({super.key});

  @override
  ConsumerState<HabitsView> createState() => _HabitsViewState();
}

class _HabitsViewState extends ConsumerState<HabitsView> {
  @override
  Widget build(BuildContext context) {
    final optionalUser = ref.watch(userProvider);
    final theme = Theme.of(context);

    return optionalUser.match(
          () => const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      ),
          (user) {
        final CollectionReference myHabits = FirebaseFirestore.instance.collection('users/${user.uid}/habits');

        return Scaffold(
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const HomeButton(),
                      Text(
                        "Habits",
                        style: theme.textTheme.displayLarge,
                      ),
                      PlusButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => HabitScreen(
                                habit: HabitsModel(
                                  id: '',
                                  title: '',
                                  description: '',
                                  amount: '',
                                  frequency: '',
                                  timeCompletion: '',
                                  pointsGain: '',
                                  pointsLost: '',
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  buildHistoryBox(context, theme),
                  const SizedBox(height: 20),
                  Expanded(
                    child: StreamBuilder<QuerySnapshot>(
                      stream: myHabits.snapshots(),
                      builder: (context, snapshot) {
                        if (!snapshot.hasData) {
                          return const Center(
                            child: CircularProgressIndicator(),
                          );
                        }
                        final habits = snapshot.data!.docs;
                        return buildHabitsBox(context, theme, habits); // Habits box
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
          bottomNavigationBar: const NavBar(),
        );
      },
    );
  }

  Widget buildHistoryBox(BuildContext context, ThemeData theme) {
    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(context, HabitsHistory.id);
      },
      child: Container(
        width: double.infinity,
        height: 70,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15.0),
          color: theme.cardColor,
        ),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Stack(
            children: [
              Align(
                alignment: Alignment.topLeft,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Habit History",
                      style: theme.textTheme.displayMedium,
                    ),
                    const SizedBox(height: 5),
                    Text(
                      "View your completed habits",
                      style: theme.textTheme.displaySmall,
                    ),
                  ],
                ),
              ),
              Positioned(
                top: 0,
                right: 0,
                child: Text(
                  "See History",
                  style: theme.textTheme.bodySmall,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildHabitsBox(BuildContext context, ThemeData theme, List<QueryDocumentSnapshot> habits) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15.0),
        color: theme.cardColor,
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Your Habits", style: theme.textTheme.displayMedium),
              ],
            ),
          ),
          if (habits.isEmpty)
            Padding(
              padding: const EdgeInsets.all(10),
              child: Text("No habits available.", style: theme.textTheme.displayMedium),
            ),
          if (habits.isNotEmpty)
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(10),
                child: Column(
                  children: habits.map((habit) {
                    final data = habit.data()! as Map<String, dynamic>;
                    final habitObject = HabitsModel(
                      id: habit.id,
                      title: data['title'] as String? ?? "",
                      description: data['description'] as String? ?? "",
                      amount: data['amount'] as String? ?? "",
                      frequency: data['frequency'] as String? ?? "",
                      timeCompletion: data['timeCompletion'] as String? ?? "",
                      pointsGain: data['pointsGain'] as String? ?? "",
                      pointsLost: data['pointsLost'] as String? ?? "",
                    );
                    return HabitCard(
                      habit: habitObject,
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => HabitScreen(habit: habitObject),
                          ),
                        );
                      },
                    );
                  }).toList(),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

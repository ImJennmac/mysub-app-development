import 'package:flutter/material.dart';
import 'package:mysub/features/explore/habits/model/habits_model.dart';

class HabitCard extends StatelessWidget {
  final HabitsModel habit;
  final VoidCallback onPressed;

  const HabitCard({
    super.key,
    required this.habit,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 5.0),
      child: InkWell(
        onTap: onPressed,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 10.0),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  habit.title,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const Icon(
                Icons.arrow_forward_ios,
                size: 16.0,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

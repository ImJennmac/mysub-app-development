import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fpdart/fpdart.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/button/backarrow.dart';
import 'package:mysub/features/explore/habits/model/habits_model.dart';

class HabitScreen extends ConsumerStatefulWidget {
  final HabitsModel habit;
  const HabitScreen({super.key, required this.habit});

  @override
  ConsumerState<HabitScreen> createState() => _HabitScreenState();
}

class _HabitScreenState extends ConsumerState<HabitScreen> {
  late PageController _pageController;
  late HabitsModel habit;
  int _currentPage = 0;

  String title = '';
  String description = '';
  int amount = 0;
  int pointsGain = 0;
  int pointsLost = 0;

  late TextEditingController titleController;
  late TextEditingController descriptionController;
  late TextEditingController amountController;
  late TextEditingController pointsGainController;
  late TextEditingController pointsLostController;

  List<String> punishmentOptions = ["None"];
  List<String> rewardOptions = ["None"];
  String selectedPunishment = "None";
  String selectedReward = "None";

  String frequencyCondition = "At least";
  int frequencyCount = 1;
  String frequencyInterval = "Once";
  TimeOfDay selectedTime = const TimeOfDay(hour: 0, minute: 0);

  List<String> daysOfWeek = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  List<bool> selectedDays = List.generate(7, (_) => false);

  late TextEditingController frequencyController;

  List<String> frequencyConditions = ["At least", "At most"];
  List<String> frequencyIntervals = ["Once", "Daily", "Weekly", "Monthly", "Custom", "Selected Days"];
  List<TimeOfDay> timeOptions = List.generate(
    96,
        (index) => TimeOfDay(hour: index ~/ 4, minute: (index % 4) * 15),
  );

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    _fetchPunishmentsAndRewards();
    habit = widget.habit;

    title = habit.title;
    description = habit.description;
    amount = int.tryParse(habit.amount) ?? 0;
    pointsGain = int.tryParse(habit.pointsGain) ?? 0;
    pointsLost = int.tryParse(habit.pointsLost) ?? 0;

    titleController = TextEditingController(text: title);
    descriptionController = TextEditingController(text: description);
    amountController = TextEditingController(text: amount.toString());
    pointsGainController = TextEditingController(text: pointsGain.toString());
    pointsLostController = TextEditingController(text: pointsLost.toString());
    frequencyController = TextEditingController(text: frequencyCount.toString());
  }

  @override
  void dispose() {
    _pageController.dispose();
    titleController.dispose();
    descriptionController.dispose();
    amountController.dispose();
    pointsGainController.dispose();
    pointsLostController.dispose();
    frequencyController.dispose();
    super.dispose();
  }

  void handleBackNavigation() {
    if (_currentPage > 0) {
      _pageController.previousPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.ease,
      );
      setState(() {
        _currentPage--;
      });
    } else {
      Navigator.of(context).pop();
    }
  }

  Future<void> _fetchPunishmentsAndRewards() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final userID = user.uid;
      final punishmentsRef = FirebaseFirestore.instance.collection('users/$userID/solo/punishments/assigned');
      final rewardsRef = FirebaseFirestore.instance.collection('users/$userID/solo/rewards/assigned');

      final punishmentsSnapshot = await punishmentsRef.get();
      final rewardsSnapshot = await rewardsRef.get();

      setState(() {
        punishmentOptions = ["None"];
        rewardOptions = ["None"];

        punishmentOptions.addAll(
          punishmentsSnapshot.docs.map((doc) => doc['title'] as String),
        );
        rewardOptions.addAll(
          rewardsSnapshot.docs.map((doc) => doc['title'] as String),
        );

        if (!punishmentOptions.contains(selectedPunishment)) {
          selectedPunishment = "None";
        }
        if (!rewardOptions.contains(selectedReward)) {
          selectedReward = "None";
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = habit.id.isNotEmpty;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  BackArrow(onPressed: handleBackNavigation),
                  Expanded(
                    child: Text(
                      isEditing ? "Edit Habit" : "Create Habit",
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const SizedBox(width: 48),
                ],
              ),
              const SizedBox(height: 20),
              Expanded(
                child: PageView(
                  controller: _pageController,
                  physics: const NeverScrollableScrollPhysics(),
                  onPageChanged: (int page) {
                    setState(() {
                      _currentPage = page;
                    });
                  },
                  children: [
                    buildTitleAmountPage(),
                    buildFrequencyTimePage(),
                    buildPointsAndAssignedPage(),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    if (_currentPage == 2) {
                      if (validateAndSaveHabit()) {
                        Navigator.pop(context);
                      }
                    } else {
                      _pageController.nextPage(
                        duration: const Duration(milliseconds: 300),
                        curve: Curves.ease,
                      );
                      setState(() {
                        _currentPage += 1;
                      });
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    backgroundColor: Theme.of(context).colorScheme.primary,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16.0,
                      vertical: 12.0,
                    ),
                  ),
                  child: Text(
                    _currentPage == 2 ? 'Save' : 'Continue',
                    style: Theme.of(context).textTheme.labelLarge?.copyWith(
                      color: Theme.of(context).colorScheme.onPrimary,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildTitleAmountPage() {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Title",
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        Container(
          decoration: BoxDecoration(
            color: theme.cardColor,
            borderRadius: BorderRadius.circular(10),
          ),
          margin: const EdgeInsets.only(bottom: 20),
          child: TextField(
            controller: titleController,
            decoration: const InputDecoration(
              border: InputBorder.none,
              focusedBorder: InputBorder.none,
              enabledBorder: InputBorder.none,
              hintText: "Enter title here",
            ),
            onChanged: (value) => title = value,
          ),
        ),
        const Text(
          "Description",
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        Container(
          decoration: BoxDecoration(
            color: theme.cardColor,
            borderRadius: BorderRadius.circular(10),
          ),
          margin: const EdgeInsets.only(bottom: 20),
          height: 150,
          child: TextField(
            controller: descriptionController,
            maxLines: null,

            expands: true,
            decoration: const InputDecoration(
              border: InputBorder.none,
              focusedBorder: InputBorder.none,
              enabledBorder: InputBorder.none,
              hintText: "Enter description here",
            ),
            onChanged: (value) => description = value,
          ),
        ),
        const Text(
          "Amount",
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        Container(
          decoration: BoxDecoration(
            color: theme.cardColor,
            borderRadius: BorderRadius.circular(10),
          ),
          padding: const EdgeInsets.all(8.0),
          margin: const EdgeInsets.only(bottom: 20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                icon: const Icon(Icons.remove),
                onPressed: () {
                  setState(() {
                    final currentValue = int.parse(amountController.text);
                    if (currentValue > 0) {
                      amountController.text = (currentValue - 1).toString();
                      amount = currentValue - 1;
                    }
                  });
                },
              ),
              SizedBox(
                width: 60,
                child: Text(
                  amountController.text,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.add),
                onPressed: () {
                  setState(() {
                    final currentValue = int.parse(amountController.text);
                    amountController.text = (currentValue + 1).toString();
                    amount = currentValue + 1;
                  });
                },
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget buildFrequencyTimePage() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("How many times should this habit be done?", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        Row(
          children: [
            DropdownButton<String>(
              value: frequencyCondition,
              items: frequencyConditions.map((String condition) {
                return DropdownMenuItem<String>(
                  value: condition,
                  child: Text(condition),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  frequencyCondition = value!;
                });
              },
            ),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: frequencyController,
                keyboardType: TextInputType.number,
                onChanged: (value) {
                  int count = int.tryParse(value) ?? 1;
                  if (count > 9999) {
                    count = 9999;
                    frequencyController.text = count.toString();
                    frequencyController.selection = TextSelection.fromPosition(TextPosition(offset: frequencyController.text.length));
                  }
                  setState(() {
                    frequencyCount = count;
                  });
                },
                decoration: InputDecoration(
                  hintText: "Enter count",
                  border: const OutlineInputBorder(),
                  suffixText: frequencyCount == 1 ? "time" : "times",
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        const Text("How often should the habit be repeated?", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        DropdownButton<String>(
          value: frequencyInterval,
          isExpanded: true,
          items: frequencyIntervals.map((String interval) {
            return DropdownMenuItem<String>(
              value: interval,
              child: Text(interval),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              frequencyInterval = value!;
            });
          },
        ),
        const SizedBox(height: 20),
        if (frequencyInterval == "Selected Days") ...[
          const Text("Select days:", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ToggleButtons(
            isSelected: selectedDays,
            onPressed: (int index) {
              setState(() {
                selectedDays[index] = !selectedDays[index];
              });
            },
            children: daysOfWeek.map((day) => Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: Text(day),
            ),
            ).toList(),
          ),
          const SizedBox(height: 20),
        ],
        const Text("What time should the habit be done by?", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("Hour", style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                  SizedBox(
                    height: 100,
                    child: CupertinoPicker(
                      scrollController: FixedExtentScrollController(initialItem: selectedTime.hour),
                      itemExtent: 32,
                      looping: true,
                      onSelectedItemChanged: (int index) {
                        setState(() {
                          selectedTime = TimeOfDay(hour: index, minute: selectedTime.minute);
                        });
                      },
                      children: List<Widget>.generate(24, (int index) {
                        return Center(child: Text(index.toString().padLeft(2, '0')));
                      }),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("Minute", style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                  SizedBox(
                    height: 100,
                    child: CupertinoPicker(
                      scrollController: FixedExtentScrollController(initialItem: selectedTime.minute ~/ 15),
                      itemExtent: 32,
                      looping: true,
                      onSelectedItemChanged: (int index) {
                        setState(() {
                          selectedTime = TimeOfDay(hour: selectedTime.hour, minute: index * 15);
                        });
                      },
                      children: List<Widget>.generate(4, (int index) {
                        return Center(child: Text((index * 15).toString().padLeft(2, '0')));
                      }),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget buildPointsAndAssignedPage() {
    return Column(
      children: [
        buildNumberCounter(pointsGainController, (value) => pointsGain = value, label: "Points Gain"),
        buildNumberCounter(pointsLostController, (value) => pointsLost = value, label: "Points Lost"),
        buildDropdown("Punishments Assigned", punishmentOptions, (value) {
          setState(() {
            selectedPunishment = value!;
          });
        }),
        buildDropdown("Rewards Assigned", rewardOptions, (value) {
          setState(() {
            selectedReward = value!;
          });
        }
        ),
      ],
    );
  }

  Widget buildNumberCounter(TextEditingController controller, Function(int) onChanged, {String label = ""}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (label.isNotEmpty) Text(label, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        IconButton(
          icon: const Icon(Icons.remove),
          onPressed: () {
            setState(() {
              final currentValue = int.parse(controller.text);
              if (currentValue > 0) {
                controller.text = (currentValue - 1).toString();
                onChanged(currentValue - 1);
              }
            });
          },
        ),
        SizedBox(width: 60, child: Text(controller.text, textAlign: TextAlign.center)),
        IconButton(
          icon: const Icon(Icons.add),
          onPressed: () {
            setState(() {
              final currentValue = int.parse(controller.text);
              controller.text = (currentValue + 1).toString();
              onChanged(currentValue + 1);
            });
          },
        ),
      ],
    );
  }

  Widget buildDropdown(String label, List<String> options, ValueChanged<String?> onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        DropdownButton<String>(
          isExpanded: true,
          value: label == "Punishments Assigned" ? selectedPunishment : selectedReward,
          items: options.map((String option) {
            return DropdownMenuItem<String>(
              value: option,
              child: Text(option),
            );
          }).toList(),
          onChanged: onChanged,
        ),
      ],
    );
  }

  Widget buildTextField(String hint, TextEditingController controller, Function(String) onChanged, {int maxLines = 1}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      child: TextField(
        controller: controller,
        maxLines: maxLines,
        decoration: InputDecoration(
          hintText: hint,
          border: const OutlineInputBorder(),
        ),
        onChanged: onChanged,
      ),
    );
  }

  bool validateAndSaveHabit() {
    if (title.isEmpty || description.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Both title and description must be filled out')),
      );
      return false;
    }
    saveHabit();
    return true;
  }

  Future<void> saveHabit() async {
    final optionalUser = ref.watch(userProvider);
    final user = optionalUser.getOrElse(() => throw Exception("User not found"));
    final CollectionReference myHabits = FirebaseFirestore.instance.collection('users/${user.uid}/habits');

    final habitData = {
      'title': title,
      'description': description,
      'amount': amount.toString(),
      'frequencyCondition': frequencyCondition,
      'frequencyCount': frequencyCount.toString(),
      'frequencyInterval': frequencyInterval,
      'timeCompletion': selectedTime.format(context),
      'pointsGain': pointsGain.toString(),
      'pointsLost': pointsLost.toString(),
      'punishmentAssigned': selectedPunishment,
      'rewardAssigned': selectedReward,
    };

    if (habit.id.isEmpty) {
      await myHabits.add(habitData);
    } else {
      await myHabits.doc(habit.id).update(habitData);
    }
  }
}

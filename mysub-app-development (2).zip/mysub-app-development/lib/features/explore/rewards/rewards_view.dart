import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/button/homebutton.dart';
import 'package:mysub/common/util/button/plusbutton.dart';
import 'package:mysub/common/util/navbar/navbar.dart';
import 'package:mysub/features/explore/rewards/controllers/reward_check_permissions.dart';
import 'package:mysub/features/explore/rewards/controllers/rewards_collections.dart';
import 'package:mysub/features/explore/rewards/model/rewards_model.dart';
import 'package:mysub/features/explore/rewards/pages/reward_history.dart';
import 'package:mysub/features/explore/rewards/widgets/integrated_points.dart';
import 'package:mysub/features/explore/rewards/widgets/reward_card.dart';
import 'package:mysub/features/explore/rewards/widgets/rewards_screen.dart';

class RewardsView extends ConsumerStatefulWidget {
  static const String id = "rewardsview";
  const RewardsView({super.key});

  @override
  ConsumerState<RewardsView> createState() => _RewardsViewState();
}

class _RewardsViewState extends ConsumerState<RewardsView> {
  Future<void> buyReward(RewardsModel reward, int userPoints,
      DocumentReference pointsDoc, DocumentReference rewardDoc,) async {
    if (userPoints >= reward.rewardCost) {
      await pointsDoc.update({'points': userPoints - reward.rewardCost});
      await rewardDoc.update({'amountAssigned': reward.amountAssigned + 1});
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Not enough points to buy this reward')),
      );
    }
  }

  Future<void> completeReward(RewardsModel reward,
      DocumentReference rewardDoc,
      ) async {
    if (reward.amountAssigned > 0) {
      await rewardDoc.update({'amountAssigned': reward.amountAssigned - 1});
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No assigned rewards to complete')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final optionalUser = ref.watch(userProvider);
    final user = optionalUser.fold(() => null, (u) => u);
    final theme = Theme.of(context);

    if (user == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const HomeButton(),
                      Text(
                        "Rewards",
                        style: theme.textTheme.displayLarge,
                      ),
                      FutureBuilder<bool>(
                        future: CheckRewardsPermissions
                            .checkCreateRewardsPermission(ref),
                        builder: (context, snapshot) {
                          if (snapshot.hasData && snapshot.data == true) {
                            return PlusButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        RewardScreen(
                                          reward: RewardsModel(
                                            id: '',
                                            title: '',
                                            description: '',
                                            rewardCost: 0,
                                            enabled: false,
                                            amountAssigned: 0,
                                          ),
                                        ),
                                  ),
                                );
                              },
                            );
                          }
                          return const SizedBox.shrink();
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  buildPointsBox("Points", "Number of points you have"),
                  const SizedBox(height: 20),
                  buildHistoryBox(context, theme),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15.0),
                    color: theme.cardColor,
                  ),
                  child: FutureBuilder<DocumentReference?>(
                    future: RewardsCollections.fetchPointsDocument(ref),
                    builder: (context, pointsDocSnapshot) {
                      if (!pointsDocSnapshot.hasData) {
                        return const Center(child: CircularProgressIndicator());
                      }

                      final pointsDoc = pointsDocSnapshot.data!;

                      return FutureBuilder<CollectionReference?>(
                        future: RewardsCollections.fetchRewardsCollection(ref),
                        builder: (context, rewardsCollectionSnapshot) {
                          if (!rewardsCollectionSnapshot.hasData) {
                            return const Center(
                                child: CircularProgressIndicator(),
                            );
                          }

                          final rewardsCollection = rewardsCollectionSnapshot
                              .data!;

                          return StreamBuilder<DocumentSnapshot>(
                            stream: pointsDoc.snapshots(),
                            builder: (context, pointsSnapshot) {
                              if (!pointsSnapshot.hasData) {
                                return const Center(
                                    child: CircularProgressIndicator(),);
                              }
                              if (!pointsSnapshot.data!.exists) {
                                return Padding(
                                  padding: const EdgeInsets.all(10),
                                  child: Text(
                                    "No points data available.",
                                    style: theme.textTheme.displayMedium,
                                  ),
                                );
                              }
                              final userPoints = pointsSnapshot.data!.get(
                                  'points',) as int;

                              return StreamBuilder<QuerySnapshot>(
                                stream: rewardsCollection.snapshots(),
                                builder: (context, rewardsSnapshot) {
                                  if (!rewardsSnapshot.hasData) {
                                    return const Center(
                                        child: CircularProgressIndicator(),);
                                  }
                                  final rewards = rewardsSnapshot.data!.docs;

                                  return Column(
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.all(10),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment
                                              .spaceBetween,
                                          children: [
                                            Text(
                                              "Rewards to Redeem",
                                              style: theme.textTheme
                                                  .displayMedium,
                                            ),
                                          ],
                                        ),
                                      ),
                                      const SizedBox(height: 5),
                                      if (rewards.isEmpty)
                                        Padding(
                                          padding: const EdgeInsets.all(10),
                                          child: Text(
                                            "No rewards to redeem.",
                                            style: theme.textTheme
                                                .displayMedium,
                                          ),
                                        ),
                                      if (rewards.isNotEmpty)
                                        Expanded(
                                          child: SingleChildScrollView(
                                            padding: const EdgeInsets.all(10),
                                            child: Column(
                                              children: rewards.map((reward) {
                                                final data = reward
                                                    .data()! as Map<
                                                    String,
                                                    dynamic>;
                                                final rewardObject = RewardsModel(
                                                  id: reward.id,
                                                  title: data['title'] as String? ??
                                                      "",
                                                  description: data['description'] as String? ??
                                                      "",
                                                  rewardCost: data['rewardCost'] as int? ??
                                                      0,
                                                  enabled: data['enabled'] as bool? ??
                                                      false,
                                                  amountAssigned: data['amountAssigned'] as int? ??
                                                      0,
                                                );
                                                return RewardCard(
                                                  reward: rewardObject,
                                                  onPressed: () {
                                                    Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                        builder: (context) =>
                                                            RewardScreen(
                                                                reward: rewardObject,),
                                                      ),
                                                    );
                                                  },
                                                  onBuy: () =>
                                                      buyReward(rewardObject,
                                                          userPoints, pointsDoc,
                                                          reward.reference,),
                                                  onComplete: () =>
                                                      completeReward(
                                                          rewardObject,
                                                          reward.reference,),
                                                  ref: ref,
                                                );
                                              }).toList(),
                                            ),
                                          ),
                                        ),
                                    ],
                                  );
                                },
                              );
                            },
                          );
                        },
                      );
                    },
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
      bottomNavigationBar: const NavBar(),
    );
  }

  Widget buildHistoryBox(BuildContext context, ThemeData theme) {
    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(context, RewardsHistory.id);
      },
      child: Container(
        width: double.infinity,
        height: 70,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15.0),
          color: theme.cardColor,
        ),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Stack(
            children: [
              Align(
                alignment: Alignment.topLeft,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Reward History",
                      style: theme.textTheme.displayMedium,
                    ),
                    const SizedBox(height: 5),
                    Text(
                      "View your redeemed rewards",
                      style: theme.textTheme.displaySmall,
                    ),
                  ],
                ),
              ),
              Positioned(
                top: 0,
                right: 0,
                child: Text(
                  "See History",
                  style: theme.textTheme.bodySmall,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildPointsBox(String title, String subtitle) {
    final theme = Theme.of(context);
    return Stack(
      children: [
        Container(
          width: double.infinity,
          height: 75,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15.0),
            color: theme.cardColor,
          ),
        ),
        Positioned(
          top: 10,
          left: 10,
          right: 10,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: theme.textTheme.displayMedium,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: theme.textTheme.displaySmall,
                  ),
                ],
              ),
              IntegratedPointsDisplayCounter(textStyle: theme.textTheme.displayMedium),
            ],
          ),
        ),
      ],
    );
  }
}

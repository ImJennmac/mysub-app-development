import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/features/explore/rewards/controllers/reward_check_permissions.dart';
import 'package:mysub/features/explore/rewards/controllers/rewards_collections.dart';

class IntegratedPointsDisplayCounter extends ConsumerStatefulWidget {
  final TextStyle? textStyle;
  final bool showButtons;

  const IntegratedPointsDisplayCounter({
    super.key,
    this.textStyle,
    this.showButtons = true,
  });

  @override
  ConsumerState<IntegratedPointsDisplayCounter> createState() =>
      _IntegratedPointsDisplayCounterState();
}

class _IntegratedPointsDisplayCounterState extends ConsumerState<IntegratedPointsDisplayCounter> {
  Timer? _debounceTimer;
  bool _hasChanges = false;
  static const int maxPoints = 1000000;
  DocumentReference? pointsDoc;
  int? _localPoints;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _initializePointsDoc();
  }

  Future<void> _initializePointsDoc() async {
    pointsDoc = await RewardsCollections.fetchPointsDocument(ref);
    setState(() {});
  }

  void _debounceWrite(int points) {
    _hasChanges = true;
    _localPoints = points;
    _debounceTimer?.cancel();
    _debounceTimer = Timer(const Duration(milliseconds: 600), () {
      if (_hasChanges) {
        _writeToFirestore(points);
        _hasChanges = false;
      }
    });
    setState(() {});
  }

  Future<void> _writeToFirestore(int points) async {
    if (pointsDoc != null) {
      await RewardsCollections.updatePoints(ref, points);
    }
  }

  Future<void> _showEditDialog(BuildContext context) async {
    final TextEditingController controller = TextEditingController(text: _localPoints.toString());

    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Edit Points'),
          content: TextField(
            controller: controller,
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            decoration: const InputDecoration(hintText: 'Enter new points'),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                final newPoints = int.tryParse(controller.text) ?? _localPoints!;
                if (newPoints >= 0 && newPoints <= maxPoints) {
                  _debounceWrite(newPoints);
                }
                Navigator.pop(context);
              },
              child: const Text('Update'),
            ),
          ],
        );
      },
    );
  }

  @override
  void dispose() {
    _debounceTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    if (pointsDoc == null) {
      return const Center(child: CircularProgressIndicator());
    }

    return StreamBuilder<DocumentSnapshot>(
      stream: pointsDoc!.snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting && _localPoints == null) {
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasData && snapshot.data!.exists) {
          final firestorePoints = snapshot.data!.get('points') as int? ?? 0;
          if (!_hasChanges) {
            _localPoints = firestorePoints;
          }
        } else if (_localPoints == null) {
          return const Text("No points data available");
        }

        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (widget.showButtons)
              IconButton(
                onPressed: () async {
                  final scaffoldMessenger = ScaffoldMessenger.of(context);

                  if (await CheckRewardsPermissions.checkAddRemovePointsPermission(ref)) {
                    if (_localPoints! > 0) {
                      _debounceWrite(_localPoints! - 1);
                    }
                  } else {
                    scaffoldMessenger.showSnackBar(
                      const SnackBar(content: Text('Permission denied to modify points.')),
                    );
                  }
                },
                icon: const Icon(Icons.remove),
                color: theme.iconTheme.color,
              ),
            GestureDetector(
              onTap: () => _showEditDialog(context),
              child: Text(
                _localPoints.toString(),
                textAlign: TextAlign.center,
                style: widget.textStyle ??
                    theme.textTheme.bodyLarge?.copyWith(
                      color: theme.textTheme.bodyLarge?.color ?? theme.colorScheme.onSurface,
                    ),
              ),
            ),
            if (widget.showButtons)
              IconButton(
                onPressed: () async {
                  final scaffoldMessenger = ScaffoldMessenger.of(context);

                  if (await CheckRewardsPermissions.checkAddRemovePointsPermission(ref)) {
                    if (_localPoints! < maxPoints) {
                      _debounceWrite(_localPoints! + 1);
                    }
                  } else {
                    scaffoldMessenger.showSnackBar(
                      const SnackBar(content: Text('Permission denied to modify points.')),
                    );
                  }
                },
                icon: const Icon(Icons.add),
                color: theme.iconTheme.color,
              ),
          ],
        );
      },
    );
  }
}

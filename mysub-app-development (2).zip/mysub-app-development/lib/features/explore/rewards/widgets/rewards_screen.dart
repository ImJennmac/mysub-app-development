import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fpdart/fpdart.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/button/backarrow.dart';
import 'package:mysub/common/util/button/large_bin_button.dart';
import 'package:mysub/common/util/button/savebutton.dart';
import 'package:mysub/features/explore/rewards/controllers/reward_check_permissions.dart';
import 'package:mysub/features/explore/rewards/controllers/rewards_collections.dart';
import 'package:mysub/features/explore/rewards/model/rewards_model.dart';

class RewardScreen extends ConsumerStatefulWidget {
  final RewardsModel reward;
  const RewardScreen({super.key, required this.reward});

  @override
  ConsumerState<RewardScreen> createState() => _RewardScreenState();
}

class _RewardScreenState extends ConsumerState<RewardScreen> {
  late RewardsModel reward;
  String titleString = '';
  String descriptionString = '';
  int rewardCost = 0;
  bool enabled = false;
  int amountAssigned = 0;

  late TextEditingController titleController;
  late TextEditingController descriptionController;
  late TextEditingController rewardCostController;
  late TextEditingController amountAssignedController;
  final ValueNotifier<String?> errorMessageNotifier = ValueNotifier<String?>(null);

  @override
  void initState() {
    super.initState();
    reward = widget.reward;
    titleString = reward.title;
    descriptionString = reward.description;
    rewardCost = reward.rewardCost;
    enabled = reward.enabled;
    amountAssigned = reward.amountAssigned;

    titleController = TextEditingController(text: titleString);
    descriptionController = TextEditingController(text: descriptionString);
    rewardCostController = TextEditingController(text: rewardCost.toString());
    amountAssignedController = TextEditingController(text: amountAssigned.toString());

    titleController.addListener(() {
      if (titleController.text.length > 30) {
        errorMessageNotifier.value = 'Title cannot exceed 30 characters';
      } else {
        errorMessageNotifier.value = null;
      }
    });
  }

  @override
  void dispose() {
    titleController.dispose();
    descriptionController.dispose();
    rewardCostController.dispose();
    amountAssignedController.dispose();
    errorMessageNotifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final optionalUser = ref.watch(userProvider);
    final user = optionalUser.getOrElse(() => throw Exception("User not found"));
    FirebaseFirestore.instance.collection('users').doc(user.uid);
    final theme = Theme.of(context);

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: FutureBuilder<CollectionReference?>(
            future: RewardsCollections.fetchRewardsCollection(ref),
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return const Center(child: CircularProgressIndicator());
              }

              final myRewards = snapshot.data!;

              return Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const BackArrow(),
                      Expanded(
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            TextField(
                              controller: titleController,
                              textAlign: TextAlign.center,
                              inputFormatters: [
                                LengthLimitingTextInputFormatter(30),
                              ],
                              decoration: const InputDecoration(
                                border: InputBorder.none,
                                focusedBorder: InputBorder.none,
                                enabledBorder: InputBorder.none,
                                hintText: "Reward Title",
                                hintStyle: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                              ),
                              onChanged: (value) {
                                setState(() {
                                  titleString = value;
                                });
                              },
                            ),
                          ],
                        ),
                      ),
                      SaveButton(
                        onPressed: () async {
                          final scaffoldMessenger = ScaffoldMessenger.of(context);
                          final navigator = Navigator.of(context);

                          // Perform permission check
                          final hasPermission = (reward.id.isEmpty && await CheckRewardsPermissions.checkCreateRewardsPermission(ref)) ||
                              (reward.id.isNotEmpty && await CheckRewardsPermissions.checkEditDeleteRewardsPermission(ref));

                          if (hasPermission) {
                            // Validate and save
                            if (validateAndSaveReward(myRewards)) {
                              navigator.pop(); // Use the navigator captured at the start
                            }
                          } else {
                            scaffoldMessenger.showSnackBar(
                              const SnackBar(content: Text('Permission denied to save this reward.')),
                            );
                          }
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  ValueListenableBuilder<String?>(
                    valueListenable: errorMessageNotifier,
                    builder: (context, errorMessage, child) {
                      return errorMessage != null
                          ? Text(
                        errorMessage,
                        style: const TextStyle(color: Colors.red),
                      )
                          : const SizedBox.shrink();
                    },
                  ),
                  const SizedBox(height: 20),
                  Expanded(
                    child: ListView(
                      children: [
                        const Text(
                          "Description",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: theme.cardColor,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          margin: const EdgeInsets.only(bottom: 20),
                          height: 200,
                          child: TextField(
                            controller: descriptionController,
                            maxLines: null,
                            expands: true,
                            decoration: const InputDecoration(
                              border: InputBorder.none,
                              focusedBorder: InputBorder.none,
                              enabledBorder: InputBorder.none,
                              hintText: "Reward Description",
                            ),
                            onChanged: (value) {
                              descriptionString = value;
                            },
                          ),
                        ),
                        const Text(
                          "Reward Cost",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: theme.cardColor,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          padding: const EdgeInsets.all(8.0),
                          margin: const EdgeInsets.only(bottom: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.remove),
                                onPressed: () {
                                  setState(() {
                                    if (rewardCost > 0) rewardCost--;
                                    rewardCostController.text = rewardCost.toString();
                                  });
                                },
                              ),
                              Expanded(
                                child: TextField(
                                  controller: rewardCostController,
                                  keyboardType: TextInputType.number,
                                  textAlign: TextAlign.center,
                                  decoration: const InputDecoration(
                                    border: InputBorder.none,
                                    focusedBorder: InputBorder.none,
                                    enabledBorder: InputBorder.none,
                                    hintText: "Reward Cost",
                                  ),
                                  onChanged: (value) {
                                    rewardCost = int.tryParse(value) ?? 0;
                                  },
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.add),
                                onPressed: () {
                                  setState(() {
                                    rewardCost++;
                                    rewardCostController.text = rewardCost.toString();
                                  });
                                },
                              ),
                            ],
                          ),
                        ),
                        const Text(
                          "Amount Assigned",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: theme.cardColor,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          padding: const EdgeInsets.all(8.0),
                          margin: const EdgeInsets.only(bottom: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.remove),
                                onPressed: () {
                                  setState(() {
                                    if (amountAssigned > 0) amountAssigned--;
                                    amountAssignedController.text = amountAssigned.toString();
                                  });
                                },
                              ),
                              Expanded(
                                child: TextField(
                                  controller: amountAssignedController,
                                  keyboardType: TextInputType.number,
                                  textAlign: TextAlign.center,
                                  decoration: const InputDecoration(
                                    border: InputBorder.none,
                                    focusedBorder: InputBorder.none,
                                    enabledBorder: InputBorder.none,
                                    hintText: "Amount Assigned",
                                  ),
                                  onChanged: (value) {
                                    amountAssigned = int.tryParse(value) ?? 0;
                                  },
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.add),
                                onPressed: () {
                                  setState(() {
                                    amountAssigned++;
                                    amountAssignedController.text = amountAssigned.toString();
                                  });
                                },
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (reward.id.isNotEmpty)
                    LargeBinButton(
                      onPressed: () {
                        myRewards.doc(reward.id).delete();
                        Navigator.pop(context);
                      },
                    ),
                ],
              );
            },
          ),

        ),
      ),
    );
  }

  bool validateAndSaveReward(CollectionReference myRewards) {
    if (titleString.isEmpty || descriptionString.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Both title and description must be filled out')),
      );
      return false;
    }

    if (titleString.length > 30) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Title cannot exceed 30 characters')),
      );
      return false;
    }

    saveReward(myRewards);
    return true;
  }

  Future<void> saveReward(CollectionReference myRewards) async {
    final rewardData = {
      'title': titleString,
      'description': descriptionString,
      'rewardCost': rewardCost,
      'enabled': enabled,
      'amountAssigned': amountAssigned,
    };

    if (reward.id.isEmpty) {
      await myRewards.add(rewardData);
    } else {
      await myRewards.doc(reward.id).update(rewardData);
    }
  }
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fpdart/fpdart.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:logger/logger.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/logger/logger.dart';

class RewardsCollections {
  static final Logger _logger = MySubLogger.getLogger((RewardsCollections).toString());

  static Future<CollectionReference?> fetchRewardsCollection(WidgetRef ref) async {
    try {
      final optionalUser = ref.read(userProvider);
      final user = optionalUser.getOrElse(() => throw Exception("User not found"));
      final DocumentReference userDoc = FirebaseFirestore.instance.collection('users').doc(user.uid);

      final snapshot = await userDoc.get();
      final data = snapshot.data() as Map<String, dynamic>?;
      final activePartner = data?['activePartner'] as Map<String, dynamic>? ?? {};
      final activeFriendshipID = activePartner['activeFriendshipID'] as String? ?? 'solo';

      if (activeFriendshipID.isEmpty) {
        throw Exception("Invalid activeFriendshipID: Cannot be empty");
      }

      if (activeFriendshipID == 'solo') {
        return FirebaseFirestore.instance.collection('users/${user.uid}/solo/rewards/assigned');
      } else {
        return FirebaseFirestore.instance.collection('friendships/$activeFriendshipID/explore/rewards/rewards');
      }
    } catch (e) {
      _logger.e('Error fetching rewards collection: $e');
      return null;
    }
  }

  static Future<DocumentReference?> fetchPointsDocument(WidgetRef ref) async {
    try {
      final optionalUser = ref.read(userProvider);
      final user = optionalUser.getOrElse(() => throw Exception("User not found"));
      final DocumentReference userDoc = FirebaseFirestore.instance.collection('users').doc(user.uid);

      final snapshot = await userDoc.get();
      final data = snapshot.data() as Map<String, dynamic>?;
      final activePartner = data?['activePartner'] as Map<String, dynamic>? ?? {};
      final activeFriendshipID = activePartner['activeFriendshipID'] as String? ?? 'solo';

      if (activeFriendshipID.isEmpty) {
        throw Exception("Invalid activeFriendshipID: Cannot be empty");
      }

      if (activeFriendshipID == 'solo') {
        return FirebaseFirestore.instance.collection('users').doc(user.uid);
      } else {
        return FirebaseFirestore.instance.collection('friendships/$activeFriendshipID/explore').doc('rewards');
      }
    } catch (e) {
      _logger.e('Error fetching points document: $e');
      return null;
    }
  }
  static Future<int> fetchInitialPoints(WidgetRef ref) async {
    try {
      final DocumentReference? pointsDoc = await fetchPointsDocument(ref);
      if (pointsDoc == null) throw Exception("Points document not found");

      final documentSnapshot = await pointsDoc.get();
      if (documentSnapshot.exists) {
        return documentSnapshot.get('points') as int? ?? 0;
      }
      return 0; // Default to 0 if points field is not present
    } catch (e) {
      _logger.e('Error fetching initial points: $e');
      return 0;
    }
  }

  // Method to update the points value
  static Future<void> updatePoints(WidgetRef ref, int points) async {
    try {
      final DocumentReference? pointsDoc = await fetchPointsDocument(ref);
      if (pointsDoc == null) throw Exception("Points document not found");

      await pointsDoc.update({'points': points});
    } catch (e) {
      _logger.e('Error updating points: $e');
    }
  }
}

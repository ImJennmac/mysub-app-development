class RewardsModel {
  String id;
  String title;
  String description;
  int rewardCost;
  bool enabled;
  int amountAssigned;

  RewardsModel({
    required this.id,
    required this.title,
    required this.description,
    required this.rewardCost,
    required this.enabled,
    required this.amountAssigned,
  });
}

import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/button/backarrow.dart';
import 'package:mysub/common/util/navbar/navbar.dart';

class RewardsHistory extends ConsumerStatefulWidget {
  static const String id = "rewardshistory";
  const RewardsHistory({super.key});

  @override
  ConsumerState<RewardsHistory> createState() => _RewardsHistoryState();
}

class _RewardsHistoryState extends ConsumerState<RewardsHistory> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final optionalUser = ref.watch(userProvider);
    final theme = Theme.of(context);

    return optionalUser.match(
          () => const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      ),
          (user) {
        return Scaffold(
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const BackArrow(),
                      Expanded(
                        child: Center(
                          child: Text(
                            "Rewards History",
                            style: theme.textTheme.titleMedium,
                          ),
                        ),
                      ),
                      const SizedBox(width: 48),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Text(
                    "Here is your Rewards History!",
                    style: theme.textTheme.displayMedium,
                  ),
                ],
              ),
            ),
          ),
          bottomNavigationBar: const NavBar(),
        );
      },
    );
  }
}

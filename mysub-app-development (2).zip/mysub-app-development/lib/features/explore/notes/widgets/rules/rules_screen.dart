import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fpdart/fpdart.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:logger/logger.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/button/backarrow.dart';
import 'package:mysub/common/util/button/large_bin_button.dart';
import 'package:mysub/common/util/button/savebutton.dart';
import 'package:mysub/common/util/logger/logger.dart';
import 'package:mysub/features/explore/notes/model/notes_model.dart';

class RulesScreen extends ConsumerStatefulWidget {
  final NotesModel note;
  const RulesScreen({super.key, required this.note});

  @override
  ConsumerState<RulesScreen> createState() => _RulesScreenState();
}

class _RulesScreenState extends ConsumerState<RulesScreen> {
  late NotesModel note;
  String titleString = '';
  String noteString = '';
  late TextEditingController titleController;
  late TextEditingController noteController;
  final ValueNotifier<String?> errorMessageNotifier = ValueNotifier<String?>(null);
  CollectionReference? myRules;
  bool isLoading = true;

  final Logger _logger = MySubLogger.getLogger((RulesScreen).toString());

  @override
  void initState() {
    super.initState();
    note = widget.note;
    titleString = note.title;
    noteString = note.note;
    titleController = TextEditingController(text: titleString);
    noteController = TextEditingController(text: noteString);

    fetchRulesCollection();

    titleController.addListener(() {
      if (titleController.text.length > 30) {
        errorMessageNotifier.value = 'Title cannot exceed 30 characters';
      } else {
        errorMessageNotifier.value = null;
      }
    });
  }

  Future<void> fetchRulesCollection() async {
    try {
      final optionalUser = ref.read(userProvider);
      final user = optionalUser.getOrElse(() => throw Exception("User not found"));
      final DocumentReference userDoc =
      FirebaseFirestore.instance.collection('users').doc(user.uid);

      final snapshot = await userDoc.get();
      final data = snapshot.data() as Map<String, dynamic>?;
      final activePartner = data?['activePartner'] as Map<String, dynamic>? ?? {};
      final activeFriendshipID = activePartner['activeFriendshipID'] as String? ?? 'solo';

      if (activeFriendshipID == 'solo') {
        myRules = FirebaseFirestore.instance.collection('users/${user.uid}/solo/notes/rules');
      } else {
        myRules =
            FirebaseFirestore.instance.collection('friendships/$activeFriendshipID/explore/rules/rules');
      }

      await createCollectionIfNotExists();

      setState(() {
        isLoading = false;
      });
    } catch (e) {
      _logger.e('Error fetching rules collection: $e');
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> createCollectionIfNotExists() async {
    try {
    } catch (e) {
      _logger.e('Error creating collection path: $e');
    }
  }

  @override
  void dispose() {
    titleController.dispose();
    noteController.dispose();
    errorMessageNotifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    if (isLoading || myRules == null) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const BackArrow(),
                  Expanded(
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        TextField(
                          controller: titleController,
                          textAlign: TextAlign.center,
                          inputFormatters: [
                            LengthLimitingTextInputFormatter(30),
                          ],
                          decoration: const InputDecoration(
                            border: InputBorder.none,
                            focusedBorder: InputBorder.none,
                            enabledBorder: InputBorder.none,
                            hintText: "Rule Title",
                            hintStyle: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 20,
                            ),
                          ),
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                          ),
                          onChanged: (value) {
                            setState(() {
                              titleString = value;
                            });
                          },
                        ),
                      ],
                    ),
                  ),
                  SaveButton(
                    onPressed: () {
                      if (validateAndSaveRules()) {
                        Navigator.pop(context);
                      }
                    },
                  ),
                ],
              ),
              const SizedBox(height: 20),
              ValueListenableBuilder<String?>(
                valueListenable: errorMessageNotifier,
                builder: (context, errorMessage, child) {
                  return errorMessage != null
                      ? Text(
                    errorMessage,
                    style: const TextStyle(color: Colors.red),
                  )
                      : const SizedBox.shrink();
                },
              ),
              const SizedBox(height: 20),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: theme.cardColor,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Padding(
                    padding: EdgeInsets.zero,
                    child: TextField(
                      controller: noteController,
                      maxLines: null,
                      decoration: const InputDecoration(
                        border: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        hintText: "Rule Content",
                      ),
                      onChanged: (value) {
                        noteString = value;
                      },
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              if (note.id.isNotEmpty)
                LargeBinButton(
                  onPressed: () {
                    myRules!.doc(note.id).delete();
                    Navigator.pop(context);
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }

  bool validateAndSaveRules() {
    if (titleString.isEmpty || noteString.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Both title and rule content must be filled out')),
      );
      return false;
    }

    if (titleString.length > 30) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Title cannot exceed 30 characters')),
      );
      return false;
    }

    saveRules();
    return true;
  }

  Future<void> saveRules() async {
    if (note.id.isEmpty) {
      await myRules!.add({
        'title': titleString,
        'note': noteString,
      });
    } else {
      await myRules!.doc(note.id).update({
        'title': titleString,
        'note': noteString,
      });
    }
  }
}

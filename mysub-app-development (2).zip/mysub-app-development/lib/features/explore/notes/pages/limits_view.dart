import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fpdart/fpdart.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:logger/logger.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/button/backarrow.dart';
import 'package:mysub/common/util/button/plusbutton.dart';
import 'package:mysub/common/util/logger/logger.dart';
import 'package:mysub/features/explore/notes/model/notes_model.dart';
import 'package:mysub/features/explore/notes/widgets/card.dart';
import 'package:mysub/features/explore/notes/widgets/limits/limits_screen.dart';

class LimitsView extends ConsumerStatefulWidget {
  static const String id = "limits_view";
  const LimitsView({super.key});

  @override
  ConsumerState<LimitsView> createState() => _LimitsViewState();
}

class _LimitsViewState extends ConsumerState<LimitsView> {
  CollectionReference? myNotes;
  bool isLoading = true;

  final Logger _logger = MySubLogger.getLogger((LimitsView).toString());

  @override
  void initState() {
    super.initState();
    fetchNotesCollection();
  }

  Future<void> fetchNotesCollection() async {
    try {
      final optionalUser = ref.read(userProvider);
      final user = optionalUser.getOrElse(() => throw Exception("User not found"));
      final DocumentReference userDoc =
      FirebaseFirestore.instance.collection('users').doc(user.uid);

      final snapshot = await userDoc.get();
      final data = snapshot.data() as Map<String, dynamic>?;
      final activePartner = data?['activePartner'] as Map<String, dynamic>? ?? {};
      final activeFriendshipID = activePartner['activeFriendshipID'] as String? ?? 'solo';

      if (activeFriendshipID == 'solo') {
        myNotes = FirebaseFirestore.instance.collection('users/${user.uid}/solo/notes/limits');
      } else {
        myNotes =
            FirebaseFirestore.instance.collection('friendships/$activeFriendshipID/explore/limits/limits');
      }

      // Ensure the collection path exists
      await createCollectionIfNotExists();

      setState(() {
        isLoading = false;
      });
    } catch (e) {
      _logger.e('Error fetching notes collection: $e');
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> createCollectionIfNotExists() async {
    try {
    } catch (e) {
      _logger.e('Error creating collection path: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final optionalUser = ref.watch(userProvider);
    final theme = Theme.of(context);

    return optionalUser.match(
      () => const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      ),
      (user) {
        if (isLoading || myNotes == null) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }

        return Scaffold(
          body: SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const BackArrow(),
                      Expanded(
                        child: Center(
                          child: Text(
                            "Limits",
                            style: theme.textTheme.displayLarge,
                          ),
                        ),
                      ),
                      PlusButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => LimitsScreen(
                                note: NotesModel(
                                  id: '',
                                  title: '',
                                  note: '',
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: StreamBuilder<QuerySnapshot>(
                    stream: myNotes!.snapshots(),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        return const Center(
                          child: CircularProgressIndicator(),
                        );
                      }
                      final notes = snapshot.data!.docs;
                      final List<NoteCard> noteCards = [];
                      for (final note in notes) {
                        final data = note.data() as Map<String, dynamic>?;
                        if (data != null) {
                          final NotesModel noteObject = NotesModel(
                            id: note.id,
                            title: data['title'] as String? ?? "",
                            note: data['note'] as String? ?? "",
                          );
                          noteCards.add(
                            NoteCard(
                              note: noteObject,
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => LimitsScreen(note: noteObject),
                                  ),
                                );
                              },
                            ),
                          );
                        }
                      }
                      return ListView.builder(
                        itemCount: noteCards.length,
                        itemBuilder: (context, index) {
                          return Container(
                            margin: const EdgeInsets.symmetric(vertical: 5),
                            child: noteCards[index],
                          );
                        },
                        padding: const EdgeInsets.all(3),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

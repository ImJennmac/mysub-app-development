// All Rights Reserved (ARR)
// Copyright (c) 2024 NotSuitable Group LTD
// Created with love by the team at NSG.

class NotesModel {
  String id;
  String title;
  String note;

  NotesModel({
    required this.id,
    required this.title,
    required this.note,
  });
}

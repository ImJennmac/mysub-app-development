import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:mysub/features/explore/punishments/model/punishments_model.dart';

class PunishmentCounterController {
  static Future<void> completePunishment(
      PunishmentsModel punishment, DocumentReference punishmentDoc, BuildContext context,) async {
    if (punishment.amountAssigned > 0) {
      await punishmentDoc.update({'amountAssigned': punishment.amountAssigned - 1});
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No assigned punishments to complete')),
      );
    }
  }

  static Future<void> incrementPunishment(
      PunishmentsModel punishment, DocumentReference punishmentDoc,) async {
    await punishmentDoc.update({'amountAssigned': punishment.amountAssigned + 1});
  }

  static Future<void> decrementPunishment(
      PunishmentsModel punishment, DocumentReference punishmentDoc,) async {
    if (punishment.amountAssigned > 0) {
      await punishmentDoc.update({'amountAssigned': punishment.amountAssigned - 1});
    }
  }
}

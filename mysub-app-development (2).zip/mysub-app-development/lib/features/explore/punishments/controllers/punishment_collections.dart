import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fpdart/fpdart.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:logger/logger.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/logger/logger.dart';

class PunishmentCollections {
  static final Logger _logger = MySubLogger.getLogger((PunishmentCollections).toString());

  static Future<CollectionReference?> fetchPunishmentsCollection(WidgetRef ref) async {
    try {
      final optionalUser = ref.read(userProvider);
      final user = optionalUser.getOrElse(() => throw Exception("User not found"));
      final DocumentReference userDoc = FirebaseFirestore.instance.collection('users').doc(user.uid);

      final snapshot = await userDoc.get();
      final data = snapshot.data() as Map<String, dynamic>?;
      final activePartner = data?['activePartner'] as Map<String, dynamic>? ?? {};
      final activeFriendshipID = activePartner['activeFriendshipID'] as String? ?? 'solo';

      if (activeFriendshipID.isEmpty) {
        throw Exception("Invalid activeFriendshipID: Cannot be empty");
      }

      if (activeFriendshipID == 'solo') {
        return FirebaseFirestore.instance.collection('users/${user.uid}/solo/punishments/assigned');
      } else {
        return FirebaseFirestore.instance.collection('friendships/$activeFriendshipID/explore/punishments/assigned');
      }
    } catch (e) {
      _logger.e('Error fetching punishments collection: $e');
      return null;
    }
  }

  static Future<void> createCollectionIfNotExists() async {
    try {
    } catch (e) {
      _logger.e('Error creating collection path: $e');
    }
  }
}

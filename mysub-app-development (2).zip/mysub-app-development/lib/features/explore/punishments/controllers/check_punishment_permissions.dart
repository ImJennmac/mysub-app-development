import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fpdart/fpdart.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:logger/logger.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/logger/logger.dart';

class CheckPunishmentPermissions {
  static final Logger _logger = MySubLogger.getLogger((CheckPunishmentPermissions).toString());

  static Future<bool> _checkPermission(WidgetRef ref, String permissionKey) async {
    try {
      final optionalUser = ref.read(userProvider);
      final user = optionalUser.getOrElse(() => throw Exception("User not found"));
      final userDoc = FirebaseFirestore.instance.collection('users').doc(user.uid);

      final snapshot = await userDoc.get();
      final data = snapshot.data();
      if (data == null) {
        throw Exception("User data not found");
      }

      // Get the active partner data, including activeDynamic and activeFriendshipID
      final activePartner = data['activePartner'] as Map<String, dynamic>? ?? {};
      final activeDynamic = activePartner['activeDynamic'] as String? ?? 'Submissive';
      final activeFriendshipID = activePartner['activeFriendshipID'] as String? ?? 'solo';

      _logger.d('Active partner data: $activePartner');
      _logger.d('Active dynamic: $activeDynamic');
      _logger.d('Active friendship ID: $activeFriendshipID');

      // If the user is in the Dominant role for this partnership, grant all permissions
      if (activeDynamic == 'Dominant') {
        _logger.d('User is Dominant in this partnership, granting all permissions');
        return true;
      }

      // If the user is not Dominant, proceed to check specific permissions in Firestore
      if (activeFriendshipID == 'solo') {
        _logger.d('No active partner, granting permissions by default');
        return true;
      }

      // Fetch specific permissions based on activeFriendshipID
      final partnerPermissions = data['partnerPermissions'] as Map<String, dynamic>? ?? {};
      final friendshipPermissions = partnerPermissions[activeFriendshipID] as Map<String, dynamic>? ?? {};

      _logger.d('Permissions for friendship ID $activeFriendshipID: $friendshipPermissions');

      final permissionGranted = friendshipPermissions[permissionKey] as bool? ?? false;
      _logger.d('Permission check for $permissionKey: $permissionGranted');

      return permissionGranted;
    } catch (e) {
      _logger.e('Error checking permission $permissionKey: $e');
      return false;
    }
  }

  static Future<bool> checkCreatePunishmentsPermission(WidgetRef ref) async {
    return _checkPermission(ref, 'Create new Punishments');
  }

  static Future<bool> checkEditDeletePunishmentsPermission(WidgetRef ref) async {
    return _checkPermission(ref, 'Edit and Delete existing Punishments');
  }

  static Future<bool> checkManuallyAddRemovePunishmentsPermission(WidgetRef ref) async {
    return _checkPermission(ref, 'Manually add or remove Punishments');
  }

  static Future<bool> checkCompletePunishmentsPermission(WidgetRef ref) async {
    return _checkPermission(ref, 'Complete Punishments');
  }
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:logger/logger.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/button/homebutton.dart';
import 'package:mysub/common/util/button/plusbutton.dart';
import 'package:mysub/common/util/logger/logger.dart';
import 'package:mysub/common/util/navbar/navbar.dart';
import 'package:mysub/features/explore/punishments/controllers/check_punishment_permissions.dart';
import 'package:mysub/features/explore/punishments/controllers/punishment_collections.dart';
import 'package:mysub/features/explore/punishments/controllers/punishment_counter.dart';
import 'package:mysub/features/explore/punishments/model/punishments_model.dart';
import 'package:mysub/features/explore/punishments/pages/all_punishment_history.dart';
import 'package:mysub/features/explore/punishments/widgets/punishment_card.dart';
import 'package:mysub/features/explore/punishments/widgets/punishment_screen.dart';

class PunishmentsView extends ConsumerStatefulWidget {
  static const String id = "punishments_view";
  const PunishmentsView({super.key});

  @override
  ConsumerState<PunishmentsView> createState() => _PunishmentsViewState();
}

class _PunishmentsViewState extends ConsumerState<PunishmentsView> {
  CollectionReference? myPunishments;
  bool isLoading = true;
  bool canCreatePunishments = false;

  final Logger _logger = MySubLogger.getLogger((PunishmentsView).toString());

  @override
  void initState() {
    super.initState();
    initializePunishmentsView();
  }

  Future<void> initializePunishmentsView() async {
    await fetchPunishmentsCollection();
    await checkCreatePunishmentsPermission();
  }

  Future<void> fetchPunishmentsCollection() async {
    try {
      myPunishments = await PunishmentCollections.fetchPunishmentsCollection(ref);
      setState(() {
        isLoading = false;
      });
    } catch (e) {
      _logger.e('Error fetching punishments collection: $e');
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> checkCreatePunishmentsPermission() async {
    try {
      canCreatePunishments = await CheckPunishmentPermissions.checkCreatePunishmentsPermission(ref);
      setState(() {});
    } catch (e) {
      _logger.e('Error checking create punishments permission: $e');
      setState(() {
        canCreatePunishments = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final optionalUser = ref.watch(userProvider);
    final theme = Theme.of(context);

    return optionalUser.match(
          () => const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      ),
          (user) {
        if (isLoading || myPunishments == null) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }

        return Scaffold(
          body: SafeArea(
            child: Padding(
              padding:
              const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const HomeButton(),
                      Text(
                        "Punishments",
                        style: theme.textTheme.displayLarge,
                      ),
                      if (canCreatePunishments)
                        PlusButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => PunishmentScreen(
                                  punishment: PunishmentsModel(
                                    id: '',
                                    title: '',
                                    description: '',
                                    enabled: false,
                                    amountAssigned: 0,
                                  ),
                                  canEdit: true,
                                ),
                              ),
                            );
                          },
                        )
                      else
                        const SizedBox(width: 48),
                    ],
                  ),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () {
                      Navigator.pushNamed(context, PunishmentHistory.id);
                    },
                    child: Container(
                      width: double.infinity,
                      height: 75,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15.0),
                        color: theme.cardColor,
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(10),
                        child: Stack(
                          children: [
                            Align(
                              alignment: Alignment.topLeft,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Punishment History",
                                    style: theme.textTheme.displayMedium,
                                  ),
                                  const SizedBox(height: 5),
                                  Text(
                                    "View your completed punishments",
                                    style: theme.textTheme.bodySmall,
                                  ),
                                ],
                              ),
                            ),
                            Positioned(
                              top: 0,
                              right: 0,
                              child: Text(
                                "See History",
                                style: theme.textTheme.displaySmall,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Expanded(
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15.0),
                        color: theme.cardColor,
                      ),
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Punishments",
                            style: theme.textTheme.bodyLarge,
                          ),
                          const SizedBox(height: 5),
                          Expanded(
                            child: StreamBuilder<QuerySnapshot>(
                              stream: myPunishments!.snapshots(),
                              builder: (context, snapshot) {
                                if (!snapshot.hasData) {
                                  return const Center(
                                    child: CircularProgressIndicator(),
                                  );
                                }
                                final punishments = snapshot.data!.docs;
                                if (punishments.isEmpty) {
                                  return Center(
                                    child: Text(
                                      "No punishments to complete.",
                                      style: theme.textTheme.bodyMedium,
                                    ),
                                  );
                                }
                                final List<PunishmentCard> punishmentCards =
                                punishments.map((punishment) {
                                  final data =
                                  punishment.data()! as Map<String, dynamic>;
                                  final punishmentObject = PunishmentsModel(
                                    id: punishment.id,
                                    title: data['title'] as String? ?? "",
                                    description:
                                    data['description'] as String? ?? "",
                                    enabled: data['enabled'] as bool? ?? false,
                                    amountAssigned:
                                    data['amountAssigned'] as int? ?? 0,
                                  );
                                  return PunishmentCard(
                                    punishment: punishmentObject,
                                    onPressed: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => PunishmentScreen(
                                            punishment: punishmentObject,
                                            canEdit: canCreatePunishments,
                                          ),
                                        ),
                                      );
                                    },
                                    onComplete: () => PunishmentCounterController.completePunishment(
                                        punishmentObject, punishment.reference, context,),
                                    onIncrement: () => PunishmentCounterController.incrementPunishment(
                                        punishmentObject, punishment.reference,),
                                    onDecrement: () => PunishmentCounterController.decrementPunishment(
                                        punishmentObject, punishment.reference,),
                                  );
                                }).toList();
                                return ListView.builder(
                                  itemCount: punishmentCards.length,
                                  itemBuilder: (context, index) {
                                    return punishmentCards[index];
                                  },
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          bottomNavigationBar: const NavBar(),
        );
      },
    );
  }
}

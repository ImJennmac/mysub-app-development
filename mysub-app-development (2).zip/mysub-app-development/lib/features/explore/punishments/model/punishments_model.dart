class PunishmentsModel {
  String id;
  String title;
  String description;
  bool enabled;
  int amountAssigned;

  PunishmentsModel({
    required this.id,
    required this.title,
    required this.description,
    required this.enabled,
    required this.amountAssigned,
  });
}

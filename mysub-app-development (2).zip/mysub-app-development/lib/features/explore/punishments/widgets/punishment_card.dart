import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/features/explore/punishments/controllers/check_punishment_permissions.dart';
import 'package:mysub/features/explore/punishments/model/punishments_model.dart';

class PunishmentCard extends ConsumerWidget {
  final PunishmentsModel punishment;
  final VoidCallback onPressed;
  final VoidCallback onComplete;
  final VoidCallback onIncrement;
  final VoidCallback onDecrement;

  const PunishmentCard({
    super.key,
    required this.punishment,
    required this.onPressed,
    required this.onComplete,
    required this.onIncrement,
    required this.onDecrement,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);

    return Card(
      color: theme.colorScheme.surface.withOpacity(1),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15.0),
      ),
      margin: const EdgeInsets.symmetric(vertical: 5.0),
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(15.0),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                punishment.title,
                style: theme.textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 8),
              Text(
                punishment.description,
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.textTheme.bodySmall?.color?.withOpacity(0.8),
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.remove),
                        onPressed: () async {
                          final scaffoldMessenger = ScaffoldMessenger.of(context);

                          if (await CheckPunishmentPermissions.checkManuallyAddRemovePunishmentsPermission(ref)) {
                            onDecrement();
                          } else {
                            scaffoldMessenger.showSnackBar(
                              const SnackBar(content: Text('You do not have permission to remove punishments')),
                            );
                          }
                        },
                        splashRadius: 20.0,
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10.0,
                          vertical: 8.0,
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8.0),
                          color: theme.colorScheme.surfaceContainerHighest,
                        ),
                        child: Text(
                          '${punishment.amountAssigned}',
                          style: theme.textTheme.titleSmall,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.add),
                        onPressed: () async {
                          final scaffoldMessenger = ScaffoldMessenger.of(context);

                          if (await CheckPunishmentPermissions.checkManuallyAddRemovePunishmentsPermission(ref)) {
                            onIncrement();
                          } else {
                            scaffoldMessenger.showSnackBar(
                              const SnackBar(content: Text('You do not have permission to add punishments')),
                            );
                          }
                        },
                        splashRadius: 20.0,
                      ),
                    ],
                  ),
                  SizedBox(
                    width: 175,
                    child: ElevatedButton(
                      onPressed: () async {
                        final scaffoldMessenger = ScaffoldMessenger.of(context);

                        if (await CheckPunishmentPermissions.checkCompletePunishmentsPermission(ref)) {
                          onComplete();
                        } else {
                          scaffoldMessenger.showSnackBar(
                            const SnackBar(content: Text('You do not have permission to complete punishments')),
                          );
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        backgroundColor: theme.colorScheme.primary,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12.0,
                          vertical: 10.0,
                        ),
                      ),
                      child: Text(
                        'Complete',
                        style: theme.textTheme.labelLarge?.copyWith(
                          color: theme.colorScheme.onPrimary,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

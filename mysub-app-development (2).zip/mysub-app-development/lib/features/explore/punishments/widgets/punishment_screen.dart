import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fpdart/fpdart.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:logger/logger.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/button/backarrow.dart';
import 'package:mysub/common/util/button/large_bin_button.dart';
import 'package:mysub/common/util/button/savebutton.dart';
import 'package:mysub/common/util/logger/logger.dart';
import 'package:mysub/features/explore/punishments/controllers/check_punishment_permissions.dart';
import 'package:mysub/features/explore/punishments/model/punishments_model.dart';

class PunishmentScreen extends ConsumerStatefulWidget {
  final PunishmentsModel punishment;
  final bool canEdit;

  const PunishmentScreen({
    super.key,
    required this.punishment,
    required this.canEdit,
  });

  @override
  ConsumerState<PunishmentScreen> createState() => _PunishmentScreenState();
}

class _PunishmentScreenState extends ConsumerState<PunishmentScreen> {
  late PunishmentsModel punishment;
  String titleString = '';
  String descriptionString = '';
  bool enabled = false;
  int amountAssigned = 0;

  late TextEditingController titleController;
  late TextEditingController descriptionController;
  late TextEditingController amountAssignedController;
  final ValueNotifier<String?> errorMessageNotifier = ValueNotifier<String?>(null);

  CollectionReference? myPunishments;
  bool isLoading = true;
  bool canEditDelete = false;

  final Logger _logger = MySubLogger.getLogger((PunishmentScreen).toString());

  @override
  void initState() {
    super.initState();
    punishment = widget.punishment;
    titleString = punishment.title;
    descriptionString = punishment.description;
    enabled = punishment.enabled;
    amountAssigned = punishment.amountAssigned;

    titleController = TextEditingController(text: titleString);
    descriptionController = TextEditingController(text: descriptionString);
    amountAssignedController = TextEditingController(text: amountAssigned.toString());

    fetchPunishmentsCollection();
    checkEditDeletePermission();

    titleController.addListener(() {
      if (titleController.text.length > 30) {
        errorMessageNotifier.value = 'Title cannot exceed 30 characters';
      } else {
        errorMessageNotifier.value = null;
      }
    });
  }

  Future<void> checkEditDeletePermission() async {
    canEditDelete = await CheckPunishmentPermissions.checkEditDeletePunishmentsPermission(ref);
    setState(() {});
  }

  Future<void> fetchPunishmentsCollection() async {
    try {
      final optionalUser = ref.read(userProvider);
      final user =
      optionalUser.getOrElse(() => throw Exception("User not found"));
      final DocumentReference userDoc =
      FirebaseFirestore.instance.collection('users').doc(user.uid);

      final snapshot = await userDoc.get();
      final data = snapshot.data() as Map<String, dynamic>?;
      final activePartner =
          data?['activePartner'] as Map<String, dynamic>? ?? {};
      final activeFriendshipID =
          activePartner['activeFriendshipID'] as String? ?? 'solo';

      if (activeFriendshipID == 'solo') {
        myPunishments = FirebaseFirestore.instance
            .collection('users/${user.uid}/solo/punishments/assigned');
      } else {
        myPunishments = FirebaseFirestore.instance
            .collection('friendships/$activeFriendshipID/explore/punishments/assigned');
      }

      await createCollectionIfNotExists();

      setState(() {
        isLoading = false;
      });
    } catch (e) {
      _logger.e('Error fetching punishments collection: $e');
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> createCollectionIfNotExists() async {
    try {
      // Add logic here if needed to create the collection
    } catch (e) {
      _logger.e('Error creating collection path: $e');
    }
  }

  @override
  void dispose() {
    titleController.dispose();
    descriptionController.dispose();
    amountAssignedController.dispose();
    errorMessageNotifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    if (isLoading || myPunishments == null) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const BackArrow(),
                  Expanded(
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        TextField(
                          controller: titleController,
                          textAlign: TextAlign.center,
                          readOnly: !canEditDelete,
                          inputFormatters: [
                            LengthLimitingTextInputFormatter(30),
                          ],
                          decoration: const InputDecoration(
                            border: InputBorder.none,
                            focusedBorder: InputBorder.none,
                            enabledBorder: InputBorder.none,
                            hintText: "Punishment Title",
                            hintStyle: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 20,
                            ),
                          ),
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                          ),
                          onChanged: (value) {
                            setState(() {
                              titleString = value;
                            });
                          },
                        ),
                      ],
                    ),
                  ),
                  if (canEditDelete)
                    SaveButton(
                      onPressed: () {
                        if (validateAndSavePunishment()) {
                          Navigator.pop(context);
                        }
                      },
                    )
                  else
                    const SizedBox(width: 48),
                ],
              ),
              const SizedBox(height: 20),
              ValueListenableBuilder<String?>(
                valueListenable: errorMessageNotifier,
                builder: (context, errorMessage, child) {
                  return errorMessage != null
                      ? Text(
                    errorMessage,
                    style: const TextStyle(color: Colors.red),
                  )
                      : const SizedBox.shrink();
                },
              ),
              const SizedBox(height: 20),
              Expanded(
                child: ListView(
                  children: [
                    const Text(
                      "Description",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(
                        color: theme.cardColor,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      margin: const EdgeInsets.only(bottom: 20),
                      height: 200,
                      child: TextField(
                        controller: descriptionController,
                        maxLines: null,
                        expands: true,
                        readOnly: !widget.canEdit,
                        decoration: const InputDecoration(
                          border: InputBorder.none,
                          focusedBorder: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          hintText: "Punishment Description",
                        ),
                        onChanged: (value) {
                          descriptionString = value;
                        },
                      ),
                    ),
                    const Text(
                      "Amount Assigned",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(
                        color: theme.cardColor,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      padding: const EdgeInsets.all(8.0),
                      margin: const EdgeInsets.only(bottom: 20),
                      child: Row(
                        children: [
                          IconButton(
                            icon: const Icon(Icons.remove),
                            onPressed: widget.canEdit
                                ? () {
                              setState(() {
                                if (amountAssigned > 0) amountAssigned--;
                                amountAssignedController.text =
                                    amountAssigned.toString();
                              });
                            }
                                : null,
                          ),
                          Expanded(
                            child: TextField(
                              controller: amountAssignedController,
                              keyboardType: TextInputType.number,
                              textAlign: TextAlign.center,
                              readOnly: !widget.canEdit,
                              decoration: const InputDecoration(
                                border: InputBorder.none,
                                focusedBorder: InputBorder.none,
                                enabledBorder: InputBorder.none,
                                hintText: "Amount Assigned",
                              ),
                              onChanged: (value) {
                                amountAssigned = int.tryParse(value) ?? 0;
                              },
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.add),
                            onPressed: widget.canEdit
                                ? () {
                              setState(() {
                                amountAssigned++;
                                amountAssignedController.text =
                                    amountAssigned.toString();
                              });
                            }
                                : null,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              if (punishment.id.isNotEmpty && widget.canEdit)
                LargeBinButton(
                  onPressed: () {
                    myPunishments!.doc(punishment.id).delete();
                    Navigator.pop(context);
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }

  bool validateAndSavePunishment() {
    if (!canEditDelete) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('You do not have permission to edit punishments'),
        ),
      );
      return false;
    }

    if (titleString.isEmpty || descriptionString.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Both title and description must be filled out'),),
      );
      return false;
    }

    if (titleString.length > 30) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Title cannot exceed 30 characters')),
      );
      return false;
    }

    savePunishment();
    return true;
  }

  Future<void> savePunishment() async {
    if (!canEditDelete) {
      return;
    }

    final punishmentData = {
      'title': titleString,
      'description': descriptionString,
      'enabled': enabled,
      'amountAssigned': amountAssigned,
    };

    if (punishment.id.isEmpty) {
      await myPunishments!.add(punishmentData);
    } else {
      await myPunishments!.doc(punishment.id).update(punishmentData);
    }
  }
}

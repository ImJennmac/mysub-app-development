import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/button/backarrow.dart';

class PunishmentHistory extends ConsumerStatefulWidget {
  static const String id = "punishmenthistory";
  const PunishmentHistory({super.key});

  @override
  ConsumerState<PunishmentHistory> createState() => _PunishmentHistoryState();
}

class _PunishmentHistoryState extends ConsumerState<PunishmentHistory> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final optionalUser = ref.watch(userProvider);
    final theme = Theme.of(context);

    return optionalUser.match(
          () => const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      ),
          (user) {
        return Scaffold(
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const BackArrow(),
                      Expanded(
                        child: Center(
                          child: Text(
                            "Punishment History",
                            style: theme.textTheme.titleMedium,
                          ),
                        ),
                      ),
                      const SizedBox(width: 48),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Text(
                    "Here is your Punishment History!",
                    style: theme.textTheme.displayMedium,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/assets.dart';
import 'package:mysub/common/util/button/small_box_arrow.dart';
import 'package:mysub/common/util/navbar/navbar.dart';
import 'package:mysub/features/explore/habits/habits_view.dart';
import 'package:mysub/features/explore/notes/noteshome_view.dart';
import 'package:mysub/features/explore/rewards/rewards_view.dart';
import 'package:mysub/features/explore/rewards/widgets/integrated_points.dart';
import 'package:mysub/features/homepage/profile/profile_view.dart';
import 'package:mysub/features/homepage/settings/settings_view.dart';
import 'package:mysub/features/homepage/settings/widgets/avatar.dart';

class HomeView extends ConsumerStatefulWidget {
  static const String id = "home";
  const HomeView({super.key});

  @override
  ConsumerState<HomeView> createState() => _HomeViewState();
}

final activePartnerProvider = StreamProvider.family<Map<String, dynamic>, String>((ref, userId) {
  return FirebaseFirestore.instance
      .collection('users')
      .doc(userId)
      .snapshots()
      .map((snapshot) {
    final data = snapshot.data();

    // Explicitly typecast 'activePartner' and 'acceptedFriends'
    final Map<String, dynamic>? activePartner = data?['activePartner'] as Map<String, dynamic>?;
    final List<Map<String, dynamic>> acceptedFriends =
    (data?['acceptedFriends'] as List<dynamic>? ?? [])
        .map((e) => e as Map<String, dynamic>)
        .toList();

    if (activePartner == null) {
      return {'status': 'Unknown'};
    }

    final activeDynamic = activePartner['activeDynamic'] as String? ?? 'Unknown';

    if (activePartner['activeUser'] == 'solo') {
      return {
        'status': 'Solo',
        'activeDynamic': 'No partner selected',
      };
    }

    // Find the active friend in 'acceptedFriends' list
    final Map<String, dynamic> activeFriend = acceptedFriends.firstWhere(
          (Map<String, dynamic> friend) => friend['ID'] == activePartner['activeUser'],
      orElse: () => <String, dynamic>{}, // Return empty map if not found
    );

    if (activeFriend.isNotEmpty) {
      return {
        'status': 'Partner',
        'partnerName': activeFriend['username'],
        'activeDynamic': activeDynamic,
      };
    }

    return {'status': 'Unknown', 'activeDynamic': activeDynamic};
  });
});

class _HomeViewState extends ConsumerState<HomeView> {
  String getFormattedDate() {
    final DateTime now = DateTime.now();
    final DateFormat formatter = DateFormat('EEE d MMM yyyy');
    return formatter.format(now);
  }

  @override
  Widget build(BuildContext context) {
    final optionalUser = ref.watch(userProvider);
    final theme = Theme.of(context);

    return optionalUser.match(
          () => Scaffold(
        body: Center(
          child: Text("User not found", style: theme.textTheme.titleLarge),
        ),
      ),
          (user) {
        final activePartnerAsync = ref.watch(activePartnerProvider(user.uid));

        return Scaffold(
          body: SafeArea(
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            const Avatar(),
                            const SizedBox(width: 15),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                RichText(
                                  text: TextSpan(
                                    children: [
                                      TextSpan(
                                        text: "Hello, ",
                                        style: theme.textTheme.titleSmall,
                                      ),
                                      TextSpan(
                                        text: user.fullName.value,
                                        style: theme.textTheme.titleSmall?.copyWith(
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Text(
                                  getFormattedDate(),
                                  style: theme.textTheme.displayMedium?.copyWith(),
                                ),
                              ],
                            ),
                          ],
                        ),
                        IconButton(
                          icon: ImageIcon(
                            const AssetImage(kSettingsIcon),
                            color: Theme.of(context).textTheme.displayMedium?.color,
                          ),
                          onPressed: () {
                            Navigator.pushNamed(context, SettingsView.id);
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 30),
                    activePartnerAsync.when(
                      data: (partnerData) {
                        String display;
                        switch (partnerData['status']) {
                          case 'Solo':
                            display = "Solo - ${partnerData['activeDynamic']}";
                          case 'Partner':
                            display = "${partnerData['partnerName']} - ${partnerData['activeDynamic']}";
                          default:
                            display = "Unknown status - ${partnerData['activeDynamic']}";
                        }
                        display = display[0].toUpperCase() + display.substring(1);
                        return Container(
                          width: double.infinity,
                          height: 80,
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Color(0xFFEC1942), Color(0xFFEC1942), Color(0xFFEC1942)],
                              begin: Alignment.bottomLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 16),
                                child: Text(
                                  display,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.change_circle, color: Colors.white),
                                onPressed: () {
                                  Navigator.pushNamed(context, ProfileView.id);
                                },
                              ),
                            ],
                          ),
                        );
                      },
                      error: (error, stackTrace) => Text('Error: $error'),
                      loading: () => const CircularProgressIndicator(),
                    ),
                    const SizedBox(height: 30),
                    Stack(
                      children: [
                        Container(
                          width: double.infinity,
                          height: 250,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15.0),
                            color: Theme.of(context).cardColor,
                          ),
                        ),
                        Positioned(
                          top: 10,
                          left: 10,
                          right: 10,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Today's Tasks",
                                    style: theme.textTheme.displayLarge,
                                  ),
                                  Text(
                                    "Completed Habits",
                                    style: theme.textTheme.bodySmall?.copyWith(),
                                  ),
                                ],
                              ),
                              GestureDetector(
                                onTap: () {
                                  Navigator.pushNamed(context, HabitsView.id);
                                },
                                child: Text(
                                  "See all",
                                  style: theme.textTheme.bodyMedium?.copyWith(),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 30),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Stack(
                            children: [
                              Container(
                                height: 175,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15.0),
                                  color: theme.cardColor,
                                ),
                              ),
                              Positioned(
                                top: 10,
                                left: 10,
                                right: 10,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Total Points",
                                                style: theme.textTheme.displayLarge,
                                                overflow: TextOverflow.ellipsis,
                                                maxLines: 2,
                                              ),
                                              Text(
                                                "Your current points",
                                                style: theme.textTheme.bodySmall,
                                                overflow: TextOverflow.ellipsis,
                                                maxLines: 2,
                                              ),
                                            ],
                                          ),
                                        ),
                                        SmalLBoxArrow(
                                          onTap: () {
                                            Navigator.pushNamed(context, RewardsView.id);
                                          },
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 10),
                                    Center(
                                      child: IntegratedPointsDisplayCounter(
                                        textStyle: theme.textTheme.displayLarge,
                                        showButtons: false,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 15),
                        Expanded(
                          child: Stack(
                            children: [
                              Container(
                                height: 175,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15.0),
                                  color: theme.cardColor,
                                ),
                              ),
                              Positioned(
                                top: 10,
                                left: 10,
                                right: 10,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Notes",
                                            style: theme.textTheme.displayLarge,
                                            overflow: TextOverflow.ellipsis,
                                            maxLines: 2,
                                          ),
                                          Text(
                                            "View and change your notes, limits and rules here!",
                                            style: theme.textTheme.bodySmall,
                                            maxLines: 5,
                                          ),
                                        ],
                                      ),
                                    ),
                                    SmalLBoxArrow(
                                      onTap: () {
                                        Navigator.pushNamed(context, NotesHomeView.id);
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          bottomNavigationBar: const NavBar(),
        );
      },
    );
  }
}

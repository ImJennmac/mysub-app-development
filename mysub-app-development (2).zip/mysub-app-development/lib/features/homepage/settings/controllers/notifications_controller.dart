import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fpdart/fpdart.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:logger/logger.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/logger/logger.dart';

Logger _logger = MySubLogger.getLogger('NotificationSettings');

Future<Map<String, bool>> loadNotificationSettings(WidgetRef ref) async {
  final Map<String, bool> settings = {
    'Daily reminders': false,
    'Partner activity': false,
    'Achievement alerts': false,
    'Rule updates': false,
  };

  try {
    final optionalUser = ref.read(userProvider);
    final user = optionalUser.getOrElse(() => throw Exception("User not found"));
    final userDoc = FirebaseFirestore.instance.collection('users').doc(user.uid);
    final doc = await userDoc.get();

    if (doc.exists) {
      final data = doc.data()!;
      final notificationSettings = data['notificationSettings'] as Map<String, dynamic>? ?? {};

      for (final setting in settings.keys) {
        settings[setting] = notificationSettings[setting] == true;
      }
    }

    _logger.d('Notification settings loaded successfully');
  } catch (e) {
    _logger.e('Error loading notification settings: $e');
  }

  return settings;
}

Future<String> updateNotificationSettings(WidgetRef ref, Map<String, bool> settings) async {
  try {
    final optionalUser = ref.read(userProvider);
    final user = optionalUser.getOrElse(() => throw Exception("User not found"));
    final userDoc = FirebaseFirestore.instance.collection('users').doc(user.uid);

    await userDoc.update({
      'notificationSettings': settings,
    });

    _logger.d('Notification settings updated successfully');
    return 'Notification settings updated successfully!';
  } catch (e) {
    _logger.e('Error updating notification settings: $e');
    return 'Failed to update notification settings: $e';
  }
}

import 'package:flutter/material.dart';
import 'package:fpdart/fpdart.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/value/value_checker.dart';
import 'package:mysub/features/homepage/settings/state/delete_account_state.dart';
import 'package:mysub/repositories/impl/auth_repository.dart';
import 'package:mysub/repositories/interface/auth_repository_facade.dart';

final deleteAccountControllerProvider =
    StateNotifierProvider.autoDispose<DeleteAccountController, DeleteAccountState>(
  (ref) {
    return DeleteAccountController(
      const DeleteAccountState(
        page: DeleteAccountStep.WARNING,
      ),
      auth: ref.read(authRepositoryProvider),
    );
  },
);

class DeleteAccountController extends StateNotifier<DeleteAccountState> {
  final IAuthRepositoryFacade _auth;

  DeleteAccountController(
    super._state, {
    required IAuthRepositoryFacade auth,
  }) : _auth = auth;

  void setPage(DeleteAccountStep page) {
    state = state.copyWith(page: page);
  }

  Future<void> tryDeleteAccount({
    required BuildContext ctx,
    required String password,
    required VoidCallback onSuccess,
    required Function(String) onError,
  }) async {
    final optionalPassword = ValueChecker.checkPassword(ctx, password);
    // Do not allow further processing if inputs are invalid
    if (optionalPassword.isNone()) {
      return;
    }
    state = state.copyWith(loading: true);
    final result =
        await _auth.validatePassword(optionalPassword.getOrElse(() => throw 'Password is invalid'));
    result.match(
      (err) => onError(err.description),
      (passwordConfirmed) async {
        if (!passwordConfirmed) {
          onError('Password is incorrect');
          state = state.copyWith(loading: false);
          return;
        }

        final deleted = await _auth.deleteAccount();
        deleted.match(
          (err) => {
            onError(err.description),
            state = state.copyWith(loading: false),
          },
          (success) {
            onSuccess();
            state = state.copyWith(loading: false);
          },
        );
      },
    );
  }
}

import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:logger/logger.dart';
import 'package:mysub/common/exceptions/backend_exception_mapping.dart';
import 'package:mysub/common/models/user_model.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/extensions.dart';
import 'package:mysub/common/util/helpers.dart';
import 'package:mysub/common/util/logger/logger.dart';
import 'package:mysub/common/value/email_address_value.dart';
import 'package:mysub/common/value/password_value.dart';
import 'package:mysub/repositories/impl/auth_repository.dart';
import 'package:mysub/repositories/impl/user_repository.dart';
import 'package:mysub/repositories/interface/auth_repository_facade.dart';

final settingsControllerProvider =
    StateNotifierProvider.autoDispose<SettingsController, LoadingState>(
  (ref) {
    return SettingsController(authInterface: ref.watch(authRepositoryProvider), ref: ref);
  },
  name: (SettingsController).toString(),
);

class LoadingState {
  final bool updatingEmail;
  final bool updatingDetails;

  LoadingState({required this.updatingEmail, required this.updatingDetails});

  const LoadingState.loadingEmail()
      : updatingEmail = true,
        updatingDetails = false;

  const LoadingState.loadingDetails()
      : updatingEmail = false,
        updatingDetails = true;

  const LoadingState.off()
      : updatingEmail = false,
        updatingDetails = false;
}

class SettingsController extends StateNotifier<LoadingState> {
  final IAuthRepositoryFacade _authInterface;
  final Ref _ref;
  SettingsController({
    required IAuthRepositoryFacade authInterface,
    required Ref ref,
  })  : _authInterface = authInterface,
        _ref = ref,
        super(LoadingState(updatingEmail: false, updatingDetails: false));
  static final Logger _logger = MySubLogger.getLogger((SettingsController).toString());

  Future<void> updatePassword({
    required String newPassword,
    required String newPasswordConfirm,
    required String oldPassword,
    required BuildContext context,
  }) async {
    if (newPassword != newPasswordConfirm) {
      return;
    }
    final oldPasswordOpt = PasswordValue(oldPassword);
    final newPasswordOpt = PasswordValue(newPassword);
    final navigator = Navigator.of(context);
    state = const LoadingState.loadingDetails();
    final result = await _authInterface.updatePasword(
      oldPassword: oldPasswordOpt,
      newPassword: newPasswordOpt,
    );
    state = const LoadingState.off();
    result.match(
      (error) {
        if (error != AuthError.unknown) {
          showErrorSnackbar(
            context: context,
            text: "Looks like the old password is not correct or your new password is invalid.",
          );
        }
      },
      (_) {
        showSnackbar(context: context, text: "Your password was updated!");
        navigator.pop();
        navigator.pop();
      },
    );
  }

  Future<(String, bool)> updateAuthEmail({
    required EmailAddressValue newEmail,
    required PasswordValue password,
    required BuildContext context,
  }) async {
    state = const LoadingState.loadingEmail();
    final result = await _authInterface.updateEmail(newEmail, password);
    state = const LoadingState.off();

    return result.match(
      (error) {
        if (error != AuthError.unknown) {
          return ("Looks like the password you've entered is incorrect.", false);
        } else {
          return (
            "An error occurred while updating your email. Try again in a few minutes.",
            false
          );
        }
      },
      (_) {
        return (
          "A confirmation email was sent to your new email address. Please verify your email to complete the process.",
          true
        );
      },
    );
  }

  Future<(String?, bool)> updateDB({
    required UserModel newUser,
    required BuildContext context,
  }) async {
    final cachedUser = _ref.read(userProvider).unwrap();

    if (cachedUser == newUser) {
      _logger.i("No changes were made to the user account.");
      return (null, false);
    }

    state = const LoadingState.loadingDetails();
    final result = await _ref.read(userRepositoryProvider).update(newUser);
    state = const LoadingState.off();
    return result.match(
      (e) {
        _logger.e("An error occurred while updating the user account: $e");
        return (
          "An error occurred while updating your account. Try again in a few minutes.",
          false
        );
      },
      (_) {
        _logger.i("The user account was successfully updated!");
        return ("Your account information was updated!", true);
      },
    );
  }
}

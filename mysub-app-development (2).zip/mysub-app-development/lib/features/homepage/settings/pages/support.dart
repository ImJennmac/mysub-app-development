import 'package:flutter/material.dart';
import 'package:mysub/common/util/button/backarrow.dart';
import 'package:mysub/common/util/helpers.dart';

class SupportPage extends StatelessWidget {
  static const String id = "support";
  const SupportPage({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textTheme = theme.textTheme;

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const BackArrow(),
                    Expanded(
                      child: Align(
                        child: Text(
                          "Support",
                          style: theme.textTheme.titleMedium,
                        ),
                      ),
                    ),
                    const SizedBox(width: 48),
                  ],
                ),
                const SizedBox(height: 40),
                Text(
                  "Contact us at:",
                  style: textTheme.bodyLarge,
                ),
                const SizedBox(height: 10),
                Text(
                  "support@mysubnsfw.com",
                  style: textTheme.bodyLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 40),
                Text(
                  "mysub",
                  style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),
                _buildListTile(
                  context,
                  Icons.question_answer,
                  "FAQ",
                  'https://example.com/faq',
                  theme,
                ),
                Divider(color: theme.dividerColor),
                const SizedBox(height: 40),
                Text(
                  "Our Apps",
                  style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),
                _buildListTile(
                  context,
                  Icons.photo,
                  "Photojar",
                  'https://photojarapp.com',
                  theme,
                ),
                Divider(color: theme.dividerColor),
                const SizedBox(height: 40),
                Text(
                  "Legal",
                  style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                _buildListTile(
                  context,
                  Icons.web,
                  "NSG Website",
                  'https://notsuitablegroup.com',
                  theme,
                ),
                Divider(color: theme.dividerColor),
                _buildListTile(
                  context,
                  Icons.description,
                  "Terms of Service (ToS)",
                  'https://example.com/tos',
                  theme,
                ),
                Divider(color: theme.dividerColor),
                _buildListTile(
                  context,
                  Icons.gavel,
                  "Legal",
                  'https://example.com/legal',
                  theme,
                ),
                Divider(color: theme.dividerColor),
                const SizedBox(height: 20),
                Center(
                  child: Text(
                    "mysub trading as notsuitable group",
                    style: textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildListTile(BuildContext context, IconData icon, String title, String url, ThemeData theme) {
    return ListTile(
      leading: Icon(icon, color: theme.iconTheme.color),
      title: Text(title, style: theme.textTheme.bodyLarge),
      onTap: () => launchBrowserWithUrl(context, url),
    );
  }
}

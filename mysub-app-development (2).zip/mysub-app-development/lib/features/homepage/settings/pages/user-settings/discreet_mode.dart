import 'package:flutter/material.dart';
import 'package:mysub/common/util/button/backarrow.dart';

class DiscreetModePage extends StatelessWidget {
  static const String id = "discreet_mode";
  const DiscreetModePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                children: [
                  BackArrow(),
                  Expanded(
                    child: Align(
                      child: Text(
                        "Discreet Mode",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.normal,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 48),
                ],
              ),
              const SizedBox(height: 40),
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    // Add discreet mode toggle functionality here
                  },
                  child: const Text("Toggle Discreet Mode"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/util/button/backarrow.dart';
import 'package:mysub/features/homepage/settings/controllers/notifications_controller.dart';

class NotificationsPage extends HookConsumerWidget {
  static const String id = "notifications";
  const NotificationsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const BackArrow(),
                  Expanded(
                    child: Align(
                      child: Text(
                        "Notifications",
                        style: theme.textTheme.titleMedium,
                      ),
                    ),
                  ),
                  const SizedBox(width: 48),
                ],
              ),
              const SizedBox(height: 40),
              Expanded(
                child: FutureBuilder<Map<String, bool>>(
                  future: loadNotificationSettings(ref),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    } else if (snapshot.hasError) {
                      return Center(child: Text('Error: ${snapshot.error}'));
                    } else if (!snapshot.hasData) {
                      return const Center(child: Text('No data available'));
                    }

                    final settings = snapshot.data!;
                    return ListView(
                      children: settings.entries.map((entry) {
                        return SwitchListTile(
                          title: Text(entry.key),
                          value: entry.value,
                          onChanged: (bool value) async {
                            final scaffoldMessenger = ScaffoldMessenger.of(context);

                            final updatedSettings = Map<String, bool>.from(settings);
                            updatedSettings[entry.key] = value;

                            final result = await updateNotificationSettings(ref, updatedSettings);
                            scaffoldMessenger.showSnackBar(
                              SnackBar(content: Text(result)),
                            );
                          },
                        );
                      }).toList(),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

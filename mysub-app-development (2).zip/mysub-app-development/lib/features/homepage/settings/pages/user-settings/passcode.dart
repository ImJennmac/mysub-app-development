import 'package:flutter/material.dart';
import 'package:mysub/common/util/button/backarrow.dart';

class PasscodePage extends StatelessWidget {
  static const String id = "passcode";
  const PasscodePage({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const BackArrow(),
                  Expanded(
                    child: Align(
                      child: Text(
                        "Passcode",
                        style: theme.textTheme.titleMedium,
                      ),
                    ),
                  ),
                  const SizedBox(width: 48),
                ],
              ),
              const SizedBox(height: 40),
              const Text(
                "Please note that the passcode is per-device, so regardless of who is logged in, the passcode will need to be entered.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey,
                ),
              ),
              const SizedBox(height: 20),
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    // Add passcode setup functionality here
                  },
                  child: const Text("Set Passcode"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

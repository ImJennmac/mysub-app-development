import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mysub/common/util/button/backarrow.dart';
import 'package:mysub/theme/theme_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ChangeThemePage extends ConsumerStatefulWidget {
  static const String id = "change_theme";
  const ChangeThemePage({super.key});

  @override
  ConsumerState<ChangeThemePage> createState() => _ChangeThemePageState();
}

class _ChangeThemePageState extends ConsumerState<ChangeThemePage> {
  ThemeMode _selectedTheme = ThemeMode.system;

  @override
  void initState() {
    super.initState();
    _loadSavedTheme();
  }

  Future<void> _loadSavedTheme() async {
    final prefs = await SharedPreferences.getInstance();
    final savedTheme = prefs.getString('theme') ?? 'system';
    setState(() {
      _selectedTheme = ThemeMode.values.firstWhere(
            (e) => e.toString() == 'ThemeMode.$savedTheme',
        orElse: () => ThemeMode.system,
      );
    });
    ref.read(themeProvider.notifier).theme = _selectedTheme;
  }

  Future<void> _saveTheme(ThemeMode mode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('theme', mode.toString().split('.').last);
  }

  void _changeTheme(ThemeMode? newTheme) {
    if (newTheme != null) {
      setState(() {
        _selectedTheme = newTheme;
      });
      ref.read(themeProvider.notifier).theme = newTheme;
      _saveTheme(newTheme);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const BackArrow(),
                  Expanded(
                    child: Align(
                      child: Text(
                        "Change Theme",
                        style: theme.textTheme.titleMedium,
                      ),
                    ),
                  ),
                  const SizedBox(width: 48),
                ],
              ),
              const SizedBox(height: 40),
              _buildThemeOption(theme, 'System Theme', ThemeMode.system),
              _buildThemeOption(theme, 'Light Theme', ThemeMode.light),
              _buildThemeOption(theme, 'Dark Theme', ThemeMode.dark),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildThemeOption(ThemeData theme, String title, ThemeMode mode) {
    return RadioListTile<ThemeMode>(
      title: Text(title, style: theme.textTheme.displayLarge),
      value: mode,
      groupValue: _selectedTheme,
      onChanged: _changeTheme,
      activeColor: theme.textTheme.displayLarge?.color,
    );
  }
}

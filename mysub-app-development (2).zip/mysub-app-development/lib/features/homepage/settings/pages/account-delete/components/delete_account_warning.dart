import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/util/assets.dart';
import 'package:mysub/features/homepage/settings/controllers/delete_account_controller.dart';
import 'package:mysub/features/homepage/settings/state/delete_account_state.dart';
import 'package:mysub/theme/styles.dart';

class DeleteAccountWarning extends ConsumerWidget {
  final VoidCallback? cb;
  const DeleteAccountWarning({
    VoidCallback? onContinue,
    super.key,
  }) : cb = onContinue;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Column(
      children: [
        const SizedBox(height: 50),
        SvgPicture.asset(kDepartingSvg),
        const SizedBox(
          height: 40,
        ),
        const Text(
          "We're sorry to see you go. ",
          // style: AppTheme.bodyMedium,
        ),
        const SizedBox(
          height: 40,
        ),
        const Text(
          "If you want to delete your account permanently, please press the button below to confirm your choice.",
          textAlign: TextAlign.justify,
        ),
        const SizedBox(
          height: 40,
        ),
        TextButton(
          style: kPrimaryTextButton,
          onPressed: () {
            cb?.call();
            ref.read(deleteAccountControllerProvider.notifier).setPage(DeleteAccountStep.DELETE);
          },
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: Text("Continue"),
          ),
        ),
      ],
    );
  }
}

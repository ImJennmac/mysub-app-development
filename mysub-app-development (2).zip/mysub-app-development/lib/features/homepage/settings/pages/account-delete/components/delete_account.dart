import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/util/helpers.dart';
import 'package:mysub/common/widgets/visibility_textfield.dart';
import 'package:mysub/features/auth/views/login_view.dart';
import 'package:mysub/features/homepage/settings/controllers/delete_account_controller.dart';
import 'package:mysub/theme/styles.dart';

class DeleteAccount extends HookConsumerWidget {
  const DeleteAccount({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final pw = useTextEditingController();
    final loading = ref.watch(deleteAccountControllerProvider.select((s) => s.loading));
    return Form(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Password",
          ),
          const SizedBox(
            height: 10,
          ),
          VisibilityTextfield(
            controller: pw,
          ),
          const SizedBox(
            height: 50,
          ),
          const Text(
            "For security reasons, we require you to enter your password. Once you enter your password, you will be forever lost. \n\nThis action is irreversable so please ensure this is what you want.",
            textAlign: TextAlign.justify,
          ),
          const SizedBox(
            height: 50,
          ),
          Center(
            child: SizedBox(
              width: 240,
              child: TextButton(
                style: kPrimaryTextButton,
                onPressed: () {
                  ref.read(deleteAccountControllerProvider.notifier).tryDeleteAccount(
                        ctx: context,
                        password: pw.text,
                        onError: (err) {
                          showErrorSnackbar(
                            context: context,
                            text: err,
                          );
                        },
                        onSuccess: () {
                          Navigator.of(context).pushNamedAndRemoveUntil(
                            LoginView.id,
                            (route) => false,
                          );
                        },
                      );
                },
                child: loading
                    ? const CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      )
                    : const Text("Delete Account"),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/widgets/terms_of_service.dart';
import 'package:mysub/features/homepage/settings/controllers/delete_account_controller.dart';
import 'package:mysub/features/homepage/settings/pages/account-delete/components/delete_account.dart';
import 'package:mysub/features/homepage/settings/pages/account-delete/components/delete_account_warning.dart';
import 'package:mysub/features/homepage/settings/state/delete_account_state.dart';

class DeleteAccountPage extends ConsumerStatefulWidget {
  static const String id = "delete_account";
  const DeleteAccountPage({super.key});

  @override
  ConsumerState<DeleteAccountPage> createState() => _DeleteAccountPageState();
}

class _DeleteAccountPageState extends ConsumerState<DeleteAccountPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _fadeController;
  late final Animation<double> _opacity;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 250),
    );
    _opacity = Tween(
      begin: 0.0,
      end: 1.0,
    ).animate(_fadeController);
    _fadeController.forward();
  }

  void doFadeAnimation() {
    _fadeController.forward(from: 0.0);
  }

  @override
  Widget build(BuildContext context) {
    final controller = ref.watch(deleteAccountControllerProvider);
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text("Delete Account"),
      ),
      body: Center(
        child: SizedBox(
          width: 320,
          child: FadeTransition(
            opacity: _opacity,
            child: ListView(
              children: [
                const SizedBox(
                  height: 40,
                ),
                if (controller.page == DeleteAccountStep.WARNING)
                  DeleteAccountWarning(
                    onContinue: () => {
                      doFadeAnimation(),
                    },
                  )
                else
                  const DeleteAccount(),
                const SizedBox(height: 50),
                const TermsOfService(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

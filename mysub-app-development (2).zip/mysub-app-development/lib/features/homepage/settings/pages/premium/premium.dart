import 'package:flutter/material.dart';
import 'package:mysub/common/util/button/backarrow.dart';
import 'package:mysub/common/util/button/custom_outline_button.dart';
import 'package:mysub/features/homepage/settings/pages/premium/plan_selector.dart';

class PremiumPage extends StatelessWidget {
  static const String id = "PremiumPage";
  const PremiumPage({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textTheme = theme.textTheme;

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const BackArrow(),
                  Expanded(
                    child: Align(
                      child: Text(
                        "mysub Premium",
                        style: theme.textTheme.titleMedium,
                      ),
                    ),
                  ),
                  const SizedBox(width: 48),
                ],
              ),
              const SizedBox(height: 40),

              Center(
                child: Text(
                  "Purchase premium now! Please note that both partners will require premium to be able to utilise all features",
                  style: textTheme.bodyLarge,
                  textAlign: TextAlign.center,
                ),
              ),

              const SizedBox(height: 40),

              Column(
                children: List.generate(6, (index) {
                  String featureTitle;
                  switch (index) {
                    case 0:
                      featureTitle = "Unlimited Punishments";
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                      featureTitle = "Unlimited Habits";
                    default:
                      featureTitle = "Feature Title $index";
                  }

                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: Row(
                      children: [
                        Icon(
                          Icons.star,
                          size: 40,
                          color: theme.colorScheme.primary,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                featureTitle,
                                style: textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                "Feature description here",
                                style: textTheme.bodyMedium,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                }),
              ),
              const Spacer(),
              Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  CustomOutlineButton(
                    text: "Restore Purchases",
                    onPressed: () {
                      // Your restore purchases logic here
                    },
                    isRedButton: true,
                  ),
                  const SizedBox(height: 30),
                  CustomOutlineButton(
                    text: "Continue",
                    onPressed: () {
                      Navigator.pushNamed(context, PremiumPlanPage.id);
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

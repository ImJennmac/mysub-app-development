import 'package:flutter/material.dart';
import 'package:mysub/common/util/button/backarrow.dart';
import 'package:mysub/common/util/button/custom_outline_button.dart';

class PremiumPlanPage extends StatefulWidget {
  static const String id = "PremiumPlanPage";
  const PremiumPlanPage({super.key});

  @override
  _PremiumPlanPageState createState() => _PremiumPlanPageState();
}

class _PremiumPlanPageState extends State<PremiumPlanPage> {
  String _selectedPlan = "Monthly";

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textTheme = theme.textTheme;

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const BackArrow(),
                  Expanded(
                    child: Align(
                      child: Text(
                        "mysub Plan Selector",
                        style: theme.textTheme.titleMedium,
                      ),
                    ),
                  ),
                  const SizedBox(width: 48),
                ],
              ),
              const SizedBox(height: 40),

              Center(
                child: Text(
                  "Choose your premium plan. Both partners will need a premium subscription to access all features.",
                  style: textTheme.bodyLarge,
                  textAlign: TextAlign.center,
                ),
              ),

              const SizedBox(height: 40),

              Expanded(
                child: ListView(
                  children: [
                    _buildPlanOption(
                      title: "Monthly",
                      price: "\$9.99",
                      discount: "",
                      isMostPopular: false,
                    ),
                    _buildPlanOption(
                      title: "Quarterly (3 months)",
                      price: "\$27.99",
                      discount: "Save 7%",
                      isMostPopular: false,
                    ),
                    _buildPlanOption(
                      title: "Semi-annually (6 months)",
                      price: "\$54.99",
                      discount: "Save 8%",
                      isMostPopular: true,  // Changed to true for this option
                    ),
                    _buildPlanOption(
                      title: "Annually (12 months)",
                      price: "\$99.99",
                      discount: "Save 17%",
                      isMostPopular: false,  // Changed to false for this option
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  CustomOutlineButton(
                    text: "Restore Purchases",
                    onPressed: () {
                      // Restore purchases logic here
                    },
                    isRedButton: true,
                  ),
                  const SizedBox(height: 30),
                  CustomOutlineButton(
                    text: "Purchase",
                    onPressed: () {
                      // Purchase logic using _selectedPlan
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPlanOption({
    required String title,
    required String price,
    required String discount,
    required bool isMostPopular,
  }) {
    final theme = Theme.of(context);
    final textTheme = theme.textTheme;
    final isSelected = _selectedPlan == title;

    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedPlan = title;
        });
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        decoration: BoxDecoration(
          border: Border.all(
            color: isSelected ? theme.colorScheme.primary : Colors.transparent,
            width: 2,
          ),
          borderRadius: BorderRadius.circular(8),
          color: isSelected ? theme.colorScheme.primary.withOpacity(0.1) : Colors.transparent,
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          title,
                          style: textTheme.displayMedium?.copyWith(fontWeight: FontWeight.bold),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (isMostPopular)
                        Container(
                          margin: const EdgeInsets.only(left: 4),
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: theme.colorScheme.secondary,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            "Most Popular",
                            style: textTheme.labelLarge?.copyWith(
                              color: theme.colorScheme.onSecondary,
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    price,
                    style: textTheme.bodyMedium,
                  ),
                  if (discount.isNotEmpty)
                    Text(
                      discount,
                      style: textTheme.bodySmall?.copyWith(color: theme.colorScheme.primary),
                    ),
                ],
              ),
            ),
            Icon(
              isSelected ? Icons.radio_button_checked : Icons.radio_button_unchecked,
              color: isSelected ? theme.colorScheme.primary : theme.unselectedWidgetColor,
            ),
          ],
        ),
      ),
    );
  }
}

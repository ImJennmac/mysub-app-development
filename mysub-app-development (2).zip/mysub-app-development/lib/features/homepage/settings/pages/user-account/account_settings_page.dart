import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/models/user_model.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/assets.dart';
import 'package:mysub/common/util/extensions.dart';
import 'package:mysub/common/util/helpers.dart';
import 'package:mysub/common/util/string_utils.dart';
import 'package:mysub/common/util/validator.dart';
import 'package:mysub/common/value/email_address_value.dart';
import 'package:mysub/common/value/name_value.dart';
import 'package:mysub/common/value/password_value.dart';
import 'package:mysub/common/value/username_value.dart';
import 'package:mysub/common/value/value_checker.dart';
import 'package:mysub/common/widgets/circular_dots_loading_indicator.dart';
import 'package:mysub/common/widgets/dialog.dart';
import 'package:mysub/features/auth/views/login_view.dart';
import 'package:mysub/features/homepage/settings/controllers/settings_controller.dart';
import 'package:mysub/features/homepage/settings/pages/user-account/password_settings_page.dart';
import 'package:mysub/features/homepage/settings/widgets/avatar.dart';
import 'package:mysub/features/homepage/settings/widgets/setting_scaffold.dart';
import 'package:mysub/features/homepage/settings/widgets/settings_tile.dart';
import 'package:mysub/repositories/impl/auth_repository.dart';
import 'package:mysub/theme/styles.dart';

class AccountSettingsPage extends StatefulHookConsumerWidget {
  const AccountSettingsPage({super.key});
  static const String id = "account_settings";

  static final formKey = GlobalKey<FormState>();

  @override
  ConsumerState<ConsumerStatefulWidget> createState() => _AccountSettingsPageState();
}

class _AccountSettingsPageState extends ConsumerState<AccountSettingsPage> {
  @override
  Widget build(BuildContext context) {
    const spacing = SizedBox(height: 20);

    final userModel = ref.watch(userProvider).unwrap();
    final auth = ref.watch(authRepositoryProvider);
    final username = useTextEditingController(text: userModel.usernameValue);
    final fullName = useTextEditingController(text: userModel.fullNameValue);
    final email = useTextEditingController(text: auth.currentUserEmail.unwrap());
    final birthDay = useTextEditingController(text: StringUtils.formatDate(userModel.birthDay));
    final currentPassword = useTextEditingController();

    return Form(
      key: AccountSettingsPage.formKey,
      child: SettingScaffold(
        title: "Account",
        content: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Center(
                child: Column(
                  children: [
                    SizedBox(width: 100, height: 100, child: Avatar()),
                    SizedBox(height: 10),
                  ],
                ),
              ),
              const Text("Username"),
              const SizedBox(height: 5),
              TextFormField(
                controller: username,
                validator: Validator.validateUsername,
              ),
              spacing,
              const Text("Display Name"),
              const SizedBox(height: 5),
              TextFormField(
                controller: fullName,
                validator: Validator.validateRealName,
              ),
              spacing,
              const Text("Email"),
              const SizedBox(height: 5),
              TextFormField(
                controller: email,
                keyboardType: TextInputType.emailAddress,
                validator: Validator.validateEmail,
              ),
              spacing,
              Row(
                children: <Widget>[
                  const Text('Date of birth'),
                  const Spacer(),
                  ImageIcon(const AssetImage(kLock), color: Theme.of(context).colorScheme.primary),
                ],
              ),
              const SizedBox(height: 5),
              TextFormField(
                readOnly: true,
                controller: birthDay,
              ),
              spacing,
              SettingsTile(
                title: "Change Password",
                icon: ImageIcon(const AssetImage(kPassword), color: Theme.of(context).colorScheme.primary),
                tapHandler: () => Navigator.pushNamed(context, PasswordSettingsPage.id),
              ),
              spacing,
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  style: kPrimaryTextButton,
                  onPressed: () {
                    if (AccountSettingsPage.formKey.currentState!.validate()) {
                      final UserModel newUserData = UserModel(
                        id: userModel.id,
                        username: UsernameValue(username.text),
                        fullName: NameValue(fullName.text),
                        position: userModel.position,
                        birthDay: userModel.birthDay,
                      );

                      if (email.text == auth.currentUserEmail.unwrap()) {
                        updateAccount(
                          newUserData: newUserData,
                          context: context,
                          onSuccess: () {
                            Navigator.pop(context);
                          },
                        );
                      } else {
                        showUpdateEmailModal(
                          context: context,
                          passwordController: currentPassword,
                          onConfirm: (pass) async {
                            await updateEmail(
                              newEmail: EmailAddressValue(email.text),
                              context: context,
                              password: pass,
                              onSuccess: () {
                                updateAccount(
                                  newUserData: newUserData,
                                  context: context,
                                );

                                Navigator.pushNamedAndRemoveUntil(
                                  context,
                                  LoginView.id,
                                  (_) => false,
                                );
                              },
                            );
                          },
                        );
                      }
                    }
                  },
                  child: const Text("Save Changes"),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> updateEmail({
    required EmailAddressValue newEmail,
    required BuildContext context,
    required PasswordValue password,
    required VoidCallback onSuccess,
  }) async {
    final (message, verificationSent) = await ref
        .read(settingsControllerProvider.notifier)
        .updateAuthEmail(context: context, newEmail: newEmail, password: password);

    if (context.mounted) {
      final title = verificationSent ? "Link Sent" : "Error";
      dialog(
        context: context,
        title: title,
        content: message,
        action: () {
          if (verificationSent) {
            onSuccess();
          }
        },
      );
    }
  }

  Future<void> updateAccount({
    required UserModel newUserData,
    required BuildContext context,
    VoidCallback? onSuccess,
  }) async {
    final cachedUser = ref.watch(userProvider).unwrap();
    if (cachedUser == newUserData) {
      return;
    }

    final (message, success) = await ref
        .read(settingsControllerProvider.notifier)
        .updateDB(context: context, newUser: newUserData);

    if (success) {
      showSnackbar(context: context, text: message!);
      onSuccess?.call();
    } else {
      showErrorSnackbar(context: context, text: message!);
    }
  }

  Future<void> showUpdateEmailModal({
    required BuildContext context,
    required TextEditingController passwordController,
    required Function(PasswordValue) onConfirm,
  }) async {
    showModalBottomSheet(
      backgroundColor: Colors.white,
      context: context,
      isScrollControlled: true,
      builder: (context) {
        return FractionallySizedBox(
          heightFactor: 0.7,
          child: Builder(
            builder: (context) {
              return Consumer(
                builder: (context, ref, child) {
                  final isUpdatingEmail = ref.watch(settingsControllerProvider).updatingEmail;
                  return Scaffold(
                    resizeToAvoidBottomInset: false,
                    body: Container(
                      padding: const EdgeInsets.all(20),
                      child: isUpdatingEmail
                          ? const DotsLoadingIndicator()
                          : ListView(
                              children: [
                                const Text(
                                  "Please enter your current password to update your email.",
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 16,
                                  ),
                                ),
                                const SizedBox(height: 20),
                                TextFormField(
                                  decoration: const InputDecoration(
                                    labelText: "Password",
                                    labelStyle: TextStyle(color: Colors.black),
                                  ),
                                  controller: passwordController,
                                  obscureText: true,
                                ),
                                const SizedBox(height: 20),
                                SizedBox(
                                  width: double.infinity,
                                  child: TextButton(
                                    style: kPrimaryTextButton,
                                    onPressed: () {
                                      final passwordValue = ValueChecker.checkPassword(
                                        context,
                                        passwordController.text,
                                        showDialog: true,
                                      );
                                      if (passwordValue.isNone()) {
                                        return;
                                      }
                                      onConfirm(passwordValue.unwrap());
                                    },
                                    child: const Text("Update Email"),
                                  ),
                                ),
                                const SizedBox(height: 240),
                              ],
                            ),
                    ),
                  );
                },
              );
            },
          ),
        );
      },
    ).then((_) {
      passwordController.clear();
    });
  }
}

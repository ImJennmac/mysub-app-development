import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/util/helpers.dart';
import 'package:mysub/common/util/validator.dart';
import 'package:mysub/common/widgets/visibility_textfield.dart';
import 'package:mysub/features/homepage/settings/controllers/settings_controller.dart';
import 'package:mysub/features/homepage/settings/widgets/setting_scaffold.dart';
import 'package:mysub/theme/styles.dart';

class PasswordSettingsPage extends HookConsumerWidget {
  static final formKey = GlobalKey<FormState>();
  static const String id = "password_settings";
  const PasswordSettingsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final oldPassword = useTextEditingController();
    final newPassword = useTextEditingController();
    final newPasswordConfirm = useTextEditingController();
    return Form(
      key: formKey,
      child: SettingScaffold(
        title: "Change your password",
        content: [
          const Text("Old Password"),
          vSpace(base: 5.0),
          VisibilityTextfield(
            controller: oldPassword,
            validator: Validator.validatePassword,
          ),
          vSpace(),
          const Text("New Password"),
          vSpace(base: 5),
          VisibilityTextfield(
            controller: newPassword,
            validator: Validator.validatePassword,
          ),
          vSpace(),
          const Text("New Password Confirmation"),
          vSpace(base: 5),
          VisibilityTextfield(
            controller: newPasswordConfirm,
            validator: (confirmation) {
              return Validator.doPasswordsMatch(newPassword.text, confirmation);
            },
          ),
          vSpace(multiplier: 2),
          SizedBox(
            width: double.infinity,
            child: TextButton(
              style: kPrimaryTextButton,
              onPressed: () {
                if (formKey.currentState!.validate()) {
                  ref.read(settingsControllerProvider.notifier).updatePassword(
                        newPassword: newPassword.text,
                        newPasswordConfirm: newPasswordConfirm.text,
                        oldPassword: oldPassword.text,
                        context: context,
                      );
                }
              },
              child: const Text("Save Changes"),
            ),
          ),
        ],
      ),
    );
  }
}

import 'dart:typed_data';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fpdart/fpdart.dart';
import 'package:image_picker/image_picker.dart';
import 'package:logger/logger.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/logger/logger.dart';
import 'package:mysub/repositories/impl/user_repository.dart';

class Avatar extends ConsumerStatefulWidget {
  const Avatar({super.key});

  @override
  ConsumerState<Avatar> createState() => _AvatarState();
}

class _AvatarState extends ConsumerState<Avatar> {
  StorageService storage = StorageService();
  Uint8List? pickedImage;
  bool isImagePickerActive = false;

  final Logger _logger = MySubLogger.getLogger((Avatar).toString());

  @override
  void initState() {
    super.initState();
    getAvatar();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onProfileTapped,
      child: Container(
        width: 65,
        height: 65,
        decoration: BoxDecoration(
          color: Colors.grey[300],
          borderRadius: BorderRadius.circular(12.0),
          image: pickedImage != null
              ? DecorationImage(
            fit: BoxFit.cover,
            image: MemoryImage(pickedImage!),
          )
              : null,
        ),
        child: pickedImage == null
            ? Icon(
          Icons.person,
          color: Colors.grey[600],
          size: 40,
        )
            : null,
      ),
    );
  }

  Future<void> onProfileTapped() async {
    if (isImagePickerActive) return;

    showModalBottomSheet(
      context: context,
      builder: (context) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.upload),
                title: const Text("Upload new avatar"),
                onTap: () {
                  Navigator.pop(context);
                  uploadNewAvatar();
                },
              ),
              ListTile(
                leading: const Icon(Icons.delete),
                title: const Text("Delete avatar"),
                onTap: () {
                  Navigator.pop(context);
                  deleteAvatar();
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> uploadNewAvatar() async {
    setState(() {
      isImagePickerActive = true;
    });

    try {
      final optionalUser = ref.read(userProvider);
      final user = optionalUser.getOrElse(() => throw Exception("User not found"));

      final ImagePicker picker = ImagePicker();
      final XFile? image = await picker.pickImage(source: ImageSource.gallery);
      if (image == null) return;

      final avatarUrl = await storage.uploadFile("Users/${user.uid}/avatar.jpg", image);
      if (avatarUrl == null) return;

      final imageBytes = await image.readAsBytes();
      if (mounted) {
        setState(() => pickedImage = imageBytes);
      }

      await ref.read(userRepositoryProvider).updateUserAvatarUrl(user.uid, avatarUrl);

      ref.read(userProvider.notifier).update((state) => Option.of(user.copyWith(avatarUrl: avatarUrl)));
    } finally {
      if (mounted) {
        setState(() {
          isImagePickerActive = false;
        });
      }
    }
  }

  Future<void> deleteAvatar() async {
    final optionalUser = ref.read(userProvider);
    final user = optionalUser.getOrElse(() => throw Exception("User not found"));

    final isDeleted = await storage.deleteFile("Users/${user.uid}/avatar.jpg");
    if (isDeleted) {
      setState(() {
        pickedImage = null;
      });

      await ref.read(userRepositoryProvider).updateUserAvatarUrl(user.uid, "");
      ref.read(userProvider.notifier).update((state) => Option.of(user.copyWith(avatarUrl: "")));
    } else {
      _logger.e('Failed to delete avatar.');
    }
  }

  Future<void> getAvatar() async {
    try {
      final userOption = ref.read(userProvider);
      final user = userOption.getOrElse(() => throw Exception("User not found"));

      final imageBytes = await storage.getFile("Users/${user.uid}/avatar.jpg");
      if (imageBytes != null && mounted) {
        setState(() => pickedImage = imageBytes);
      } else {
        _logger.i('No avatar found, using default.');
      }
    } catch (e) {
      _logger.e('Error fetching avatar: $e');
    }
  }
}

class StorageService {
  StorageService() : ref = FirebaseStorage.instance.ref();
  final Reference ref;
  final Logger _logger = MySubLogger.getLogger((StorageService).toString());

  Future<String?> uploadFile(String filePath, XFile file) async {
    try {
      final imageRef = ref.child(filePath);
      final imageBytes = await file.readAsBytes();
      await imageRef.putData(imageBytes);
      return await imageRef.getDownloadURL();
    } catch (e) {
      _logger.e('Could not upload: $e');
      return null;
    }
  }

  Future<bool> deleteFile(String filePath) async {
    try {
      final imageRef = ref.child(filePath);
      await imageRef.delete();
      _logger.i('File deleted at: $filePath');
      return true;
    } on FirebaseException catch (e) {
      if (e.code == 'object-not-found') {
        _logger.i('No file found at: $filePath');
      } else {
        _logger.e('Failed to delete file: $e');
      }
      return false;
    }
  }

  Future<Uint8List?> getFile(String filePath) async {
    try {
      final imageRef = ref.child(filePath);
      try {
        await imageRef.getDownloadURL();
      } on FirebaseException catch (e) {
        if (e.code == 'object-not-found') {
          _logger.i('No object exists at: $filePath');
          return null;
        }
        rethrow;
      }

      final data = await imageRef.getData();
      if (data == null || data.isEmpty) {
        _logger.i('File is empty at: $filePath');
        return null;
      }
      return data;
    } on FirebaseException catch (e) {
      _logger.e('Firebase error getting file: $e');
      return null;
    } catch (e) {
      _logger.e('Unexpected error getting file: $e');
      return null;
    }
  }
}

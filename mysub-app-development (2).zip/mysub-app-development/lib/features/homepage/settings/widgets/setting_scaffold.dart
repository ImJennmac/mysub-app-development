import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/util/button/backarrow.dart';
import 'package:mysub/common/util/helpers.dart';
import 'package:mysub/common/widgets/terms_of_service.dart';
import 'package:mysub/features/homepage/settings/controllers/settings_controller.dart';

class SettingScaffold extends ConsumerWidget {
  final List<Widget> content;
  final String? title;

  const SettingScaffold({
    super.key,
    required this.content,
    this.title,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final loading = ref.watch(settingsControllerProvider).updatingDetails;
    return loading
        ? buildLoadingPage()
        : Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(100),
        child: AppBar(
          scrolledUnderElevation: 0.0,
          backgroundColor: Colors.transparent,
          elevation: 0.0,
          automaticallyImplyLeading: false,
          flexibleSpace: SafeArea(
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30.0, vertical: 16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const BackArrow(),
                    if (title != null)
                      Expanded(
                        child: Center(
                          child: Text(
                            title!,
                            style: Theme.of(context).textTheme.titleMedium,
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                    const SizedBox(width: 56),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 30.0),
          child: ListView(
            padding: const EdgeInsets.only(bottom: 20.0),
            children: [
              const SizedBox(height: 5),
              ...content,
              const SizedBox(height: 20),
              const TermsOfService(),
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';

class SettingsTile extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget icon;
  final VoidCallback tapHandler;
  const SettingsTile({
    super.key,
    required this.title,
    this.subtitle,
    required this.icon,
    required this.tapHandler,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: tapHandler,
      child: ListTile(
        iconColor: Colors.black,
        contentPadding: EdgeInsets.zero,
        leading: SizedBox(
          width: 32,
          height: 32,
          child: icon,
        ),
        title: Text(
          title,
          style: Theme.of(context).textTheme.displayLarge,
        ),
        subtitle: subtitle == null ? null : Text(subtitle!),
        trailing: Icon(
          Icons.navigate_next,
          color: Theme.of(context).textTheme.displayMedium?.color,
        ),
      ),
    );
  }
}

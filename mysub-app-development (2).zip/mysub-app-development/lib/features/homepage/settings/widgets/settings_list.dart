import 'package:flutter/material.dart';
import 'package:mysub/features/homepage/settings/widgets/settings_tile.dart';

class SettingsList extends StatelessWidget {
  final String title;
  final List<SettingsTile> settings;
  const SettingsList({
    super.key,
    required this.title,
    required this.settings,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        const SizedBox(
          height: 5,
        ),
        Text(
          title,
          style: Theme.of(context).textTheme.displayMedium,
        ),
        const SizedBox(
          height: 10,
        ),
        ...settings,
        //     DEFAULT_SPACING,
      ],
    );
  }
}

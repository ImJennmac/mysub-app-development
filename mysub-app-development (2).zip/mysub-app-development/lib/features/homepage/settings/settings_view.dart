import 'package:flutter/material.dart';
import 'package:fpdart/fpdart.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/assets.dart';
import 'package:mysub/common/util/extensions.dart';
import 'package:mysub/features/homepage/profile/profile_view.dart';
import 'package:mysub/features/homepage/settings/pages/account-delete/account_delete_page.dart';
import 'package:mysub/features/homepage/settings/pages/premium/premium.dart';
import 'package:mysub/features/homepage/settings/pages/support.dart';
import 'package:mysub/features/homepage/settings/pages/user-account/account_settings_page.dart';
import 'package:mysub/features/homepage/settings/pages/user-settings/change_theme.dart';
import 'package:mysub/features/homepage/settings/pages/user-settings/notifications.dart';
import 'package:mysub/features/homepage/settings/pages/user-settings/passcode.dart';
import 'package:mysub/features/homepage/settings/widgets/setting_scaffold.dart';
import 'package:mysub/features/homepage/settings/widgets/settings_list.dart';
import 'package:mysub/features/homepage/settings/widgets/settings_tile.dart';
import 'package:mysub/features/landing/landing_view.dart';
import 'package:mysub/repositories/impl/auth_repository.dart';

class SettingsView extends ConsumerWidget {
  static const String id = "settings";
  const SettingsView({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.read(userProvider).unwrap();
    final authRepository = ref.read(authRepositoryProvider);
    final theme = Theme.of(context);
    final iconColor = theme.textTheme.displayMedium?.color;

    return SettingScaffold(
      title: "Settings",
      content: [
        // Updated Premium Upgrade Bar
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8.0), // Remove horizontal padding
          child: SizedBox(
            width: double.infinity, // Expand to full width
            child: Material(
              color: theme.primaryColor,
              borderRadius: BorderRadius.circular(12.0),
              child: InkWell(
                borderRadius: BorderRadius.circular(12.0),
                onTap: () {
                  Navigator.pushNamed(context, PremiumPage.id);
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 16.0),
                  alignment: Alignment.center,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center, // Center the content
                    children: [
                      const Icon(Icons.star, color: Colors.white),
                      const SizedBox(width: 8.0),
                      Text(
                        "Upgrade to Premium Now",
                        style: theme.textTheme.bodyLarge?.copyWith(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
        // Account settings section
        SettingsList(
          title: 'Account',
          settings: <SettingsTile>[
            SettingsTile(
              title: user.fullName.value,
              subtitle: "Personal Information",
              icon: ImageIcon(const AssetImage(kEdit), color: iconColor),
              tapHandler: () {
                Navigator.pushNamed(context, AccountSettingsPage.id);
              },
            ),
            SettingsTile(
              title: "Partners",
              icon: ImageIcon(const AssetImage(kAddPartner), color: iconColor),
              tapHandler: () {
                Navigator.pushNamed(context, ProfileView.id);
              },
            ),
            SettingsTile(
              title: "Premium",
              icon: ImageIcon(const AssetImage(kPremium), color: iconColor),
              tapHandler: () {
                Navigator.pushNamed(context, PremiumPage.id);
              },
            ),
          ],
        ),
        // User Settings section
        SettingsList(
          title: 'User Settings',
          settings: <SettingsTile>[
            SettingsTile(
              title: "Change Theme",
              icon: Icon(Icons.brightness_6, color: iconColor),
              tapHandler: () {
                Navigator.pushNamed(context, ChangeThemePage.id);
              },
            ),
            SettingsTile(
              title: "Notifications",
              icon: Icon(Icons.notifications, color: iconColor),
              tapHandler: () {
                Navigator.pushNamed(context, NotificationsPage.id);
              },
            ),
            SettingsTile(
              title: "Passcode",
              icon: Icon(Icons.lock, color: iconColor),
              tapHandler: () {
                Navigator.pushNamed(context, PasscodePage.id);
              },
            ),
          ],
        ),
        // Other settings section
        SettingsList(
          title: 'Other',
          settings: <SettingsTile>[
            SettingsTile(
              title: "Support",
              icon: ImageIcon(const AssetImage(kEmail), color: iconColor),
              tapHandler: () {
                Navigator.pushNamed(context, SupportPage.id);
              },
            ),
            SettingsTile(
              title: "Delete Account",
              icon: ImageIcon(const AssetImage(kDelete), color: iconColor),
              tapHandler: () {
                Navigator.pushNamed(context, DeleteAccountPage.id);
              },
            ),
            SettingsTile(
              title: "Log Out",
              icon: ImageIcon(const AssetImage(kLogout), color: iconColor),
              tapHandler: () async {
                final result = await authRepository.signOut();
                ref.read(userProvider.notifier).state = const Option.none();
                result.fold(
                      (error) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Failed to log out: ${error.description}')),
                    );
                  },
                      (_) {
                    Navigator.pushNamedAndRemoveUntil(context, LandingView.id, (route) => false);
                  },
                );
              },
            ),
          ],
        ),
      ],
    );
  }
}

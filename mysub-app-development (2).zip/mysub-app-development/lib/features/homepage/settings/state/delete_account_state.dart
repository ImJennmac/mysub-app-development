import 'package:flutter/cupertino.dart';

enum DeleteAccountStep { WARNING, DELETE }

@immutable
class DeleteAccountState {
  final DeleteAccountStep page;
  final double transitionOpacity;
  final bool loading;
  const DeleteAccountState({
    required this.page,
    this.transitionOpacity = 0,
    this.loading = false,
  });

  DeleteAccountState copyWith({
    DeleteAccountStep? page,
    double? transitionOpacity,
    bool? loading,
  }) {
    return DeleteAccountState(
      page: page ?? this.page,
      transitionOpacity: transitionOpacity ?? this.transitionOpacity,
      loading: loading ?? this.loading,
    );
  }
}

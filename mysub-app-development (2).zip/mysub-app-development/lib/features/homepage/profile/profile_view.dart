import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/button/backarrow.dart';
import 'package:mysub/features/homepage/settings/widgets/avatar.dart';
import 'package:mysub/features/partners/controllers/friend_system.dart';
import 'package:mysub/features/partners/controllers/update_active_partner.dart';
import 'package:mysub/features/partners/pages/partner_page.dart';
import 'package:mysub/features/partners/pages/sent_requests.dart';
import 'package:mysub/features/partners/state/dynamic.dart';
import 'package:mysub/features/partners/widgets/partners_card.dart';

class ProfileView extends ConsumerStatefulWidget {
  static const String id = "profile";
  const ProfileView({super.key});

  @override
  ConsumerState<ProfileView> createState() => _ProfileViewState();
}

class _ProfileViewState extends ConsumerState<ProfileView> {
  final TextEditingController _usernameController = TextEditingController();
  final PageController _pageController = PageController();

  @override
  void dispose() {
    _usernameController.dispose();
    _pageController.dispose();
    super.dispose();
  }

  void _handleNext() {
    final username = _usernameController.text.trim();
    if (username.isNotEmpty) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => DynamicPage(username: username),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a username')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final optionalUser = ref.watch(userProvider);

    return optionalUser.match(
          () => Scaffold(
        body: Center(
          child: CircularProgressIndicator(color: theme.colorScheme.primary),
        ),
      ),
          (user) {
        final userDoc = FirebaseFirestore.instance.collection('users').doc(user.uid);

        return Scaffold(
          body: SafeArea(
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                child: Column(
                  children: [
                    Row(
                      children: [
                        const BackArrow(),
                        Expanded(
                          child: Align(
                            child: Text(
                              "Profile",
                              style: theme.textTheme.titleMedium,
                            ),
                          ),
                        ),
                        const SizedBox(width: 48),
                      ],
                    ),
                    const SizedBox(height: 20),
                    const SizedBox(
                      width: 100,
                      height: 100,
                      child: Avatar(),
                    ),
                    const SizedBox(height: 20),
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => PartnerPage(
                              onPartnerSelected: (partnerUsername) async {
                                await swapPartner(partnerUsername, user.uid, context);
                              },
                            ),
                          ),
                        );
                      },
                      child: Container(
                        width: double.infinity,
                        height: 50,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10.0),
                          border: Border.all(
                            color: theme.colorScheme.primary,
                            width: 2.0,
                          ),
                        ),
                        child: Center(
                          child: Text(
                            'Swap Partner',
                            style: theme.textTheme.displayMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Add Partners",
                          style: theme.textTheme.displayMedium,
                        ),
                        const SizedBox(height: 5),
                        Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15.0),
                            color: theme.colorScheme.surface,
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 10.0),
                            child: Row(
                              children: [
                                Expanded(
                                  child: TextField(
                                    controller: _usernameController,
                                    decoration: InputDecoration(
                                      hintText: "Partner's Username",
                                      border: InputBorder.none,
                                      enabledBorder: InputBorder.none,
                                      focusedBorder: InputBorder.none,
                                      hintStyle: TextStyle(color: theme.hintColor),
                                    ),
                                    style: theme.textTheme.bodyMedium,
                                    onSubmitted: (value) {
                                      _handleNext();
                                    },
                                  ),
                                ),
                                TextButton(
                                  onPressed: _handleNext,
                                  child: Text(
                                    'Next',
                                    style: theme.textTheme.labelLarge?.copyWith(
                                      color: theme.colorScheme.primary,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushNamed(context, SentRequestsPage.id);
                      },
                      child: Container(
                        width: double.infinity,
                        height: 50,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10.0),
                          border: Border.all(
                            color: theme.colorScheme.primary,
                            width: 2.0,
                          ),
                        ),
                        child: Center(
                          child: Text(
                            'Sent Requests',
                            style: theme.textTheme.displayMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Pending Requests",
                          style: theme.textTheme.displayMedium,
                        ),
                        const SizedBox(height: 5),
                        Container(
                          width: double.infinity,
                          height: 300,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15.0),
                            color: theme.colorScheme.surface,
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 10.0),
                            child: StreamBuilder<DocumentSnapshot>(
                              stream: userDoc.snapshots(),
                              builder: (context, snapshot) {
                                if (snapshot.connectionState == ConnectionState.waiting) {
                                  return Center(child: CircularProgressIndicator(color: theme.colorScheme.primary));
                                }

                                if (!snapshot.hasData || !snapshot.data!.exists) {
                                  return Center(child: Text('No data available', style: theme.textTheme.bodyMedium));
                                }

                                final data = snapshot.data!.data()! as Map<String, dynamic>;
                                final receivedRequests = (data['receivedRequests'] as List<dynamic>?)
                                    ?.map((e) => e as Map<String, dynamic>)
                                    .toList() ??
                                    [];

                                if (receivedRequests.isEmpty) {
                                  return Center(child: Text('No pending requests found.', style: theme.textTheme.bodyMedium));
                                }

                                return SizedBox(
                                  height: 250,
                                  child: Stack(
                                    children: [
                                      PageView.builder(
                                        controller: _pageController,
                                        itemCount: receivedRequests.length,
                                        itemBuilder: (context, index) {
                                          final request = receivedRequests[index];
                                          final username = request['username'] as String;

                                          return PartnerCard(
                                            username: username,
                                            isSelected: false,
                                            onSelect: () {},
                                            onDelete: () async {
                                              await rejectRequest(request, userDoc, user.uid, data);
                                            },
                                            onAccept: () async {
                                              await acceptRequest(
                                                request,
                                                userDoc,
                                                user.uid,
                                                data,
                                                ref,
                                              );
                                            },
                                            onReject: () async {
                                              await rejectRequest(request, userDoc, user.uid, data);
                                            },
                                            isPendingRequest: true,
                                            dynamicText: "Wants to connect with you",
                                            isDominant: false,               // Default value since role isn't set yet
                                            isSwitch: false,                 // Default value since role isn't set yet
                                            currentRoleIsDominant: false,    // Provide default value
                                          );
                                        },
                                      ),
                                      Positioned(
                                        left: 0,
                                        top: 100,
                                        child: IconButton(
                                          icon: Icon(Icons.arrow_back, color: theme.iconTheme.color),
                                          onPressed: () {
                                            _pageController.previousPage(
                                              duration: const Duration(milliseconds: 300),
                                              curve: Curves.easeInOut,
                                            );
                                          },
                                        ),
                                      ),
                                      Positioned(
                                        right: 0,
                                        top: 100,
                                        child: IconButton(
                                          icon: Icon(Icons.arrow_forward, color: theme.iconTheme.color),
                                          onPressed: () {
                                            _pageController.nextPage(
                                              duration: const Duration(milliseconds: 300),
                                              curve: Curves.easeInOut,
                                            );
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

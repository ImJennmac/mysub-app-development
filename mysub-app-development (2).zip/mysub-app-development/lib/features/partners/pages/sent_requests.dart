import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fpdart/fpdart.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/button/backarrow.dart';
import 'package:mysub/features/partners/controllers/friend_system.dart';

class SentRequestsPage extends ConsumerStatefulWidget {
  static const String id = "sent_requests";
  const SentRequestsPage({super.key});

  @override
  ConsumerState<SentRequestsPage> createState() => _SentRequestsPageState();
}

class _SentRequestsPageState extends ConsumerState<SentRequestsPage> {
  Future<void> _cancelRequest(String targetUserId, String username) async {
    final optionalUser = ref.read(userProvider);
    final user = optionalUser.getOrElse(() => throw Exception("User not found"));
    final userDoc = FirebaseFirestore.instance.collection('users').doc(user.uid);

    final messenger = ScaffoldMessenger.of(context);

    try {
      final senderUserDoc = await userDoc.get();
      final senderData = senderUserDoc.data() ?? {};

      final request = {
        'id': targetUserId,
        'partnerOneDynamic': 'Switch',
        'username': username,
      };

      await rejectRequest(request, userDoc, user.uid, senderData, isCancellation: true);

      messenger.showSnackBar(
        const SnackBar(content: Text('Request canceled successfully!')),
      );
    } catch (e) {
      messenger.showSnackBar(
        SnackBar(content: Text('Failed to cancel request: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final optionalUser = ref.watch(userProvider);

    return optionalUser.match(
      () => const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      ),
      (user) {
        final userDoc = FirebaseFirestore.instance.collection('users').doc(user.uid);

        return Scaffold(
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              child: Column(
                children: [
                  Row(
                    children: [
                      const BackArrow(),
                      Expanded(
                        child: Align(
                          child: Text(
                            "Sent Requests",
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                        ),
                      ),
                      const SizedBox(width: 48),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Expanded(
                    child: StreamBuilder<DocumentSnapshot>(
                      stream: userDoc.snapshots(),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState == ConnectionState.waiting) {
                          return const Center(child: CircularProgressIndicator());
                        }

                        if (!snapshot.hasData || !snapshot.data!.exists) {
                          return const Center(child: Text('No data available'));
                        }

                        final data = snapshot.data!.data()! as Map<String, dynamic>;
                        final sentRequests = (data['sentRequests'] as List<dynamic>?)
                                ?.map((e) => e as Map<String, dynamic>)
                                .toList() ??
                            [];

                        if (sentRequests.isEmpty) {
                          return const Center(child: Text('No sent requests found.'));
                        }

                        return ListView.builder(
                          itemCount: sentRequests.length,
                          itemBuilder: (context, index) {
                            final request = sentRequests[index];
                            final username = request['username'] as String?;
                            final targetUserId = request['id'] as String?;

                            if (username == null || targetUserId == null) {
                              return const SizedBox.shrink();
                            }

                            return ListTile(
                              title: Text(username),
                              trailing: IconButton(
                                icon: const Icon(Icons.close, color: Colors.red),
                                onPressed: () async {
                                  await _cancelRequest(targetUserId, username);
                                },
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

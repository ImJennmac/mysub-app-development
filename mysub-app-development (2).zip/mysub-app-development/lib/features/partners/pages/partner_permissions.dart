import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/util/button/backarrow.dart';
import 'package:mysub/common/util/button/savebutton.dart';
import 'package:mysub/features/partners/controllers/permissions.dart';

class PartnerPermissionsPage extends ConsumerStatefulWidget {
  static const String id = "partner_permissions_page";
  final String partnerId;
  final String partnerUsername;
  final bool isDominant;
  final bool isSwitch;

  const PartnerPermissionsPage({
    super.key,
    required this.partnerId,
    required this.partnerUsername,
    required this.isDominant,
    required this.isSwitch,
  });

  @override
  ConsumerState<PartnerPermissionsPage> createState() => _PartnerPermissionsPageState();
}

class _PartnerPermissionsPageState extends ConsumerState<PartnerPermissionsPage> {
  late Future<Map<String, bool>> _permissionsFuture;

  @override
  void initState() {
    super.initState();
    _permissionsFuture = loadPermissions(ref, widget.partnerId, widget.isDominant);
  }

  Future<void> _savePermissions(Map<String, bool> permissions) async {
    if (widget.isDominant) {
      final result = await updatePermissions(ref, widget.partnerId, permissions, widget.isDominant);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(result)),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final canEdit = widget.isDominant;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const BackArrow(),
                  Expanded(
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        child: Text(
                          canEdit
                              ? "Permissions for ${widget.partnerUsername}"
                              : "Permissions set by ${widget.partnerUsername}",
                          style: theme.textTheme.displayMedium,
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  ),
                  if (canEdit)
                    SaveButton(
                      onPressed: () async {
                        final permissions = await _permissionsFuture;
                        await _savePermissions(permissions);
                      },
                    ),
                  if (!canEdit)
                    const SizedBox(width: 50),
                ],
              ),
              const SizedBox(height: 20),
              Expanded(
                child: FutureBuilder<Map<String, bool>>(
                  future: _permissionsFuture,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return Center(child: CircularProgressIndicator(color: theme.colorScheme.primary));
                    }

                    if (snapshot.hasError) {
                      return Center(child: Text('Error: ${snapshot.error}', style: theme.textTheme.bodyLarge));
                    }

                    final permissions = snapshot.data!;

                    return ListView.builder(
                      itemCount: permissions.length,
                      itemBuilder: (context, index) {
                        final perm = permissions.keys.elementAt(index);
                        return Container(
                          decoration: BoxDecoration(
                            color: theme.colorScheme.surface,
                            borderRadius: BorderRadius.circular(15.0),
                          ),
                          margin: const EdgeInsets.symmetric(vertical: 8.0),
                          child: canEdit
                              ? SwitchListTile(
                            title: Text(
                              perm,
                              style: theme.textTheme.displayMedium,
                            ),
                            value: permissions[perm]!,
                            onChanged: (value) {
                              setState(() {
                                permissions[perm] = value;
                              });
                            },
                            activeColor: theme.colorScheme.primary,
                          )
                              : ListTile(
                            title: Text(
                              perm,
                              style: theme.textTheme.displayMedium,
                            ),
                            trailing: Icon(
                              permissions[perm]! ? Icons.check_circle : Icons.cancel,
                              color: permissions[perm]! ? Colors.green : Colors.red,
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

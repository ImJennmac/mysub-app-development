import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/util/button/backarrow.dart';

class SwapPartnerProfilesPage extends ConsumerWidget {
  static const String id = "swap_partner_profiles";
  final String partnerUsername;

  const SwapPartnerProfilesPage({super.key, required this.partnerUsername});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const BackArrow(),
                  Expanded(
                    child: Align(
                      child: Text(
                        "Dynamic for $partnerUsername",
                        style: theme.textTheme.displayMedium,
                      ),
                    ),
                  ),
                  const SizedBox(width: 48),
                ],
              ),
              const SizedBox(height: 20),
              Text(
                'Select the profile you want to swap to:',
                style: Theme.of(context).textTheme.displayMedium,
              ),
              const SizedBox(height: 20),
              _buildProfileButton(context, 'Submissive Profile', 'Submissive'),
              const SizedBox(height: 20),
              _buildProfileButton(context, 'Dominant Profile', 'Dominant'),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProfileButton(BuildContext context, String label, String profile) {
    final theme = Theme.of(context);
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(15.0),
      ),
      child: InkWell(
        onTap: () {
          Navigator.of(context).pop(profile);
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                label,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              const Icon(Icons.arrow_forward_ios, color: Colors.blue),
            ],
          ),
        ),
      ),
    );
  }
}

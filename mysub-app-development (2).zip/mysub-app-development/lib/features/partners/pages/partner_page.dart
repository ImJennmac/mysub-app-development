import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/button/backarrow.dart';
import 'package:mysub/features/partners/controllers/remove_friend.dart';
import 'package:mysub/features/partners/controllers/update_active_partner.dart';
import 'package:mysub/features/partners/pages/partner_permissions.dart';
import 'package:mysub/features/partners/widgets/partners_card.dart';

class PartnerPage extends ConsumerStatefulWidget {
  static const String id = "partners_page";
  final Future<void> Function(String partnerUsername) onPartnerSelected;

  const PartnerPage({super.key, required this.onPartnerSelected});

  @override
  ConsumerState<PartnerPage> createState() => _PartnerPageState();
}

class _PartnerPageState extends ConsumerState<PartnerPage> {
  @override
  Widget build(BuildContext context) {
    final optionalUser = ref.watch(userProvider);
    final theme = Theme.of(context);

    return optionalUser.match(
          () => const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      ),
          (user) {
        final userDoc = FirebaseFirestore.instance.collection('users').doc(user.uid);

        return Scaffold(
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              child: StreamBuilder<DocumentSnapshot>(
                stream: userDoc.snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  if (!snapshot.hasData || !snapshot.data!.exists) {
                    return const Center(child: Text('No data available'));
                  }

                  final data = snapshot.data!.data()! as Map<String, dynamic>;
                  final activePartner = data['activePartner'] as Map<String, dynamic>? ?? {};
                  final activeUser = activePartner['activeUser'] as String? ?? 'solo';

                  final acceptedFriends = (data['acceptedFriends'] as List<dynamic>?)
                      ?.map((e) => e as Map<String, dynamic>)
                      .toList() ??
                      [];

                  return SingleChildScrollView(
                    child: Column(
                      children: [
                        Row(
                          children: [
                            const BackArrow(),
                            Expanded(
                              child: Align(
                                child: Text(
                                  "Your Partners",
                                  style: theme.textTheme.titleMedium,
                                ),
                              ),
                            ),
                            const SizedBox(width: 48),
                          ],
                        ),
                        const SizedBox(height: 20),
                        _buildSoloTile(activeUser, user.uid),
                        const SizedBox(height: 10),
                        ...acceptedFriends.map((friend) => _buildPartnerCard(friend, user.uid, activeUser)),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildSoloTile(String activeUser, String userFUid) {
    return PartnerCard(
      username: 'Solo',
      isSelected: activeUser == 'solo',
      onSelect: () => _updateActivePartner('solo', userFUid, 'solo', 'solo'),
      isSolo: true,
      isDominant: true,
      isSwitch: false,
      currentRoleIsDominant: true,
    );
  }

  Widget _buildPartnerCard(Map<String, dynamic> friend, String userUid, String activeUser) {
    final username = friend['username'] as String?;
    final id = friend['ID'] as String?;
    if (username == null || id == null) {
      return const SizedBox.shrink();
    }

    final friendID = friend['friendID'];
    final partnerOneDynamic = friend['partnerOneDynamic'] as String?;
    final partnerTwoDynamic = friend['partnerTwoDynamic'] as String?;

    bool isDominant = false;
    bool isSwitch = false;
    bool currentRoleIsDominant = false;

    final bool isUserPartnerOne = friend['partnerOneID'] == userUid;

    if (friendID is Map<String, dynamic>) {
      isSwitch = true;
      currentRoleIsDominant = getCurrentUserRole(friend, isUserPartnerOne);
      isDominant = currentRoleIsDominant;
    } else if (friendID is String) {
      isSwitch = false;
      if (isUserPartnerOne) {
        isDominant = partnerOneDynamic == "Dominant";
      } else {
        isDominant = partnerTwoDynamic == "Dominant";
      }
      currentRoleIsDominant = isDominant;
    }

    return PartnerCard(
      username: username,
      accepted: true,
      isSelected: activeUser == id,
      onSelect: () async {
        await swapPartner(username, userUid, context);
      },
      onDelete: () => removeFriend(username, id, userUid, context),
      onEditPermissions: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => PartnerPermissionsPage(
              partnerId: id,
              partnerUsername: username,
              isDominant: true,
              isSwitch: isSwitch,
            ),
          ),
        );
      },
      onViewPermissions: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => PartnerPermissionsPage(
              partnerId: id,
              partnerUsername: username,
              isDominant: false,
              isSwitch: isSwitch,
            ),
          ),
        );
      },
      isDominant: isDominant,
      isSwitch: isSwitch,
      currentRoleIsDominant: currentRoleIsDominant,
    );
  }

  Future<void> _updateActivePartner(String partnerID, String userFUid, String activeDynamic, String activeFriendshipID) async {
    await updateActive(partnerID, userFUid, context, activeDynamic, activeFriendshipID);
  }

  bool getCurrentUserRole(Map<String, dynamic> friend, bool isUserPartnerOne) {
    final currentRole = friend['currentRole'] as String?;
    if (currentRole == null) {
      return true;
    }
    if (isUserPartnerOne) {
      return currentRole == 'partnerOneDominant';
    } else {
      return currentRole == 'partnerTwoDominant';
    }
  }
}

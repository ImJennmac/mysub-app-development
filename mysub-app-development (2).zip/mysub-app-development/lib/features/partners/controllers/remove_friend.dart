import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:logger/logger.dart';
import 'package:mysub/common/util/logger/logger.dart';

Logger _logger = MySubLogger.getLogger('RemoveFriend');

Future<void> removeFriend(
    String friendUsername,
    String friendId,
    String userUid,
    BuildContext context,
    ) async {
  final DocumentReference userDoc = FirebaseFirestore.instance.collection('users').doc(userUid);
  final DocumentReference friendDoc = FirebaseFirestore.instance.collection('users').doc(friendId);
  final CollectionReference friendshipsCollection = FirebaseFirestore.instance.collection('friendships');

  final messenger = ScaffoldMessenger.of(context);

  try {
    await FirebaseFirestore.instance.runTransaction((transaction) async {
      final DocumentSnapshot userSnapshot = await transaction.get(userDoc);
      final DocumentSnapshot friendSnapshot = await transaction.get(friendDoc);

      final Map<String, dynamic> userData = userSnapshot.data()! as Map<String, dynamic>;
      final Map<String, dynamic> friendData = friendSnapshot.data()! as Map<String, dynamic>;

      final List<Map<String, dynamic>> userAcceptedFriends = (userData['acceptedFriends'] as List<dynamic>?)
          ?.map((e) => e as Map<String, dynamic>)
          .toList() ?? [];

      final Map<String, dynamic> friendToRemove = userAcceptedFriends.firstWhere(
            (friend) => friend['username'] == friendUsername && friend['ID'] == friendId,
        orElse: () => <String, dynamic>{},
      );

      if (friendToRemove.isEmpty) {
        throw Exception('Friend not found in accepted friends list');
      }

      final friendID = friendToRemove['friendID'];
      final List<String> friendshipIdsToRemove = [];

      if (friendID is Map<String, dynamic>) {
        final String? partnerOneSub = friendID['partnerOneSub'] as String?;
        final String? partnerOneDom = friendID['partnerOneDom'] as String?;

        if (partnerOneSub != null) friendshipIdsToRemove.add(partnerOneSub);
        if (partnerOneDom != null) friendshipIdsToRemove.add(partnerOneDom);
      } else if (friendID is String) {
        friendshipIdsToRemove.add(friendID);
      } else {
        _logger.w('Unexpected friendID type: ${friendID.runtimeType}');
      }

      // Remove friend from user's acceptedFriends and partnerPermissions
      final Map<String, dynamic> updateUserData = {
        'acceptedFriends': FieldValue.arrayRemove([friendToRemove]),
      };
      for (final String id in friendshipIdsToRemove) {
        updateUserData['partnerPermissions.$id'] = FieldValue.delete();
      }
      transaction.update(userDoc, updateUserData);

      // Find and remove user from friend's acceptedFriends
      final List<Map<String, dynamic>> friendAcceptedFriends = (friendData['acceptedFriends'] as List<dynamic>?)
          ?.map((e) => e as Map<String, dynamic>)
          .toList() ?? [];

      final Map<String, dynamic> userToRemoveFromFriend = friendAcceptedFriends.firstWhere(
            (friend) => friend['username'] == userData['username'] && friend['ID'] == userUid,
        orElse: () => <String, dynamic>{},
      );

      if (userToRemoveFromFriend.isEmpty) {
        _logger.w("User not found in friend's accepted friends list");
      }

      // Remove user from friend's acceptedFriends and partnerPermissions
      final Map<String, dynamic> updateFriendData = {
        'acceptedFriends': FieldValue.arrayRemove([userToRemoveFromFriend]),
      };
      for (final String id in friendshipIdsToRemove) {
        updateFriendData['partnerPermissions.$id'] = FieldValue.delete();
      }
      transaction.update(friendDoc, updateFriendData);

      // Delete friendship documents
      for (final String id in friendshipIdsToRemove) {
        transaction.delete(friendshipsCollection.doc(id));
      }

      // Update active partner if necessary
      final Map<String, dynamic> activePartner = (userData['activePartner'] as Map<String, dynamic>?) ?? {};
      if (activePartner['activeUser'] == friendId) {
        transaction.update(userDoc, {
          'activePartner': {
            'activeUser': 'solo',
            'activeFriendshipID': 'solo',
            'activeDynamic': userData['POSITION'] ?? 'Submissive',
          },
        });
      }

      _logger.d('Friend removal transaction completed. User updated: $updateUserData, Friend updated: $updateFriendData');
    });

    // Show success message
    messenger.showSnackBar(
      const SnackBar(content: Text('Friend removed successfully!')),
    );
    _logger.d('Friend $friendUsername removed successfully for user $userUid');

    final userSnapshot = await userDoc.get();
    final userData = userSnapshot.data() as Map<String, dynamic>?;
    final activePartner = userData?['activePartner'] as Map<String, dynamic>?;

    // Check if active partner needs to be updated
    if (activePartner != null && activePartner['activeUser'] == 'solo') {
      await updateActiveWithoutContext('solo', userUid, activePartner['activeDynamic'] as String, 'solo');
    }

  } catch (e) {
    // Show error message
    messenger.showSnackBar(
      SnackBar(content: Text('Failed to remove friend: $e')),
    );
    _logger.e('Error removing friend $friendUsername for user $userUid: $e');
  }
}

Future<void> updateActiveWithoutContext(String s, String userUid, String activePartner, String t) async {
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:logger/logger.dart';
import 'package:mysub/common/util/logger/logger.dart';
import 'package:uuid/uuid.dart';

const Uuid uuid = Uuid();

Logger _logger = MySubLogger.getLogger('FriendSystem');

Future<void> acceptRequest(
    Map<String, dynamic> request,
    DocumentReference userDoc,
    String userUid,
    Map<String, dynamic> data,
    WidgetRef ref,
    ) async {
  final username = request['username'] as String;
  final userId = request['id'] as String;
  final partnerTwoDynamic = request['partnerTwoDynamic'] as String;

  final String partnerOneDynamic = partnerTwoDynamic == 'Switch'
      ? 'Switch'
      : partnerTwoDynamic == 'Submissive'
      ? 'Dominant'
      : 'Submissive';

  dynamic friendID;
  if (partnerTwoDynamic == 'Switch') {
    if (request['friendID'] == null || request['friendID'] is! Map) {
      // Generate new IDs if friendID is not properly structured
      friendID = {
        'partnerOneDom': uuid.v4(),
        'partnerOneSub': uuid.v4(),
      };
    } else {
      friendID = (request['friendID'] as Map<String, dynamic>).map(
            (key, value) => MapEntry(key, value?.toString() ?? uuid.v4()),
      );
    }
  } else {
    friendID = request['friendID']?.toString() ?? uuid.v4();
  }

  try {
    await FirebaseFirestore.instance.runTransaction((transaction) async {
      // Update receiver's document
      transaction.update(userDoc, {
        'acceptedFriends': FieldValue.arrayUnion([
          {
            'username': username,
            'ID': userId,
            'friendID': friendID,
            'partnerTwoDynamic': partnerTwoDynamic,
          }
        ]),
        'receivedRequests': FieldValue.arrayRemove([request]),
      });

      // Update sender's document
      final targetUserDoc = FirebaseFirestore.instance.collection('users').doc(userId);
      final reverseFriendID = partnerTwoDynamic == 'Switch'
          ? {
        'partnerTwoDom': (friendID as Map<String, String>)['partnerOneSub'],
        'partnerTwoSub': friendID['partnerOneDom'],
      }
          : friendID;

      transaction.update(targetUserDoc, {
        'acceptedFriends': FieldValue.arrayUnion([
          {
            'username': data['username'],
            'ID': userUid,
            'friendID': reverseFriendID,
            'partnerOneDynamic': partnerOneDynamic,
          }
        ]),
        'sentRequests': FieldValue.arrayRemove([
          {
            'id': userUid,
            'partnerOneDynamic': partnerOneDynamic,
            'username': data['username'],
          },
        ]),
      });

      // Initialize permissions for both users
      final defaultPermissions = {
        'Create new habits': false,
        'Create new punishments': false,
        'Create new rewards': false,
        'Add new rules': false,
        'View progress': false,
      };

      if (partnerTwoDynamic == 'Switch') {
        final friendIDMap = friendID as Map<String, String>;
        transaction.update(userDoc, {
          'partnerPermissions.${friendIDMap['partnerOneDom']}': defaultPermissions,
          'partnerPermissions.${friendIDMap['partnerOneSub']}': defaultPermissions,
        });
        transaction.update(targetUserDoc, {
          'partnerPermissions.${friendIDMap['partnerOneSub']}': defaultPermissions,
          'partnerPermissions.${friendIDMap['partnerOneDom']}': defaultPermissions,
        });
      } else {
        transaction.update(userDoc, {
          'partnerPermissions.$friendID': defaultPermissions,
        });
        transaction.update(targetUserDoc, {
          'partnerPermissions.$friendID': defaultPermissions,
        });
      }
    });

    final friendshipsCollection = FirebaseFirestore.instance.collection('friendships');
    if (partnerTwoDynamic == 'Switch') {
      final friendIDMap = friendID as Map<String, String>;
      await friendshipsCollection.doc(friendIDMap['partnerOneSub']).set({
        'user1': userUid,
        'user2': userId,
        'user1Username': data['username'],
        'user2Username': username,
        'dynamic': 'Submissive',
      });
      await friendshipsCollection.doc(friendIDMap['partnerOneDom']).set({
        'user1': userUid,
        'user2': userId,
        'user1Username': data['username'],
        'user2Username': username,
        'dynamic': 'Dominant',
      });
    } else {
      await friendshipsCollection.doc(friendID as String).set({
        'user1': userUid,
        'user2': userId,
        'user1Username': data['username'],
        'user2Username': username,
        'dynamic': partnerTwoDynamic,
      });
    }

    _logger.d('Request accepted and documents updated successfully.');
  } catch (e) {
    _logger.e('Error accepting request: $e');
    rethrow;
  }
}

Future<void> rejectRequest(
    Map<String, dynamic> request,
    DocumentReference userDoc,
    String userUid,
    Map<String, dynamic> data, {
      bool isCancellation = false,
    }) async {
  _logger.d('Rejecting request: $request');
  _logger.d('User data: $data');

  final senderId = request['id'] as String?;
  final receiverUsername = data['username'] as String?;

  if (senderId == null) {
    _logger.e('Error: Sender ID is null in the request');
    return;
  }

  if (receiverUsername == null) {
    _logger.e('Error: Receiver username is null in the user data');
    return;
  }

  try {
    // Fetch the document of the intended recipient of the request (user who received it)
    final recipientDoc = FirebaseFirestore.instance.collection('users').doc(senderId);
    final recipientSnapshot = await recipientDoc.get();
    final recipientData = recipientSnapshot.data();

    List<Map<String, dynamic>> receivedRequests = [];
    if (recipientData is Map<String, dynamic> && recipientData['receivedRequests'] is List) {
      receivedRequests = List<Map<String, dynamic>>.from(recipientData['receivedRequests'] as List);
    }

    _logger.d('Current receivedRequests for recipient: $receivedRequests');

    // Find the matching request in recipient's receivedRequests
    final matchingRequest = receivedRequests.firstWhere(
          (req) => req['id'] == userUid && req['username'] == receiverUsername,
      orElse: () => {},
    );

    if (matchingRequest.isEmpty) {
      _logger.e('Matching request not found in recipient\'s receivedRequests.');
      return;
    }

    // Remove the exact matching request object from recipient's receivedRequests
    await recipientDoc.update({
      'receivedRequests': FieldValue.arrayRemove([matchingRequest]),
    });

    // Fetch the sender's sentRequests to ensure an exact match
    final senderDoc = FirebaseFirestore.instance.collection('users').doc(userUid);
    final senderSnapshot = await senderDoc.get();
    final senderData = senderSnapshot.data();

    List<Map<String, dynamic>> sentRequests = [];
    if (senderData is Map<String, dynamic> && senderData['sentRequests'] is List) {
      sentRequests = List<Map<String, dynamic>>.from(senderData['sentRequests'] as List);
    }

    _logger.d('Current sentRequests for sender: $sentRequests');

    // Find the exact matching request in sender's sentRequests based on id and username only
    final matchingSentRequest = sentRequests.firstWhere(
          (req) => req['username'] == request['username'] && req['id'] == senderId,
      orElse: () => {},
    );

    if (matchingSentRequest.isEmpty) {
      _logger.e('Matching sent request not found in sender\'s sentRequests.');
      return;
    }

    // Remove the exact matching request object from sender's sentRequests
    await senderDoc.update({
      'sentRequests': FieldValue.arrayRemove([matchingSentRequest]),
    });

    _logger.d(
      'Request ${isCancellation ? "canceled" : "rejected"} and documents updated successfully on both ends.',
    );
  } catch (e) {
    _logger.e('Error ${isCancellation ? "canceling" : "rejecting"} request: $e');
    rethrow;
  }
}


Future<String> sendFriendRequest({
  required String senderUid,
  required String senderUsername,
  required String targetUsername,
  required String selectedDynamic,
}) async {
  final usernamesCollection = FirebaseFirestore.instance.collection('usernames');
  final usersCollection = FirebaseFirestore.instance.collection('users');

  try {
    if (senderUsername == targetUsername) {
      return 'You cannot add yourself as a friend.';
    }

    final usernameDoc = await usernamesCollection.doc(targetUsername).get();
    if (!usernameDoc.exists) {
      return 'Username does not exist.';
    }

    final targetUserId = usernameDoc.get('id') as String?;
    if (targetUserId == null) {
      return 'Failed to retrieve user details.';
    }

    // partnerOne is always the sender, while partnerTwo is the person who obtains the request.
    final String partnerOneDynamic = selectedDynamic;
    final String partnerTwoDynamic = selectedDynamic == 'Switch'
        ? 'Switch'
        : (selectedDynamic == 'Submissive' ? 'Dominant' : 'Submissive');

    final senderDoc = await usersCollection.doc(senderUid).get();
    final senderData = senderDoc.data();
    final sentRequests = (senderData?['sentRequests'] as List<dynamic>?)
        ?.map((e) => e as Map<String, dynamic>)
        .toList() ??
        [];
    final alreadySent = sentRequests.any((req) => req['username'] == targetUsername);

    final targetUserDoc = await usersCollection.doc(targetUserId).get();
    final targetUserData = targetUserDoc.data();
    final receivedRequests = (targetUserData?['receivedRequests'] as List<dynamic>?)
        ?.map((e) => e as Map<String, dynamic>)
        .toList() ??
        [];
    final alreadyReceived = receivedRequests.any((req) => req['username'] == senderUsername);

    if (alreadySent || alreadyReceived) {
      return 'There is already a pending request with this user.';
    }

    await usersCollection.doc(targetUserId).update({
      'receivedRequests': FieldValue.arrayUnion([
        {
          'username': senderUsername,
          'id': senderUid,
          'partnerTwoDynamic': partnerTwoDynamic,
        },
      ]),
    });

    await usersCollection.doc(senderUid).update({
      'sentRequests': FieldValue.arrayUnion([
        {
          'username': targetUsername,
          'id': targetUserId,
          'partnerOneDynamic': partnerOneDynamic,
        },
      ]),
    });

    _logger.d('Friend request sent successfully from $senderUsername to $targetUsername');
    return 'Friend request sent successfully!';
  } catch (e) {
    _logger.e('Error sending friend request: $e');
    return 'Failed to send friend request: $e';
  }
}

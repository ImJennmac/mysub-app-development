import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:logger/logger.dart';
import 'package:mysub/common/util/logger/logger.dart';
import 'package:mysub/features/partners/pages/swap_partner_profiles.dart';

Logger _logger = MySubLogger.getLogger('UpdateActive');

Future<void> updateActive(String activeValue, String userUid, BuildContext context, String activeDynamic, String activeFriendshipID) async {
  final DocumentReference userDoc = FirebaseFirestore.instance.collection('users').doc(userUid);
  final messenger = ScaffoldMessenger.of(context);

  _logger.d('Starting updateActive with activeUser: $activeValue, activeDynamic: $activeDynamic, activeFriendshipID: $activeFriendshipID');

  try {
    await FirebaseFirestore.instance.runTransaction((transaction) async {
      final DocumentSnapshot snapshot = await transaction.get(userDoc);

      if (!snapshot.exists) {
        _logger.e("User document does not exist!");
        throw Exception("User document does not exist!");
      }

      final Map<String, dynamic> userData = snapshot.data()! as Map<String, dynamic>;

      final Map<String, dynamic> activePartner = {
        'activeUser': activeValue,
        'activeFriendshipID': activeFriendshipID,
        'activeDynamic': activeDynamic,
      };

      _logger.d('Current activePartner data: ${userData['activePartner']}');
      _logger.d('New activePartner data: $activePartner');

      // Only update if the active partner is different
      if (userData['activePartner'] != activePartner) {
        _logger.d('Updating active partner for user $userUid');
        transaction.update(userDoc, {'activePartner': activePartner});
      } else {
        _logger.d('No update needed; active partner is already set to the desired values.');
      }
    });

    messenger.showSnackBar(
      const SnackBar(content: Text('Active partner updated successfully!')),
    );
    _logger.d('Active partner updated successfully for user $userUid');
  } catch (e) {
    messenger.showSnackBar(
      SnackBar(content: Text('Failed to update active partner: $e')),
    );
    _logger.e('Error updating active partner to $activeValue for user $userUid: $e');
  }
}

Future<void> swapPartner(String partnerUsername, String userUid, BuildContext context) async {
  final messenger = ScaffoldMessenger.of(context);
  final navigator = Navigator.of(context);
  final userDoc = await FirebaseFirestore.instance.collection('users').doc(userUid).get();

  if (!userDoc.exists) {
    messenger.showSnackBar(
      const SnackBar(content: Text('User document not found.')),
    );
    return;
  }

  final acceptedFriends = (userDoc.data()?['acceptedFriends'] as List<dynamic>?)
      ?.map((e) => e as Map<String, dynamic>)
      .toList() ?? [];

  final partner = acceptedFriends.firstWhere(
        (friend) => friend['username'] == partnerUsername,
    orElse: () => <String, dynamic>{},
  );

  if (partner.isEmpty) {
    messenger.showSnackBar(
      const SnackBar(content: Text('Partner not found.')),
    );
    return;
  }

  final dynamic friendID = partner['friendID'];
  final String partnerOneDynamic = partner['partnerOneDynamic'] as String? ?? 'Unknown';
  final String partnerTwoDynamic = partner['partnerTwoDynamic'] as String? ?? 'Unknown';

  final bool isSwitch = partnerOneDynamic == 'Switch' || partnerTwoDynamic == 'Switch';

  String activeDynamic = '';
  String activeFriendshipID = '';

  if (isSwitch) {
    final result = await navigator.push<String>(
      MaterialPageRoute(
        builder: (context) => SwapPartnerProfilesPage(partnerUsername: partnerUsername),
      ),
    );

    if (result != null && (result == 'Submissive' || result == 'Dominant')) {
      activeDynamic = result;

      if (friendID is Map<String, dynamic>) {
        if (activeDynamic == 'Submissive') {
          activeFriendshipID = friendID['partnerOneSub'] as String? ?? friendID['partnerTwoSub'] as String? ?? '';
        } else if (activeDynamic == 'Dominant') {
          activeFriendshipID = friendID['partnerOneDom'] as String? ?? friendID['partnerTwoDom'] as String? ?? '';
        }
      } else if (friendID is String) {
        activeFriendshipID = friendID;
      }

      if (activeFriendshipID.isEmpty) {
        messenger.showSnackBar(
          const SnackBar(content: Text('Invalid friendship ID for switch dynamic.')),
        );
        return;
      }

      await updateActive(partner['ID'] as String? ?? '', userUid, context, activeDynamic, activeFriendshipID);
      messenger.showSnackBar(SnackBar(content: Text('Profile updated to $result profile.')));
    } else {
      messenger.showSnackBar(
        const SnackBar(content: Text('Profile update cancelled or invalid selection.')),
      );
      return;
    }
  } else {
    // Handle non-switch dynamics, prioritizing partnerOneDynamic if set
    if (partnerOneDynamic != 'Unknown') {
      activeDynamic = partnerOneDynamic;
    } else if (partnerTwoDynamic != 'Unknown') {
      activeDynamic = partnerTwoDynamic;
    }

    if (friendID is Map<String, dynamic>) {
      if (activeDynamic == 'Submissive') {
        activeFriendshipID = friendID['partnerOneSub'] as String? ?? friendID['partnerTwoSub'] as String? ?? '';
      } else {
        activeFriendshipID = friendID['partnerOneDom'] as String? ?? friendID['partnerTwoDom'] as String? ?? '';
      }
    } else if (friendID is String) {
      activeFriendshipID = friendID;
    }

    if (activeFriendshipID.isEmpty) {
      messenger.showSnackBar(
        const SnackBar(content: Text('Invalid friendship ID for non-switch dynamic.')),
      );
      return;
    }

    await updateActive(partner['ID'] as String? ?? '', userUid, context, activeDynamic, activeFriendshipID);
    messenger.showSnackBar(SnackBar(content: Text('Profile updated to $activeDynamic profile.')));
  }

  _logger.d('Partner swapped to $partnerUsername for user $userUid with activeDynamic: $activeDynamic and activeFriendshipID: $activeFriendshipID');
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fpdart/fpdart.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:logger/logger.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/logger/logger.dart';

Logger _logger = MySubLogger.getLogger('PartnerPermissions');

Future<Map<String, bool>> loadPermissions(
    WidgetRef ref, String partnerId, bool isDominant,) async {
  final Map<String, bool> permissions = {
    'Create new Punishments': false,
    'Edit and Delete existing Punishments': false,
    'Manually add or remove Punishments': false,
    'Complete Punishments': false,
    'Create new Rewards': false,
    'Edit and Delete existing Rewards': false,
    'Manually add or remove Rewards': false,
    'Complete Rewards': false,
    'Add or remove points manually': false,
    'Create new Habits': false,
    'Edit and Delete existing Habits': false,
    'Change Habit History': false,
  };

  try {
    final optionalUser = ref.read(userProvider);
    final user = optionalUser.getOrElse(() => throw Exception("User not found"));
    final userDoc = FirebaseFirestore.instance.collection('users').doc(user.uid);
    final doc = await userDoc.get();

    if (doc.exists) {
      final data = doc.data()!;

      // Explicitly type acceptedFriends
      final List<Map<String, dynamic>> acceptedFriends =
      (data['acceptedFriends'] as List<dynamic>? ?? [])
          .map((e) => e as Map<String, dynamic>)
          .toList();

      final Map<String, dynamic> friendEntry = acceptedFriends.firstWhere(
            (Map<String, dynamic> friend) => friend['ID'] == partnerId,
        orElse: () => <String, dynamic>{},
      );

      final dynamic friendID = friendEntry['friendID'];

      final Map<String, dynamic> partnerPermissions =
          data['partnerPermissions'] as Map<String, dynamic>? ?? {};

      String permissionKey = '';

      if (friendID is Map<String, dynamic>) {
        // Handle Switch case
        if (friendID.containsKey('partnerOneDom') &&
            friendID.containsKey('partnerOneSub')) {
          permissionKey = isDominant
              ? friendID['partnerOneDom']?.toString() ?? ''
              : friendID['partnerOneSub']?.toString() ?? '';
        } else if (friendID.containsKey('partnerTwoDom') &&
            friendID.containsKey('partnerTwoSub')) {
          permissionKey = isDominant
              ? friendID['partnerTwoDom']?.toString() ?? ''
              : friendID['partnerTwoSub']?.toString() ?? '';
        }
      } else if (friendID is String) {
        // Handle non-Switch case
        permissionKey = friendID;
      } else {
        _logger.w('Unexpected friendID type: ${friendID.runtimeType}');
      }

      if (permissionKey.isNotEmpty) {
        final Map<String, dynamic>? perms =
        partnerPermissions[permissionKey] as Map<String, dynamic>?;

        if (perms != null) {
          for (final String perm in permissions.keys) {
            permissions[perm] = perms[perm] as bool? ?? false;
          }
        }
      }
        }

    _logger.d('Permissions loaded successfully for partner $partnerId');
  } catch (e) {
    _logger.e('Error loading permissions for partner $partnerId: $e');
  }

  return permissions;
}

Future<String> updatePermissions(
    WidgetRef ref, String partnerId, Map<String, bool> permissions, bool isDominant,) async {
  try {
    final optionalUser = ref.read(userProvider);
    final user = optionalUser.getOrElse(() => throw Exception("User not found"));
    final userDoc = FirebaseFirestore.instance.collection('users').doc(user.uid);

    final doc = await userDoc.get();
    if (!doc.exists) {
      throw Exception("User document not found");
    }

    final data = doc.data()!;
    final List<Map<String, dynamic>> acceptedFriends =
    (data['acceptedFriends'] as List<dynamic>? ?? [])
        .map((e) => e as Map<String, dynamic>)
        .toList();

    final Map<String, dynamic> friendEntry = acceptedFriends.firstWhere(
          (Map<String, dynamic> friend) => friend['ID'] == partnerId,
      orElse: () => <String, dynamic>{},
    );

    final dynamic friendID = friendEntry['friendID'];
    final Map<String, dynamic> updateData = {};

    _logger.d('FriendID structure: ${friendID.runtimeType} - $friendID');

    String permissionKey = '';

    if (friendID is Map<String, dynamic>) {
      // Handle Switch case
      if (friendID.containsKey('partnerOneDom') &&
          friendID.containsKey('partnerOneSub')) {
        permissionKey = isDominant
            ? friendID['partnerOneDom']?.toString() ?? ''
            : friendID['partnerOneSub']?.toString() ?? '';
      } else if (friendID.containsKey('partnerTwoDom') &&
          friendID.containsKey('partnerTwoSub')) {
        permissionKey = isDominant
            ? friendID['partnerTwoDom']?.toString() ?? ''
            : friendID['partnerTwoSub']?.toString() ?? '';
      } else {
        throw Exception("Invalid switch case structure");
      }

      if (permissionKey.isEmpty) {
        throw Exception("Invalid permission key for switch case");
      }
    } else if (friendID is String) {
      // Handle non-Switch case
      permissionKey = friendID;
    } else {
      _logger.e('Invalid friendID format: ${friendID.runtimeType} - $friendID');
      throw Exception("Invalid friendID format");
    }

    updateData['partnerPermissions.$permissionKey'] = permissions;

    _logger.d('Updating permissions. PermissionKey: $permissionKey');

    // Update current user's document
    await userDoc.update(updateData);

    // Update partner's document
    final partnerDoc =
    FirebaseFirestore.instance.collection('users').doc(partnerId);
    await partnerDoc.update({'partnerPermissions.$permissionKey': permissions});

    _logger.d('Permissions updated successfully for both users');
    return 'Permissions updated successfully!';
  } catch (e) {
    _logger.e('Error updating permissions: $e');
    return 'Failed to update permissions: $e';
  }
}

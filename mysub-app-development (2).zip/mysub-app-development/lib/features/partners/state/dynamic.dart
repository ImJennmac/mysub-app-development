import 'package:flutter/material.dart';
import 'package:fpdart/fpdart.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/button/backarrow.dart';
import 'package:mysub/features/partners/controllers/friend_system.dart';

class DynamicPage extends ConsumerStatefulWidget {
  static const String id = "dynamic_page";
  final String username;

  const DynamicPage({super.key, required this.username});

  @override
  ConsumerState<DynamicPage> createState() => _DynamicPageState();
}

class _DynamicPageState extends ConsumerState<DynamicPage> {
  String selectedDynamic = 'Submissive';

  Future<void> _sendFriendRequest() async {
    final optionalUser = ref.read(userProvider);
    final user = optionalUser.getOrElse(() => throw Exception("User not found"));
    final String senderUsername = user.username.value;

    final result = await sendFriendRequest(
      senderUid: user.uid,
      senderUsername: senderUsername,
      targetUsername: widget.username,
      selectedDynamic: selectedDynamic,
    );

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result)),
      );

      if (result == 'Friend request sent successfully!') {
        Navigator.of(context).pop();
      }
    }
  }

  Widget _buildDynamicOption(String title, String value, String description) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        RadioListTile<String>(
          title: Text(title),
          value: value,
          groupValue: selectedDynamic,
          onChanged: (value) {
            setState(() {
              selectedDynamic = value!;
            });
          },
          contentPadding: EdgeInsets.zero,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 4.0, bottom: 8.0),
          child: Text(
            description,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.textTheme.bodyMedium?.color?.withOpacity(0.6),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const BackArrow(),
                  Expanded(
                    child: Align(
                      child: Text(
                        "Choose Dynamic",
                        style: theme.textTheme.titleMedium,
                      ),
                    ),
                  ),
                  const SizedBox(width: 48),
                ],
              ),
              const SizedBox(height: 20),
              Text(
                'Select your dynamic with this partner: \n\nAdd the dynamic that you are to your partner. \nSo if you are the Dominant, choose Dominant, etc. \n\nIf you select Switch, both profiles will be created for you, and you can swap between both Submissive and Dominant',
                style: theme.textTheme.bodyMedium,
              ),
              const SizedBox(height: 20),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildDynamicOption(
                        'Submissive',
                        'Submissive',
                        "In this dynamic, you prefer to follow your partner's lead.",
                      ),
                      _buildDynamicOption(
                        'Dominant',
                        'Dominant',
                        'In this dynamic, you prefer to take the lead in the relationship.',
                      ),
                      _buildDynamicOption(
                        'Switch',
                        'Switch',
                        'In this dynamic, you enjoy switching between being dominant and submissive.',
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: _sendFriendRequest,
                child: Container(
                  width: double.infinity,
                  height: 50,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10.0),
                    border: Border.all(
                      color: Colors.red,
                      width: 2.0,
                    ),
                  ),
                  child: Center(
                    child: Text(
                      'Send Request',
                      style: theme.textTheme.displaySmall,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

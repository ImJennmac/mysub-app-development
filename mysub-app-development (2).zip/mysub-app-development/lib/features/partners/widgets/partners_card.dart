import 'package:flutter/material.dart';

class PartnerCard extends StatelessWidget {
  final String username;
  final bool isSelected;
  final VoidCallback onSelect;
  final VoidCallback? onDelete;
  final VoidCallback? onAccept;
  final VoidCallback? onReject;
  final VoidCallback? onEditPermissions;
  final VoidCallback? onViewPermissions;
  final bool isPendingRequest;
  final bool accepted;
  final bool isSolo;
  final String? dynamicText;
  final bool isDominant;
  final bool isSwitch;
  final bool currentRoleIsDominant;

  const PartnerCard({
    super.key,
    required this.username,
    required this.isSelected,
    required this.onSelect,
    this.onDelete,
    this.onAccept,
    this.onReject,
    this.onEditPermissions,
    this.onViewPermissions,
    this.isPendingRequest = false,
    this.accepted = false,
    this.isSolo = false,
    this.dynamicText,
    required this.isDominant,
    required this.isSwitch,
    required this.currentRoleIsDominant,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(15.0),
        border: isSelected ? Border.all(color: Colors.red, width: 3.0) : null,
      ),
      margin: const EdgeInsets.all(15.0),
      child: isPendingRequest ? _buildPendingRequestCard(context) : _buildRegularCard(context),
    );
  }

  Widget _buildPendingRequestCard(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const CircleAvatar(
          radius: 50,
          backgroundImage: AssetImage('assets/images/home.png'),
        ),
        const SizedBox(height: 16),
        Text(
          username,
          style: theme.textTheme.displayMedium,
          textAlign: TextAlign.center,
        ),
        if (dynamicText != null)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            child: Text(
              dynamicText!,
              style: const TextStyle(
                fontSize: 16,
                color: Colors.grey,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (onAccept != null)
              ElevatedButton(
                onPressed: onAccept,
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.white,
                  backgroundColor: Colors.green,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                ),
                child: const Text('Accept'),
              ),
            const SizedBox(width: 16),
            if (onReject != null)
              ElevatedButton(
                onPressed: onReject,
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.white,
                  backgroundColor: Colors.red,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                ),
                child: const Text('Reject'),
              ),
          ],
        ),
      ],
    );
  }

  Widget _buildRegularCard(BuildContext context) {
    final theme = Theme.of(context);
    return ListTile(
      title: Text(
        isSolo ? "Solo Profile" : username,
        style: theme.textTheme.displayMedium,
        textAlign: isSolo ? TextAlign.center : TextAlign.left,
      ),
      subtitle: !isSolo && onDelete != null
          ? Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),
          ElevatedButton(
            onPressed: onDelete,
            style: ElevatedButton.styleFrom(
              foregroundColor: Colors.white,
              backgroundColor: Colors.red,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
            ),
            child: const Text('Remove'),
          ),
        ],
      )
          : null,
      trailing: !isSolo
          ? Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Show the settings icon if the user can edit permissions
          if (!isPendingRequest && ((isDominant && !isSwitch) || (isSwitch && currentRoleIsDominant)))
            IconButton(
              icon: Icon(Icons.settings, color: theme.iconTheme.color),
              onPressed: onEditPermissions,
              tooltip: 'Edit Permissions',
            ),
          // Show the shield icon for switch dynamics or if the user can view permissions
          if (isSwitch || (!isDominant && !isSwitch) || isPendingRequest)
            IconButton(
              icon: Icon(Icons.shield, color: theme.iconTheme.color),
              onPressed: onViewPermissions,
              tooltip: 'View Permissions',
            ),
          if (isSelected) const Icon(Icons.check, color: Colors.red),
        ],
      )
          : null,
      onTap: onSelect,
    );
  }
}

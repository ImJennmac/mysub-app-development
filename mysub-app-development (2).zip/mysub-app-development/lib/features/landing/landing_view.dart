import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:mysub/common/services/notification_service.dart';
import 'package:mysub/common/util/assets.dart';
import 'package:mysub/features/auth/views/login_view.dart';
import 'package:mysub/features/auth/views/signup_view.dart';
import 'package:mysub/theme/styles.dart';

class LandingView extends StatefulWidget {
  static const String id = "landing";
  const LandingView({
    super.key,
  });

  @override
  State<LandingView> createState() => _LandingViewState();
}

class _LandingViewState extends State<LandingView> {
  NotificationServices notificationServices = NotificationServices();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    notificationServices.requestNotificationPermission();
    notificationServices.firebaseInit(context);
    notificationServices.isTokenRefresh();
    notificationServices.getDeviceToken().then((value) {
      print("Device Token");
      print(value);
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      body: Center(
        child: SizedBox(
          width: 320,
          child: ListView(
            children: [
              const SizedBox(
                height: 50,
              ),
              SvgPicture.asset(
                kIntenseFeelingAsset,
                width: 250,
                height: 250,
              ),
              const SizedBox(
                height: 30,
              ),
              Text(
                "mysub",
                style: theme.textTheme.titleLarge,
                textAlign: TextAlign.center,
              ),
              const SizedBox(
                height: 30,
              ),
              Text(
                "The best BDSM tracker out there for couples!",
                style: theme.textTheme.displayLarge,
                textAlign: TextAlign.center,
              ),
              const SizedBox(
                height: 40,
              ),
              TextButton(
                style: kPrimaryTextButton,
                onPressed: () => Navigator.pushNamed(context, LoginView.id),
                child: Text(
                  "Sign in",
                  style: theme.textTheme.displayLarge!
                      .copyWith(color: Colors.white),
                ),
              ),
              const SizedBox(
                height: 30,
              ),
              OutlinedButton(
                onPressed: () => Navigator.pushNamed(context, SignUpView.id),
                child: Text(
                  "Sign up for free",
                  style: theme.textTheme.displayLarge,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

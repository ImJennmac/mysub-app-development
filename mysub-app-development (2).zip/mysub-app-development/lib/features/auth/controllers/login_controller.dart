import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:logger/logger.dart';
import 'package:mysub/common/util/extensions.dart';
import 'package:mysub/common/util/helpers.dart';
import 'package:mysub/common/util/logger/logger.dart';
import 'package:mysub/common/value/value_checker.dart';
import 'package:mysub/features/auth/state/login_state.dart';
import 'package:mysub/repositories/impl/auth_repository.dart';

final loginProvider = StateNotifierProvider.autoDispose<LoginController, LoginState>((ref) {
  return LoginController(
    auth: ref.watch(authRepositoryProvider),
    logger: MySubLogger.getLogger((LoginController).toString()),
  );
});

class LoginController extends StateNotifier<LoginState> {
  final AuthRepositoryImpl _auth;
  final Logger _logger;

  LoginController({
    required AuthRepositoryImpl auth,
    required Logger logger,
  })  : _auth = auth,
        _logger = logger,
        super(
          const LoginState(processingData: false),
        );

  void setLoading({required bool loading}) {
    state = state.copyWith(processingData: loading);
    _logger.d('Login state updated: $state');
  }

  Future<User?> logIn({
    required String email,
    required String password,
    required BuildContext context,
  }) async {
    // Check inputs
    final optionalEmail = ValueChecker.checkEmail(context, email);

    // Do not allow further processing if inputs are invalid
    if (optionalEmail.isNone()) {
      return null;
    }

    final optionalPassword = ValueChecker.checkPassword(context, password);
    if (optionalPassword.isNone()) {
      return null;
    }
    setLoading(loading: true);
    final response = await _auth.signIn(
      email: optionalEmail.unwrap(),
      password: optionalPassword.unwrap(),
    );
    return response.match(
      (backendError) {
        showErrorSnackbar(context: context, text: backendError.description);
        setLoading(loading: false);
        return null;
      },
      (user) {
        setLoading(loading: false);

        return user;
      },
    );
  }
}

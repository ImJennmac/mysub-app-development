import 'package:flutter/cupertino.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mysub/common/util/helpers.dart';
import 'package:mysub/repositories/impl/auth_repository.dart';

final recoveryControllerProvider =
    StateNotifierProvider.autoDispose<RecoveryController, bool>((ref) {
  return RecoveryController(
    auth: ref.read(authRepositoryProvider),
  );
});

class RecoveryController extends StateNotifier<bool> {
  final AuthRepositoryImpl auth;

  RecoveryController({
    required this.auth,
  }) : super(false);

  Future<void> sendRecoveryEmail({
    required BuildContext context,
    required String email,
  }) async {
    state = true;
    final output = await auth.sendPasswordResetEmail(email: email);
    state = false;
    output.match(
      (error) => showErrorSnackbar(context: context, text: error),
      (_) => showSnackbar(context: context, text: "The recovery email was sent!"),
    );
  }
}

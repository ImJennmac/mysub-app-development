import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/util/helpers.dart';
import 'package:mysub/features/homepage/home/home_view.dart';
import 'package:mysub/repositories/impl/auth_repository.dart';

final emailVerificationController =
    StateNotifierProvider<EmailVerificationController, bool>((ref) {
  return EmailVerificationController(
    auth: ref.read(authRepositoryProvider),
  );
});

class EmailVerificationController extends StateNotifier<bool> {
  final AuthRepositoryImpl _auth;

  EmailVerificationController({
    required AuthRepositoryImpl auth,
  })  : _auth = auth,
        super(false);

  Future<bool> _validateAccount() async {
    final optional = _auth.currentUser;

    return optional.match(
      () => false,
      (user) async {

        await user.reload();
        final c = _auth.currentUser;

        return c.match(() => false, (u) => u.emailVerified);
      },
    );
  }

  Future<void> onVerifyPressed(BuildContext context) async {
    state = true;
    final validated = await _validateAccount();
    state = false;

    if (context.mounted) {
      if (validated) {
        showMessage(
          context: context,
          message: "Your email has been successfully verified!",
          content: const Icon(
            Icons.done,
            color: Colors.white,
            size: 40,
          ),
          onPostClose: () {
            Navigator.pushReplacementNamed(context, HomeView.id);
          },
        );
      } else {
        showMessage(
          context: context,
          message:
          "We noticed your email address has not been verified. To start using your mysub account, you need to confirm your email address.",
          isError: true,
        );
      }
    }
  }

  Future<void> resendEmail(BuildContext context) async {
    state = true;
    final response = await _auth.sendUserVerificationEmail();
    response.match(
      (l) => showMessage(context: context, message: l, isError: true),
      (_) => showMessage(
        context: context,
        message: "Email verification sent!",
      ),
    );
    state = false;
  }
}

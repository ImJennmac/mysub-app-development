import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:logger/logger.dart';
import 'package:mysub/common/exceptions/backend_exception_mapping.dart';
import 'package:mysub/common/models/signup_request.dart';
import 'package:mysub/common/util/enums.dart';
import 'package:mysub/common/util/extensions.dart';
import 'package:mysub/common/util/helpers.dart';
import 'package:mysub/common/util/logger/logger.dart';
import 'package:mysub/common/util/string_utils.dart';
import 'package:mysub/common/value/value_checker.dart';
import 'package:mysub/features/auth/state/signup_view_state.dart';
import 'package:mysub/features/auth/views/email_verification_view.dart';
import 'package:mysub/repositories/impl/auth_repository.dart';
import 'package:mysub/theme/colors.dart';

final signUpControllerProvider =
    StateNotifierProvider.autoDispose<SignUpController, SignUpViewState>(
  (ref) {
    return SignUpController(
      auth: ref.read(authRepositoryProvider),
      logger: MySubLogger.getLogger((SignUpController).toString()),
    );
  },
  name: (SignUpViewState).toString(),
);

class SignUpController extends StateNotifier<SignUpViewState> {
  final AuthRepositoryImpl _auth;
  final Logger _logger;
  SignUpController({
    required AuthRepositoryImpl auth,
    required Logger logger,
  })  : _auth = auth,
        _logger = logger,
        super(SignUpViewState.empty());

  Future<void> onSubmit(BuildContext context) async {
    _logger.d('Attempting to register user..');
    await register(context);
  }

  void nextStep({
    required GlobalKey<FormState> accountFormKey,
    required GlobalKey<FormState> personalDetailsFormKey,
    required BuildContext context,
  }) {
    if (state.activeStep == 0 &&
        !personalDetailsFormKey.currentState!.validate()) {
      return;
    }
    if (state.activeStep == 1 && !accountFormKey.currentState!.validate()) {
      return;
    }
    if (state.activeStep == state.stepsCount - 1) {
      onSubmit(context);
      return;
    }
    setActiveStep(state.activeStep + 1);
  }

  void previousStep() {
    setActiveStep(state.activeStep - 1);
  }

  void pickPosition(Position pos) {
    if (pos != state.position) {
      state = state.copyWith(position: pos);
    }
  }

  Future<void> pickBirthDay({
    required BuildContext context,
    required TextEditingController birthDayHandler,
  }) async {
    final DateTime dateToday = DateTime.now();
    final DateTime? date = await showDatePicker(
      context: context,
      initialDate:
          DateTime(dateToday.year - 18, dateToday.month, dateToday.day),
      firstDate: DateTime(dateToday.year - 90),
      lastDate: DateTime(dateToday.year - 18, dateToday.month, dateToday.day),
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(primary: kPrimaryColor),
          ),
          child: child!,
        );
      },
    );
    if (date != null) {
      setBirthDay(date);
      birthDayHandler.text = StringUtils.formatDate(date);
    }
  }

  /// Registration algorithm:
  /// 1. wait for user input.
  /// 2. check that the user input is valid.
  /// 3. do not allow further processing otherwise.
  /// 4. set loading animation
  /// 5. get stored user input
  /// 6. create new registration request form.
  /// 7. make the async registration call.
  /// 8. match the response.
  /// 9. if the response is a backend error:
  ///    - remove loading animation
  ///    - show the description
  ///    - go back to step 1
  /// 10. if the responsive is a success:
  ///    - navigNavigator.pushNamedAndRemoveUntil(context, EmailVerificationView.id, (route) => false);ate the user to the login
  ///    - no need to remove the loading animation.
  ///
  Future<void> register(BuildContext context) async {
    // Check inputs
    // Do not allow further processing if inputs are invalid
    final optionalName = ValueChecker.checkName(context, state.fullName);
    if (optionalName.isNone()) {
      setActiveStep(0);
      return;
    }
    final optionalUsername =
        ValueChecker.checkUsername(context, state.username);
    if (optionalUsername.isNone()) {
      setActiveStep(0);
      return;
    }

    final optionalEmail = ValueChecker.checkEmail(context, state.email);
    if (optionalEmail.isNone()) {
      setActiveStep(1);
      return;
    }
    final optionalPassword =
        ValueChecker.checkPassword(context, state.password);
    if (optionalPassword.isNone()) {
      setActiveStep(1);
      return;
    }

    // Set loading animation
    setLoading(loading: true);
    // Unwrap
    final emailVal = optionalEmail.unwrap();
    final passwordVal = optionalPassword.unwrap();
    final nameVal = optionalName.unwrap();
    final usernameVal = optionalUsername.unwrap();

    final SignUpRequest request = SignUpRequest(
      email: emailVal,
      password: passwordVal,
      username: usernameVal,
      fullName: nameVal,
      position: state.position,
      birthday: state.birthDay,
    );
    final response = await _auth.register(request);
    setLoading(loading: false);
    return response.match(
      (backendError) {
        switch (backendError.code) {
          case AuthError.emailAlreadyInUseCode:
          case AuthError.invalidEmailCode:
          case AuthError.weakPasswordCode:
          case AuthError.wrongPasswordCode:
            setActiveStep(1);

          case AuthError.usernameAlreadyInUseCode:
            setActiveStep(0);
        }
        showErrorSnackbar(context: context, text: backendError.description);
      },
      (_) {
        setLoading(loading: false);
        _auth.sendUserVerificationEmail();
        Navigator.pushNamedAndRemoveUntil(
            context, EmailVerificationView.id, (route) => false,);
      },
    );
  }

  // These are the state modifiers:

  void setLoading({required bool loading}) {
    state = state.copyWith(
      processingData: loading,
    );
  }

  void setEmail(String? email) {
    state = state.copyWith(email: email);
  }

  void setUsername(String? username) {
    state = state.copyWith(username: username);
  }

  void setPassword(String? password) {
    state = state.copyWith(password: password);
  }

  void setName(String? name) {
    state = state.copyWith(fullName: name);
  }

  void setBirthDay(DateTime time) {
    state = state.copyWith(birthDay: time);
  }

  void setActiveStep(int i) {
    if (i < 0) {
      return;
    }
    if (i >= SignUpViewState.stepCount) {
      return;
    }
    state = state.copyWith(activeStep: i);
  }
}

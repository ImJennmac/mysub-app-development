import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:lottie/lottie.dart';
import 'package:mysub/common/util/assets.dart';
import 'package:mysub/common/util/helpers.dart';
import 'package:mysub/features/auth/controllers/email_verification_controller.dart';
import 'package:mysub/theme/styles.dart';

class EmailVerificationView extends ConsumerWidget {
  static const String id = "email_verification";
  const EmailVerificationView({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final loading = ref.watch(emailVerificationController);
    final textTheme = Theme.of(context).textTheme;

    return loading
        ? buildLoadingPage()
        : Scaffold(
      appBar: AppBar(
        foregroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pushReplacementNamed('/signup'),
        ),
        title: Text(
          "Verify your email",
          style: textTheme.titleSmall?.copyWith(color: Colors.white),
        ),
      ),
      body: Center(
        child: SizedBox(
          width: 320,
          child: ListView(
            children: [
              LottieBuilder.asset(
                kEmailAnimationAsset,
                width: 200,
                height: 200,
              ),
              const Text(
                "We've sent a verification link to your email address to activate your account.\n\nClick the resend button if you did not receive an email.",
              ),
              const SizedBox(height: 80),
              TextButton(
                style: kPrimaryTextButton,
                onPressed: () async {
                  await ref
                      .read(emailVerificationController.notifier)
                      .onVerifyPressed(context);
                },
                child: Text(
                  "Verify",
                  style: textTheme.displayMedium?.copyWith(color: Colors.white),
                ),
              ),
              const SizedBox(height: 20),
              TextButton(
                style: kPrimaryTextButton,
                onPressed: () async {
                  await ref.read(emailVerificationController.notifier).resendEmail(context);
                },
                child: Text(
                  "Resend",
                  style: textTheme.displayMedium?.copyWith(color: Colors.white),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

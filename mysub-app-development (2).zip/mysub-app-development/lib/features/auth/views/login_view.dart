import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fpdart/fpdart.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/button/backarrow.dart';
import 'package:mysub/common/util/extensions.dart';
import 'package:mysub/common/util/helpers.dart';
import 'package:mysub/common/widgets/visibility_textfield.dart';
import 'package:mysub/features/auth/controllers/login_controller.dart';
import 'package:mysub/features/auth/views/email_verification_view.dart';
import 'package:mysub/features/auth/views/recovery_view.dart';
import 'package:mysub/features/auth/views/signup_view.dart';
import 'package:mysub/features/homepage/home/home_view.dart';
import 'package:mysub/repositories/impl/user_repository.dart';
import 'package:mysub/theme/colors.dart';
import 'package:mysub/theme/styles.dart';

class LoginView extends ConsumerStatefulWidget {
  static const String id = "login";

  const LoginView({super.key});

  @override
  ConsumerState<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends ConsumerState<LoginView> {
  final email = TextEditingController();
  final password = TextEditingController();

  @override
  void dispose() {
    super.dispose();
    email.dispose();
    password.dispose();
  }

  Future<void> logIn() async {
    final navigator = Navigator.of(context);
    final user = await ref.read(loginProvider.notifier).logIn(
          email: email.text,
          password: password.text,
          context: context,
        );
    if (user != null) {
      final optionalUser = await ref.watch(userRepositoryProvider).read(user.toIdentifier());
      optionalUser.match(
        (err) {
          showSnackbar(context: context, text: "An error occurred. Please try again.");
        },
        (userModel) {
          ref.watch(userProvider.notifier).state = Option.of(userModel);
          if (!user.emailVerified) {
            navigator.pushNamedAndRemoveUntil(EmailVerificationView.id, (route) => false);
          } else {
            navigator.pushNamedAndRemoveUntil(HomeView.id, (route) => false);
          }
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final textTheme = theme.textTheme;
    final controller = ref.watch(loginProvider);
    return controller.processingData
        ? buildLoadingPage()
        : Scaffold(
            body: Center(
              child: SizedBox(
                width: 320,
                child: ListView(
                  children: [
                    const SizedBox(height: 50),
                    const Row(
                      children: [
                        BackArrow(),
                      ],
                    ),
                    const SizedBox(height: 50),
                    Text(
                      'Welcome\nback!',
                      style: textTheme.displayLarge,
                    ),
                    const SizedBox(height: 50),
                    Text(
                      "Email",
                      style: textTheme.displayMedium,
                    ),
                    const SizedBox(height: 5),
                    TextFormField(
                      keyboardType: TextInputType.emailAddress,
                      textInputAction: TextInputAction.next,
                      controller: email,
                    ),
                    const SizedBox(height: 30),
                    Text(
                      "Password",
                      style: textTheme.displayMedium,
                    ),
                    const SizedBox(height: 5),
                    VisibilityTextfield(
                      controller: password,
                      onFieldSubmitted: (value) {
                        logIn();
                      },
                    ),
                    const SizedBox(height: 30),
                    TextButton(
                      style: kPrimaryTextButton,
                      onPressed: () async {
                        logIn();
                      },
                      child: const Text("Sign in"),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: <Widget>[
                        Text(
                          "Don't have an account?",
                          style: textTheme.displaySmall,
                        ),
                        const Spacer(),
                        GestureDetector(
                          onTap: () => Navigator.pushNamed(
                            context,
                            SignUpView.id,
                          ),
                          child: Text(
                            "Sign up",
                            style: textTheme.displaySmall!.copyWith(
                              color: kPrimaryColor,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    GestureDetector(
                      onTap: () => Navigator.pushNamed(
                        context,
                        RecoveryView.id,
                        arguments: email.text,
                      ),
                      child: Text(
                        "Forgot password",
                        style: textTheme.displaySmall!.copyWith(
                          color: kPrimaryColor,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
  }
}

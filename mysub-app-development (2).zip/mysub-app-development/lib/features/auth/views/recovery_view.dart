import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mysub/common/util/helpers.dart';
import 'package:mysub/features/auth/controllers/recovery_controller.dart';
import 'package:mysub/theme/styles.dart';

class RecoveryView extends ConsumerStatefulWidget {
  static const String id = "recovery";
  final String loginEmail;
  const RecoveryView(this.loginEmail, {super.key});

  @override
  ConsumerState<RecoveryView> createState() => _RecoveryViewState();
}

class _RecoveryViewState extends ConsumerState<RecoveryView> {
  late final TextEditingController email;
  final formKey = GlobalKey<FormState>();
  @override
  void initState() {
    super.initState();
    email = TextEditingController(text: widget.loginEmail);
  }

  @override
  Widget build(BuildContext context) {
    const vSpace = SizedBox(
      height: 20,
    );
    final theme = Theme.of(context).textTheme;
    final loading = ref.watch(recoveryControllerProvider);
    return loading
        ? buildLoadingPage()
        : Scaffold(
            appBar: AppBar(
              centerTitle: true,
              title: const Text("Reset Password"),
            ),
            body: SafeArea(
              child: Form(
                key: formKey,
                child: Center(
                  child: SizedBox(
                    width: 320,
                    child: ListView(
                      children: <Widget>[
                        const SizedBox(
                          height: 64,
                        ),
                        Center(
                          child: Text(
                            "Resetting your password",
                            style: theme.displayLarge,
                          ),
                        ),
                        const SizedBox(
                          height: 35,
                        ),
                        const Text(
                          "Want to reset your password? Just enter your email below and we'll send you an email reset link!",
                        ),
                        vSpace,
                        const Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            "Email",
                          ),
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        TextFormField(
                          controller: email,
                          // controller: model.emailController,
                          // validator: Validator.validateEmail,
                        ),
                        vSpace,
                        SizedBox(
                          width: double.infinity,
                          child: TextButton(
                            style: kPrimaryTextButton,
                            onPressed: () async {
                              ref.read(recoveryControllerProvider.notifier).sendRecoveryEmail(
                                    context: context,
                                    email: email.text,
                                  );
                            },
                            child: const Text("Reset Password"),
                          ),
                        ),
                        vSpace,
                        SizedBox(
                          width: double.infinity,
                          child: OutlinedButton(
                            onPressed: () => Navigator.pop(context),
                            child: const Text("Back to login"),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
  }
}

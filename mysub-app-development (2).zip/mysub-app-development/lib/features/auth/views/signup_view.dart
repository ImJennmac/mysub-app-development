import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mysub/common/util/enums.dart';
import 'package:mysub/common/util/string_utils.dart';
import 'package:mysub/common/util/validator.dart';
import 'package:mysub/common/widgets/selectable_outlined_button.dart';
import 'package:mysub/common/widgets/visibility_textfield.dart';
import 'package:mysub/features/auth/controllers/signup_controller.dart';
import 'package:mysub/features/auth/widgets/registration_form_scaffold.dart';
import 'package:url_launcher/url_launcher.dart';

class SignUpView extends HookConsumerWidget {
  const SignUpView({super.key});
  static const String id = "/signup";
  static final personalDetailsFormKey = GlobalKey<FormState>();
  static final accountFormKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final loading = ref.watch(signUpControllerProvider.select((value) => value.processingData));
    final activeStep = ref.watch(signUpControllerProvider.select((value) => value.activeStep));
    final position = ref.watch(signUpControllerProvider.select((value) => value.position));
    final termsAccepted = useState<bool>(false);

    final passwordController = useTextEditingController(
      text: ref.watch(signUpControllerProvider).password,
    );

    final birthDayController = useTextEditingController(
      text: StringUtils.formatDate(ref.watch(signUpControllerProvider).birthDay),
    );
    return RegistrationFormScaffold(
      loading: loading,
      activeStep: activeStep,
      onContinue: () {
        if (activeStep == 2 && !termsAccepted.value) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('You must accept the Terms of Service to continue.'),
            ),
          );
          return;
        }
        ref.read(signUpControllerProvider.notifier).nextStep(
          context: context,
          personalDetailsFormKey: personalDetailsFormKey,
          accountFormKey: accountFormKey,
        );
      },
      onCancel: () => ref.read(signUpControllerProvider.notifier).previousStep(),
      steps: [
        Step(
          state: _getStateFor(
            activeStep: activeStep,
            thisStep: 0,
          ),
          isActive: activeStep >= 0,
          title: const Text("Personal details"),
          subtitle: const Text("Name and birthday"),
          content: Form(
            key: personalDetailsFormKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Display Name"),
                const SizedBox(height: 5),
                TextFormField(
                  initialValue: ref.watch(signUpControllerProvider).fullName,
                  decoration: const InputDecoration(
                    hintText: "John Doe1234",
                  ),
                  onChanged: (value) {
                    ref.read(signUpControllerProvider.notifier).setName(value);
                  },
                  validator: Validator.validateNotEmpty,
                  textInputAction: TextInputAction.next,
                ),
                const SizedBox(
                  height: 20,
                ),
                const Text("Username"),
                const SizedBox(height: 5),
                TextFormField(
                  initialValue: ref.watch(signUpControllerProvider).username,
                  decoration: const InputDecoration(
                    hintText: "mysubnsfw",
                  ),
                  onChanged: (value) {
                    ref.read(signUpControllerProvider.notifier).setUsername(value);
                  },
                  validator: Validator.validateNotEmpty,
                  textInputAction: TextInputAction.next,
                ),
                const SizedBox(
                  height: 20,
                ),
                const Text("Date of birth"),
                const SizedBox(height: 5),
                TextFormField(
                  controller: birthDayController,
                  readOnly: true,
                  onTap: () {
                    ref.read(signUpControllerProvider.notifier).pickBirthDay(
                          context: context,
                          birthDayHandler: birthDayController,
                        );
                  },
                ),
              ],
            ),
          ),
        ),
        Step(
          subtitle: const Text('Email and Password'),
          state: _getStateFor(
            activeStep: activeStep,
            thisStep: 1,
          ),
          isActive: activeStep >= 1,
          title: const Text("Account"),
          content: Form(
            key: accountFormKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Email Address"),
                const SizedBox(
                  height: 5,
                ),
                TextFormField(
                  initialValue: ref.watch(signUpControllerProvider).email,
                  decoration: const InputDecoration(
                    hintText: "john@mysubnsfw.com",
                  ),
                  onChanged: (value) {
                    ref.read(signUpControllerProvider.notifier).setEmail(value);
                  },
                  validator: Validator.validateNotEmpty,
                  keyboardType: TextInputType.emailAddress,
                  textInputAction: TextInputAction.next,
                ),
                const SizedBox(
                  height: 20,
                ),
                const Text("Password"),
                const SizedBox(height: 5),
                VisibilityTextfield(
                  controller: passwordController,
                  onChanged: (value) {
                    ref.read(signUpControllerProvider.notifier).setPassword(value);
                  },
                  validator: Validator.validateNotEmpty,
                  textInputAction: TextInputAction.next,
                  keyboardType: TextInputType.visiblePassword,
                  hintText: "Enter your password",
                ),
              ],
            ),
          ),
        ),
        Step(
          state: _getStateFor(
            activeStep: activeStep,
            thisStep: 2,
          ),
          isActive: activeStep >= 2,
          title: const Text("Position"),
          content: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "What position are you?",
              ),
              const SizedBox(
                height: 20,
              ),
              SizedBox(
                width: double.infinity,
                child: Container(
                  decoration: BoxDecoration(
                    color: position == Position.SUBMISSIVE
                        ? Theme.of(context).colorScheme.primary.withOpacity(0.2)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: SelectableOutlinedButton(
                    selected: position == Position.SUBMISSIVE,
                    onPressed: () {
                      ref.read(signUpControllerProvider.notifier).pickPosition(Position.SUBMISSIVE);
                    },
                    child: const Text("Submissive"),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: Container(
                  decoration: BoxDecoration(
                    color: position == Position.SWITCH
                        ? Theme.of(context).colorScheme.primary.withOpacity(0.2)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: SelectableOutlinedButton(
                    selected: position == Position.SWITCH,
                    onPressed: () {
                      ref.read(signUpControllerProvider.notifier).pickPosition(Position.SWITCH);
                    },
                    child: const Text("Switch"),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: Container(
                  decoration: BoxDecoration(
                    color: position == Position.DOMINANT
                        ? Theme.of(context).colorScheme.primary.withOpacity(0.2)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: SelectableOutlinedButton(
                    selected: position == Position.DOMINANT,
                    onPressed: () {
                      ref.read(signUpControllerProvider.notifier).pickPosition(Position.DOMINANT);
                    },
                    child: const Text("Dominant"),
                  ),
                ),
              ),
              // After the position selection widgets
              const SizedBox(height: 20),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Checkbox(
                    value: termsAccepted.value,
                    onChanged: (value) {
                      termsAccepted.value = value ?? false;
                    },
                  ),
                  Expanded(
                    child: GestureDetector(
                      onTap: () async {
                        final url = Uri.parse('https://mysubnsfw.com/pages/legal/tos.html');
                        if (await canLaunchUrl(url)) {
                          await launchUrl(url);
                        } else {
                          // Can't launch the URL, show an error to the user
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Could not open the Terms of Service.'),
                            ),
                          );
                        }
                      },
                      child: RichText(
                        text: TextSpan(
                          style: Theme.of(context).textTheme.displaySmall,
                          children: [
                            const TextSpan(
                              text: 'By signing up, you agree that you are 18+ and agree to our ',
                            ),
                            TextSpan(
                              text: 'Terms of Service',
                              style: TextStyle(
                                color: Theme.of(context).colorScheme.primary,
                                decoration: TextDecoration.underline,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  static StepState _getStateFor({
    required int activeStep,
    required int thisStep,
  }) {
    if (activeStep < thisStep) {
      return StepState.indexed;
    } else if (activeStep == thisStep) {
      return StepState.editing;
    } else {
      return StepState.complete;
    }
  }
}

import 'package:flutter/material.dart';

@immutable
class LoginState {
  final bool processingData;
  const LoginState({
    required this.processingData,
  });

  LoginState copyWith({
    bool? processingData,
  }) {
    return LoginState(
      processingData: processingData ?? this.processingData,
    );
  }

  @override
  String toString() => 'LoginState(processingData: $processingData)';

  @override
  bool operator ==(covariant LoginState other) {
    if (identical(this, other)) return true;

    return other.processingData == processingData;
  }

  @override
  int get hashCode => processingData.hashCode;
}

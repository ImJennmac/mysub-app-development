import 'package:flutter/cupertino.dart';

import 'package:mysub/common/util/enums.dart';

@immutable
class SignUpViewState {
  final String email;
  final String password;
  final String username;
  final String fullName;
  final int activeStep;
  final int stepsCount;
  final Position position;
  final DateTime birthDay;
  final bool processingData;
  static const stepCount = 3;
  const SignUpViewState({
    required this.email,
    required this.password,
    required this.activeStep,
    required this.stepsCount,
    required this.position,
    required this.birthDay,
    required this.processingData,
    required this.username,
    required this.fullName,
  });
  factory SignUpViewState.empty() {
    return SignUpViewState(
      fullName: '',
      username: '',
      email: '',
      password: '',
      activeStep: 0,
      stepsCount: 3,
      position: Position.SUBMISSIVE,
      birthDay: DateTime(DateTime.now().year - 18, DateTime.now().month, DateTime.now().day),
      processingData: false,
    );
  }

  SignUpViewState copyWith({
    String? email,
    String? password,
    String? username,
    String? fullName,
    int? activeStep,
    int? stepsCount,
    Position? position,
    DateTime? birthDay,
    bool? processingData,
  }) {
    return SignUpViewState(
      email: email ?? this.email,
      password: password ?? this.password,
      username: username ?? this.username,
      fullName: fullName ?? this.fullName,
      activeStep: activeStep ?? this.activeStep,
      stepsCount: stepsCount ?? this.stepsCount,
      position: position ?? this.position,
      birthDay: birthDay ?? this.birthDay,
      processingData: processingData ?? this.processingData,
    );
  }

  @override
  String toString() {
    return 'SignUpViewState(email: $email, password: $password, username: $username, fullName: $fullName, activeStep: $activeStep, stepsCount: $stepsCount, position: $position, birthDay: $birthDay, processingData: $processingData)';
  }
}

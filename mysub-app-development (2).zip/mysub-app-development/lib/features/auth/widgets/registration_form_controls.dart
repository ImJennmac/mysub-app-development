import 'package:flutter/material.dart';
import 'package:mysub/theme/colors.dart';
import 'package:mysub/theme/styles.dart';

class RegistrationFormControls extends StatelessWidget {
  final VoidCallback? onContinue;
  final VoidCallback? onCancel;
  const RegistrationFormControls({
    super.key,
    required this.onContinue,
    required this.onCancel,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 20.0),
      child: Row(
        children: [
          Expanded(
            child: TextButton(
              style: kPrimaryTextButton,
              onPressed: onContinue,
              child: const Text("Continue"),
            ),
          ),
          const SizedBox(width: 20),
          Expanded(
            child: TextButton(
              style: kPrimaryTextButton.copyWith(
                backgroundColor: WidgetStateProperty.all(Colors.transparent),
                foregroundColor: WidgetStateProperty.all(kPrimaryColor),
                side: WidgetStateProperty.all(const BorderSide(color: kPrimaryColor)),
              ),
              onPressed: onCancel,
              child: const Text("Back"),
            ),
          ),
        ],
      ),
    );
  }
}

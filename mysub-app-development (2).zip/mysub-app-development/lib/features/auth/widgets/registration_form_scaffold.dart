import 'package:flutter/material.dart';
import 'package:mysub/common/util/breakpoints.dart';
import 'package:mysub/common/util/button/backarrow.dart';
import 'package:mysub/common/util/helpers.dart';
import 'package:mysub/features/auth/widgets/registration_form_controls.dart';
import 'package:mysub/features/landing/landing_view.dart';
import 'package:mysub/theme/colors.dart';

class RegistrationFormScaffold extends StatelessWidget {
  final bool loading;
  final int activeStep;
  final List<Step> steps;
  final VoidCallback onContinue;
  final VoidCallback onCancel;

  const RegistrationFormScaffold({
    super.key,
    required this.loading,
    required this.activeStep,
    required this.steps,
    required this.onContinue,
    required this.onCancel,
  });

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final bool isTablet = size.width >= kTabletMinWidth;
    if (loading) {
      return buildLoadingPage();
    } else {
      final stepper = Stepper(
        onStepContinue: onContinue,
        onStepCancel: onCancel,
        elevation: 0.0,
        type: isTablet ? StepperType.horizontal : StepperType.vertical,
        currentStep: activeStep,
        steps: steps,
        controlsBuilder: (context, details) {
          return RegistrationFormControls(
            onContinue: details.onStepContinue,
            onCancel: details.onStepCancel,
          );
        },
      );
      return Scaffold(
        body: Column(
          children: [
            const SizedBox(height: 25),
            Padding(
              padding: const EdgeInsets.only(top: 50, left: 16, right: 16),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: BackArrow(onPressed: () => Navigator.of(context).popAndPushNamed(LandingView.id),),
                  ),
                  const Center(
                    child: Text(
                      "Registration",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Theme(
                data: Theme.of(context).copyWith(
                  colorScheme: const ColorScheme.light(
                    primary: kPrimaryColor,
                  ),
                ),
                child: isTablet
                    ? Center(
                  child: SizedBox(
                    width: 500,
                    child: stepper,
                  ),
                )
                    : stepper,
              ),
            ),
          ],
        ),
      );
    }
  }
}

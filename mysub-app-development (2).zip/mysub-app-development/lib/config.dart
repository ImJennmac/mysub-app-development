import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:logger/logger.dart';
import 'package:mysub/common/util/logger/logger.dart';

enum EnvType {
  DEVELOPMENT,
  TESTING,
  DEBUGGING,
}

/// Environment configuration singleton
class AppConfig {
  /// The environment type of this instance.
  late final EnvType env;
  // Internal constructor
  AppConfig._internal();

  static final Logger _logger = MySubLogger.getLogger((AppConfig).toString());

  static final AppConfig _instance = AppConfig._internal();

  // Getter for the instance
  static AppConfig get instance => _instance;

  // late constructor to set the environment
  factory AppConfig([EnvType type = EnvType.DEVELOPMENT]) {
    _instance.env = type;
    return _instance;
  }

  static bool get isDev => _instance.env == EnvType.DEVELOPMENT;
  static bool get isTesting => _instance.env == EnvType.TESTING;
  static bool get isDebugging => _instance.env == EnvType.DEBUGGING;

  static final _androidSettings = FirebaseOptions(
    apiKey: dotenv.get("FIREBASE_ANDROID_API_KEY"),
    appId: dotenv.get("FIREBASE_ANDROID_APP_ID"),
    messagingSenderId: dotenv.get("FIREBASE_MESSAGING_SENDER_ID"),
    projectId: dotenv.get("FIREBASE_PROJECT_ID"),
    storageBucket: dotenv.get("FIREBASE_STORAGE_BUCKET"),
  );
  static final _iosSettings = FirebaseOptions(
    apiKey: dotenv.get("FIREBASE_IOS_API_KEY"),
    appId: dotenv.get("FIREBASE_IOS_APP_ID"),
    messagingSenderId: dotenv.get("FIREBASE_MESSAGING_SENDER_ID"),
    projectId: dotenv.get("FIREBASE_PROJECT_ID"),
    storageBucket: dotenv.get("FIREBASE_STORAGE_BUCKET"),
    iosClientId: dotenv.get("FIREBASE_IOS_CLIENT_ID"),
    iosBundleId: dotenv.get("FIREBASE_IOS_BUNDLE_ID"),
  );

  static FirebaseOptions get firebaseSettings {
    _logger.d("Running on $defaultTargetPlatform platform");
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return _androidSettings;
      case TargetPlatform.iOS:
        return _iosSettings;
      default:
        throw UnsupportedError(
          'The platform: $defaultTargetPlatform is not currently supported.',
        );
    }
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mysub/common/util/clamping_scroll_behaviour.dart';
import 'package:mysub/init/startup.dart';
import 'package:mysub/router.dart';
import 'package:mysub/theme/theme_provider.dart';
import 'package:mysub/theme/themes.dart';


class MySub extends ConsumerWidget {
  const MySub({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeProvider);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      scrollBehavior: ClampingScrollBehavior(),
      theme: lightTheme,
      darkTheme: darkTheme,
      themeMode: themeMode,
      home: const StartUp(),
      onGenerateRoute: generateRoutes,
    );
  }
}

import 'package:mysub/common/exceptions/value_exceptions.dart';
import 'package:mysub/common/util/validator.dart';
import 'package:mysub/common/value/value.dart';

class PasswordValue extends Value<String> {
  factory PasswordValue(String? raw) {
    if (raw == null || raw.isEmpty) {
      throw const RequiredValueException();
    } else if (raw.length < Validator.requiredPasswordLength) {
      throw TooShortValueException(raw);
    } else if (!Validator.isValidPassword(raw)) {
      throw IllegalValueException(raw);
    } else {
      return PasswordValue._(raw);
    }
  }

  const PasswordValue._(super.value);
}

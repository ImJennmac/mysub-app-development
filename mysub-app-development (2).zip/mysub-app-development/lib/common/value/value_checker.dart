import 'package:flutter/cupertino.dart';
import 'package:fpdart/fpdart.dart';
import 'package:logger/logger.dart';
import 'package:mysub/common/exceptions/value_exceptions.dart';
import 'package:mysub/common/util/helpers.dart';
import 'package:mysub/common/util/logger/logger.dart';
import 'package:mysub/common/util/validator.dart';
import 'package:mysub/common/value/email_address_value.dart';
import 'package:mysub/common/value/name_value.dart';
import 'package:mysub/common/value/password_value.dart';
import 'package:mysub/common/value/username_value.dart';
import 'package:mysub/common/widgets/dialog.dart';

class ValueChecker {
  static final Logger _logger = MySubLogger.getLogger((ValueChecker).toString());
  const ValueChecker();

  static Option<NameValue> checkName(BuildContext context, String? name) {
    try {
      return Option.of(NameValue(name));
    } on RequiredValueException catch (e) {
      showSnackbar(
        context: context,
        text: "You haven't entered a name yet. Enter one and try again.",
      );
      _logger.d("Thrown exception [${e.code}]: ${e.message}");
      return const Option.none();
    } on IllegalValueException catch (e) {
      showSnackbar(
        context: context,
        text: "The name you've entered is invalid. Enter a valid name and try again.",
      );
      _logger.d("Thrown exception [${e.code}]: ${e.message}");
      return const Option.none();
    }
  }

  static Option<UsernameValue> checkUsername(BuildContext context, String? username) {
    try {
      return Option.of(UsernameValue(username));
    } on RequiredValueException catch (e) {
      showSnackbar(
        context: context,
        text: "You haven't entered an username yet. Enter one and try again.",
      );
      _logger.d("Thrown exception [${e.code}]: ${e.message}");
      return const Option.none();
    } on IllegalValueException catch (e) {
      showSnackbar(
        context: context,
        text: "The username you've entered is invalid. Enter a valid username and try again.",
      );
      _logger.d("Thrown exception [${e.code}]: ${e.message}");
      return const Option.none();
    }
  }

  static Option<EmailAddressValue> checkEmail(BuildContext context, String? email) {
    try {
      return Option.of(EmailAddressValue(email));
    } on RequiredValueException catch (e) {
      showSnackbar(
        context: context,
        text: "You haven't entered an email yet. Enter one and try again.",
      );
      _logger.d("Thrown exception [${e.code}]: ${e.message}");
      return const Option.none();
    } on IllegalValueException catch (e) {
      showSnackbar(
        context: context,
        text: "The email you've entered is invalid. Enter a valid email and try again.",
      );
      _logger.d("Thrown exception [${e.code}]: ${e.message}");
      return const Option.none();
    }
  }

  static Option<PasswordValue> checkPassword(
    BuildContext context,
    String? password, {
    bool showDialog = false,
  }) {
    try {
      return Option.of(PasswordValue(password));
    } on RequiredValueException catch (e) {
      if (showDialog) {
        dialog(
          context: context,
          title: "Invalid Password",
          content: "You haven't entered a password yet. Enter one and try again.",
        );
      } else {
        showSnackbar(
          context: context,
          text: "You haven't entered a password yet. Enter one and try again.",
        );
      }

      _logger.d("Thrown exception [${e.code}]: ${e.message}");
    } on TooShortValueException catch (e) {
      if (showDialog) {
        dialog(
          context: context,
          title: "Invalid Password",
          content: "Password can't be smaller than ${Validator.requiredPasswordLength} characters",
        );
      } else {
        showSnackbar(
          context: context,
          text: "Password can't be smaller than ${Validator.requiredPasswordLength} characters",
        );
      }
      _logger.d("Thrown exception [${e.code}]: ${e.message}");
    } on IllegalValueException catch (e) {
      if (showDialog) {
        dialog(
          context: context,
          title: "Invalid Password",
          content:
              "Your password is missing; a number or a special character or lower / uppercase characters.",
        );
      } else {
        showSnackbar(
          context: context,
          text:
              "Your password is missing; a number or a special character or lower / uppercase characters.",
        );
      }
      _logger.d("Thrown exception [${e.code}]: ${e.message}");
    }
    return const Option.none();
  }
}

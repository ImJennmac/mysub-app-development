import 'package:mysub/common/exceptions/value_exceptions.dart';
import 'package:mysub/common/util/validator.dart';
import 'package:mysub/common/value/value.dart';

class UsernameValue extends Value<String> {
  factory UsernameValue(String? raw) {
    if (raw == null || raw.isEmpty) {
      throw const RequiredValueException();
    } else if (!Validator.isValidUsername(raw)) {
      throw IllegalValueException(raw);
    } else {
      return UsernameValue._(raw);
    }
  }

  const UsernameValue._(super.value);
}

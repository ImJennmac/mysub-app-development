// ignore_for_file: public_member_api_docs, sort_constructors_first
// All Rights Reserved (ARR)
// Copyright (c) 2024 NotSuitable Group LTD
// Created with love by the team at NSG.

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mysub/common/identifier.dart';
import 'package:mysub/common/util/enums.dart';
import 'package:mysub/common/value/email_address_value.dart';
import 'package:mysub/common/value/name_value.dart';
import 'package:mysub/common/value/username_value.dart';

class UserModel {
  final Identifier id;
  final NameValue fullName;
  final UsernameValue username;
  final Position position;
  final DateTime birthDay;
  final String? avatarUrl;
  final Map<String, String> activePartner;
  final int points;

  const UserModel({
    required this.id,
    required this.username,
    required this.fullName,
    required this.position,
    required this.birthDay,
    this.avatarUrl,
    this.activePartner = const {
      'activeDynamic': 'solo',
      'activeFriendshipID': 'solo',
      'activeUser': 'solo',
    },
    this.points = 0,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: Identifier.fromUUID(json["id"] as String),
      fullName: NameValue(json["fullName"] as String),
      username: UsernameValue(json["username"] as String),
      position: Position.values.byName(json["position"] as String),
      birthDay: (json["birthDay"] as Timestamp).toDate(),
      avatarUrl: json["avatarUrl"] as String?,
      activePartner: Map<String, String>.from(json["activePartner"] as Map),
      points: json["points"] as int? ?? 0,
    );
  }

  UserModel copyWith({
    EmailAddressValue? email,
    UsernameValue? username,
    NameValue? fullName,
    Position? position,
    DateTime? birthDay,
    String? avatarUrl,
    Map<String, String>? activePartner,
    int? points,
  }) {
    return UserModel(
      id: id,
      username: username ?? this.username,
      fullName: fullName ?? this.fullName,
      position: position ?? this.position,
      birthDay: birthDay ?? this.birthDay,
      avatarUrl: avatarUrl ?? this.avatarUrl,
      activePartner: activePartner ?? this.activePartner,
      points: points ?? this.points,
    );
  }

  String get usernameValue => username.value;
  String get uid => id.value;
  String get fullNameValue => fullName.value;

  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      "id": id.value,
      "fullName": fullName.value,
      "username": username.value,
      "position": position.name,
      "birthDay": Timestamp.fromDate(birthDay),
      "avatarUrl": avatarUrl,
      "activePartner": activePartner,
      "points": points,
    };
  }

  @override
  String toString() {
    return "UID: $id USERNAME: $username";
  }

  @override
  bool operator ==(covariant UserModel other) {
    if (identical(this, other)) return true;

    return other.id == id &&
        other.fullName == fullName &&
        other.username == username &&
        other.position == position &&
        other.birthDay == birthDay &&
        other.avatarUrl == avatarUrl;
  }

  @override
  int get hashCode {
    return id.hashCode ^
        fullName.hashCode ^
        username.hashCode ^
        position.hashCode ^
        birthDay.hashCode ^
        avatarUrl.hashCode;
  }
}

import 'package:flutter/cupertino.dart';
import 'package:mysub/common/util/enums.dart';
import 'package:mysub/common/value/email_address_value.dart';
import 'package:mysub/common/value/name_value.dart';
import 'package:mysub/common/value/password_value.dart';
import 'package:mysub/common/value/username_value.dart';

@immutable
class SignUpRequest {
  final EmailAddressValue email;
  final PasswordValue password;
  final UsernameValue username;
  final NameValue fullName;
  final Position position;
  final DateTime birthday;
  final Map<String, String> activePartner;
  final int points;

  const SignUpRequest({
    required this.email,
    required this.password,
    required this.username,
    required this.fullName,
    required this.position,
    required this.birthday,
    this.activePartner = const {
      'activeDynamic': 'solo',
      'activeFriendshipID': 'solo',
      'activeUser': 'solo',
    },
    this.points = 0,
  });

  @override
  String toString() {
    return 'SignUpRequest(email: $email, password: $password, username: $username, fullName: $fullName, points: $points)';
  }
}

abstract class BackendError {
  const BackendError();
  String get code;
  String get title;
  String get description;
}

class AuthError extends BackendError {
  static const String emailAlreadyInUseCode = "email-already-in-use";
  static const String invalidEmailCode = "invalid-email";
  static const String weakPasswordCode = "weak-password";
  static const String userNotFoundCode = "user-not-found";
  static const String wrongPasswordCode = "wrong-password";
  static const String opNotAllowedCode = "operation-not-allowed";
  static const String popupClosedByUserCode = "popup-closed-by-user";
  static const String invalidCredentialsCode = "invalid-credential";
  static const String unauthenticatedCode = "unauthenticated";
  static const String usernameAlreadyInUseCode = "username-already-in-use";

  @override
  final String code;
  @override
  final String title;
  @override
  final String description;
  // AuthError constructor
  const AuthError({
    required this.code,
    required this.title,
    required this.description,
  });

  static const emailAlreadyInUse = AuthError(
    code: emailAlreadyInUseCode,
    title: "Email in Use",
    description: "This email is already being used.",
  );

  static const usernameAlreadyInUse = AuthError(
    code: usernameAlreadyInUseCode,
    title: "Username in Use",
    description: "This username is already being used.",
  );

  static const invalidEmail = AuthError(
    code: invalidEmailCode,
    title: "Invalid Email",
    description: "The email you've entered is invalid.",
  );
  static const weakPassword = AuthError(
    code: weakPasswordCode,
    title: "Weak Password",
    description: "Your password must be at least 8 characters long.",
  );

  static const accountNotFound = AuthError(
    code: userNotFoundCode,
    title: "Account not found",
    description:
        "This account was not found in our records. Check your email and try again.",
  );

  static const wrongPassword = AuthError(
    code: wrongPasswordCode,
    title: "Invalid Credentials",
    description: "You have entered an invalid email or password.",
  );
  static const opNotAllowed = AuthError(
    code: opNotAllowedCode,
    title: "Operation not Allowed",
    description: "Please reach out to our support team.",
  );
  static const unauthenticated = AuthError(
    code: unauthenticatedCode,
    title: "Sign in again",
    description: "Looks like your session expired. Please sign in again.",
  );
  static const closedByUser = AuthError(
    code: popupClosedByUserCode,
    title: "Cancelled by User",
    description: "The operation was canceled by the user.",
  );

  static const invalidCredentials = AuthError(
    code: "invalid-credentials",
    title: "Invalid Credentials",
    description: "The email or password you've entered is incorrect.",
  );
  static const unknown = AuthError(
    code: "unknown",
    title: "Unknown Error",
    description: "Please reach out to support.",
  );

  static BackendError mapCode(String code) {
    switch (code) {
      case emailAlreadyInUseCode:
        return emailAlreadyInUse;
      case invalidEmailCode:
        return invalidEmail;
      case weakPasswordCode:
        return weakPassword;
      case userNotFoundCode:
        return accountNotFound;
      case wrongPasswordCode:
        return wrongPassword;
      case opNotAllowedCode:
        return opNotAllowed;
      case popupClosedByUserCode:
        return closedByUser;
      case unauthenticatedCode:
        return unauthenticated;
      case invalidCredentialsCode:
        return invalidCredentials;
      default:
        return unknown;
    }
  }
}

class DatabaseError extends BackendError {
  @override
  final String code;
  @override
  final String title;
  @override
  final String description;
  // AuthError constructor
  const DatabaseError({
    required this.code,
    required this.title,
    required this.description,
  });
  static const unknown = DatabaseError(
    code: "unknown",
    title: "Unknown Error",
    description: "Please reach out to support.",
  );

  static BackendError mapCode(String code) {
    switch (code) {
      default:
        return unknown;
    }
  }
}

import 'package:flutter/cupertino.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:mysub/theme/colors.dart';

/// This is the a wrapper over [SpinKitCircle] loading indicator
/// that combines the primary and dark color of the app.
///
/// The loading indicator inform users about the status of ongoing processes,
/// such as loading an app, submitting a form, or saving updates.
class DotsLoadingIndicator extends StatelessWidget {
  final double size;
  const DotsLoadingIndicator({
    super.key,
    this.size = 120.0,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SpinKitCircle(
        itemBuilder: (BuildContext context, int index) {
          final List<Color> colors = <Color>[kPrimaryColor, kDarkColor];
          final Color color = colors[index % colors.length];
          return DecoratedBox(
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
            ),
          );
        },
        size: size,
      ),
    );
  }
}

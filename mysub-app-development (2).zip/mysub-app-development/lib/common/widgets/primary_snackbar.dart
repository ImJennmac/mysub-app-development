import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:mysub/common/util/helpers.dart';
import 'package:mysub/theme/colors.dart';
import 'package:mysub/theme/styles.dart';

class PrimarySnackBar extends StatelessWidget {
  final String text;
  final bool isError;
  const PrimarySnackBar(
    this.text, {
    super.key,
    this.isError = false,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        IntrinsicHeight(
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: kPrimaryColor,
              borderRadius: circularRadius(20),
            ),
            child: Row(
              children: [
                const SizedBox(
                  width: 48,
                ),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (isError) ...{
                        Text(
                          "Oh no!",
                          style: kHeadline2.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      },
                      Text(
                        text,
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        Positioned(
          bottom: 0,
          child: ClipRRect(
            borderRadius: const BorderRadius.only(
              bottomLeft: Radius.circular(20),
            ),
            child: SvgPicture.asset(
              'assets/svg/bubbles.svg',
              height: 48,
              width: 40,
            ),
          ),
        ),
      ],
    );
  }
}

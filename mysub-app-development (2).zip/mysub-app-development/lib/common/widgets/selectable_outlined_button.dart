import 'package:flutter/material.dart';

class SelectableOutlinedButton extends StatelessWidget {
  final ButtonStyle? style;
  final bool selected;
  final Widget child;
  final VoidCallback onPressed;

  const SelectableOutlinedButton({
    super.key,
    this.style,
    this.selected = false,
    required this.child,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    // Use the theme's text color as default color
    final Color defaultColor = theme.textTheme.bodyLarge?.color ?? Colors.white;

    return OutlinedButton(
      style: style ??
          OutlinedButton.styleFrom(
            side: BorderSide(
              color: selected ? colorScheme.primary : defaultColor,
              width: 1.5,
            ),
            foregroundColor: selected
                ? (theme.brightness == Brightness.dark ? Colors.black : Colors.white)
                : defaultColor,
            backgroundColor: selected ? colorScheme.primary : Colors.transparent,
            textStyle: theme.textTheme.labelLarge,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(5.0),
            ),
          ),
      onPressed: onPressed,
      child: child,
    );
  }
}

import 'package:flutter/material.dart';
import 'package:mysub/theme/colors.dart';

void dialog({
  required BuildContext context,
  required String title,
  required String content,
  String actionText = "OK",
  VoidCallback? action,
}) {
  showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        title: Text(title, style: const TextStyle(color: kPrimaryColor)),
        content: Text(content),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              if (action != null) {
                action();
              }
            },
            child: Text(actionText, style: const TextStyle(color: kPrimaryColor)),
          ),
        ],
      );
    },
  );
}

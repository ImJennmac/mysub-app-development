import 'package:flutter/cupertino.dart';
import 'package:mysub/common/util/helpers.dart';

class TermsOfService extends StatelessWidget {
  static const String TOS_URL = "https://mysubnsfw.com/pages/legal/tos";
  static const String PRIVACY_URL = "https://mysubnsfw.com/pages/legal/privacy";
  const TermsOfService({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        GestureDetector(
          onTap: () async {
            await launchBrowserWithUrl(context, TOS_URL);
          },
          child: const Text("Terms of Service"),
        ),
        const Spacer(),
        GestureDetector(
          onTap: () async {
            await launchBrowserWithUrl(context, PRIVACY_URL);
          },
          child: const Text("Privacy Policy"),
        ),
      ],
    );
  }
}

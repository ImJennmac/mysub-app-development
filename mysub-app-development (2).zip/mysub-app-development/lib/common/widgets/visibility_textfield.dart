import 'package:flutter/material.dart';
import 'package:mysub/theme/colors.dart';

class VisibilityTextfield extends StatefulWidget {
  final String? hintText;
  final Widget? prefixIcon;
  final TextEditingController? controller;
  final ValueChanged<String>? onFieldSubmitted;
  final String? Function(String? value)? validator;
  final ValueChanged<String>? onChanged; // Added
  final TextInputAction? textInputAction; // Added
  final TextInputType? keyboardType; // Added

  const VisibilityTextfield({
    super.key,
    this.hintText,
    this.prefixIcon,
    this.controller,
    this.onFieldSubmitted,
    this.validator,
    this.onChanged, // Added
    this.textInputAction, // Added
    this.keyboardType, // Added
  });

  @override
  State<VisibilityTextfield> createState() => _VisibilityTextfieldState();
}

class _VisibilityTextfieldState extends State<VisibilityTextfield> {
  bool obscureText = true;

  void updateVisibility() {
    setState(() {
      obscureText = !obscureText;
    });
  }

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: widget.controller,
      obscureText: obscureText,
      onFieldSubmitted: widget.onFieldSubmitted,
      validator: widget.validator,
      onChanged: widget.onChanged, // Added
      textInputAction: widget.textInputAction, // Added
      keyboardType: widget.keyboardType, // Added
      decoration: InputDecoration(
        hintText: widget.hintText,
        prefixIcon: widget.prefixIcon,
        suffixIcon: IconButton(
          onPressed: updateVisibility,
          icon: Icon(
            obscureText ? Icons.visibility_off : Icons.visibility,
            color: kPrimaryColor,
          ),
        ),
      ),
    );
  }
}

import 'package:mysub/config.dart';

/// The validator class contains a set helper functions
/// for validating text field inputs.
///
/// **Note**: Validator helper functions are disabled when [AppConfig.isDev]
/// is active.
class Validator {
  const Validator._();

  static const int requiredPasswordLength = 8;

  /// Validates a real name, which can only contain
  /// letters.
  /// - 2 letters required
  ///
  static String? validateRealName(String? realName) {
    if (AppConfig.isDev) {
      return null;
    }
    final RegExp regExp = RegExp(
      r'^[^\n0-9_!¡?÷?¿\/\\+=@#$%ˆ&*(){}|~<>;:[\]]{2,}$',
    );
    if (realName == null || realName.isEmpty) {
      return "Please enter a name.";
    } else if (!regExp.hasMatch(realName.trim())) {
      return "Please enter a valid name.";
    } else {
      return null;
    }
  }

  static bool isValidName(String? realName) {
    return validateRealName(realName) == null;
  }

  /// Username validation.
  /// An username is only allowed to have
  /// letters and numbers. Anything else will be rejected.
  static String? validateUsername(String? username) {
    if (AppConfig.isDev) {
      return null;
    }
    final RegExp regExp = RegExp(
      r'^[^-\s](?=.{4,28}$)(?![_.])(?!.*[_.]{2})[a-zA-Z0-9._]+(?<![_.])$',
    );
    if (username == null || username.isEmpty) {
      return "Please enter a username.";
    } else if (!regExp.hasMatch(username)) {
      return "Please enter a valid username";
    } else {
      return null;
    }
  }

  static bool isValidUsername(String? username) {
    return validateUsername(username) == null;
  }

  /// Validates that the given email is **valid**
  /// by processing the characters with the regex expression.
  ///
  /// If the email is valid, a null pointer will be returned,
  /// meaning there is no error to show to the user. Otherwise
  /// you'll get the apropriate error message.
  static String? validateEmail(String? email) {
    if (AppConfig.isDev) {
      return null;
    }
    // This Regex expression was taken from: https://stackoverflow.com/questions/46155/how-can-i-validate-an-email-address-in-javascript
    // Dart regular expressions have the same syntax and semantics as JavaScript regular expressions.
    final RegExp regExp = RegExp(
      r'^[^-\s](([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$',
    );
    if (email == null || email.isEmpty) {
      return "Please enter a valid email.";
    } else if (!regExp.hasMatch(email)) {
      return "Enter a valid email";
    } else {
      return null;
    }
  }

  static bool isValidEmail(String? email) {
    return validateEmail(email) == null;
  }

  /// Validates that the given password is **valid**.
  ///
  /// With a valid password we mean:
  /// - A password with at least 8 characters
  /// - A password with at least 1 number
  /// - A password with a special character
  /// - A password with box uppercase and lowercase letters.
  ///
  /// If the password is valid, a null pointer will be returned,
  /// meaning there is no error to show to the user. Otherwise
  /// you'll get the appropriate error message.
  static String? validatePassword(String? password) {
    if (AppConfig.isDev) {
      return null;
    }
    final RegExp regExp = RegExp(r"^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$");
    if (password == null || password.isEmpty) {
      return "Please enter a valid password.";
    } else if (password.length < requiredPasswordLength) {
      return "Password can't be smaller than $requiredPasswordLength characters";
    } else if (!regExp.hasMatch(password.trim())) {
      return "Your password is missing; a number or a special character or lower / uppercase characters.";
    } else {
      return null;
    }
  }

  static bool isValidPassword(String? password) {
    return validatePassword(password) == null;
  }

  /// Validates that both passwords are completely **equal** by comparing
  /// their address in memory.
  ///
  /// This does not cares on whether the passwords are valid or not,
  /// it simply makes a string reference comparison.
  ///
  /// If the passwords match, a null pointer will be returned,
  /// meaning there is no error to show to the user. Otherwise
  /// you'll get the appropriate error message.
  static String? doPasswordsMatch(String? password, String? confirmation) {
    if (password != confirmation) {
      // false, they have different address in memory.
      return "The passwords entered do not match";
    } else {
      // true, they are the same object in memory
      return null;
    }
  }

  /// Validates that the given text is NOT empty.
  ///
  /// If it's empty a message will be returned for displaying
  /// to the user.
  static String? validateNotEmpty(String? val) {
    if (val == null || val.isEmpty) {
      return "Required Field";
    } else {
      return null;
    }
  }
}

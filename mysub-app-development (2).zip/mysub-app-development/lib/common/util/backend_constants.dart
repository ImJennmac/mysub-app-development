class DatabaseCollections {
  static const String usersCollectionID = "users";
  static const String usernamesCollectionID = "usernames";
}

// TESTING TEXT HERE

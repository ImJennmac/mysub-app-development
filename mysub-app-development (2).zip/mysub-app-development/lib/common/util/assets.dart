const String _imageAssetsFolder = "assets/images";
const String _animationAssetsFolder = "assets/animations";
const String _imageNavBarFolder = "assets/images/navbar";
const String _imageSettingsFolder = "assets/images/settings";

const String kIntenseFeelingAsset = "$_imageAssetsFolder/intense_feeling.svg";
const String kDepartingSvg = "$_imageAssetsFolder/departing.svg";

const String kHomeIcon = "$_imageAssetsFolder/home.png";
const String kSettingsIcon = "$_imageAssetsFolder/settings.png";

const String kAddPartner = "$_imageSettingsFolder/add_partners.png";
const String kDelete = "$_imageSettingsFolder/delete.png";
const String kEdit = "$_imageSettingsFolder/edit.png";
const String kEmail = "$_imageSettingsFolder/email.png";
const String kLogout = "$_imageSettingsFolder/logout.png";
const String kPremium = "$_imageSettingsFolder/premium.png";

const String habitsIcon = "$_imageNavBarFolder/habits.png";
const String notes = "$_imageNavBarFolder/notes.png";
const String rewards = "$_imageNavBarFolder/rewards.png";
const String punishments = "$_imageNavBarFolder/punishments.png";

const String kLock = "$_imageAssetsFolder/lock.png";
const String kPassword = "$_imageAssetsFolder/password.png";

const String kEmailAnimationAsset = "$_animationAssetsFolder/email_verification.json";

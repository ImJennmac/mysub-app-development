class StringUtils {
  static String formatDate(DateTime time) {
    const String separator = "/";
    return "${time.year}$separator" "${time.month}$separator" "${time.day}";
  }
}

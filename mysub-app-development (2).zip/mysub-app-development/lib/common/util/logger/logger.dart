import 'package:logger/logger.dart';
import 'package:mysub/common/util/logger/log_printer.dart';

class MySubLogger {
  static Logger getLogger(String className) {
    final Level level;
    // if (AppConfig.isDebugging) {
    //   level = Level.debug;
    // } else {
    //   level = Level.info;
    // }
    level = Level.debug;
    return Logger(
      printer: MySubLogPrinter(
        className: className,
      ),
      level: level,
    );
  }
}

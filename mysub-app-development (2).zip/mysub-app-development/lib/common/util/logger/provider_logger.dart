import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mysub/common/util/logger/logger.dart';

class ProviderLogger extends ProviderObserver {
  @override
  void didUpdateProvider(
    ProviderBase provider,
    Object? previousValue,
    Object? newValue,
    ProviderContainer container,
  ) {
    MySubLogger.getLogger(provider.name ?? 'provider').d('New state: $newValue');
  }
}

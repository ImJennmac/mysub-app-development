import 'package:flutter/material.dart';
import 'package:mysub/theme/theme_extension.dart';

class SmalLBoxArrow extends StatelessWidget {
  final VoidCallback onTap;

  const SmalLBoxArrow({super.key, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final customTheme = theme.extension<CustomThemeExtension>();

    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 30,
        height: 30,
        decoration: BoxDecoration(
          color: customTheme?.cardColorDarker,
          borderRadius: BorderRadius.circular(4),
        ),
        child: Center(
          child: Icon(
            Icons.arrow_forward,
            size: 20,
            color: theme.textTheme.bodySmall?.color,
          ),
        ),
      ),
    );
  }
}

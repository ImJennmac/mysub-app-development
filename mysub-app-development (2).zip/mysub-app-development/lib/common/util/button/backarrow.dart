import 'package:flutter/material.dart';

class BackArrow extends StatelessWidget {
  final VoidCallback? onPressed;

  const BackArrow({super.key, this.onPressed});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFF9D122D),
            Color(0xFFEC1942),
            Color(0xFFFF617F),
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        borderRadius: BorderRadius.circular(13),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            spreadRadius: 1,
            blurRadius: 5,
          ),
        ],
      ),
      child: IconButton(
        icon: const Icon(Icons.arrow_back, color: Colors.white),
        onPressed: onPressed ??
                () {
              if (Navigator.canPop(context)) {
                Navigator.pop(context);
              }
            },
      ),
    );
  }
}

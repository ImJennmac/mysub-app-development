import 'package:flutter/material.dart';

class LargeBinButton extends StatelessWidget {
  final VoidCallback onPressed;

  const LargeBinButton({super.key, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 15),
      child: SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(
          onPressed: onPressed,
          icon: Icon(
            Icons.delete,
            color: theme.colorScheme.onError,
          ),
          label: Text(
            'Delete',
            style: TextStyle(color: theme.colorScheme.onError),
          ),
          style: ElevatedButton.styleFrom(
            backgroundColor: theme.colorScheme.primary,
            padding: const EdgeInsets.all(15),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            ),
          ),
        ),
      ),
    );
  }
}

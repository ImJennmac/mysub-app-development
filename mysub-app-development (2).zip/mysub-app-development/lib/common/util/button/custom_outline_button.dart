import 'package:flutter/material.dart';

class CustomOutlineButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;
  final bool isRedButton;

  const CustomOutlineButton({
    super.key,
    required this.text,
    required this.onPressed,
    this.isRedButton = false,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    // Define colors based on the theme and isRedButton
    final Color buttonColor = isRedButton ? theme.colorScheme.primary : Colors.transparent;
    final Color borderColor = isRedButton ? theme.colorScheme.primary : theme.colorScheme.primary;
    final Color textColor = isRedButton ? theme.colorScheme.onError : theme.colorScheme.onSurface;

    return GestureDetector(
      onTap: onPressed,
      child: Container(
        width: double.infinity,
        height: 50,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10.0),
          color: buttonColor,
          border: Border.all(
            color: borderColor,
            width: 2.0,
          ),
        ),
        child: Center(
          child: Text(
            text,
            style: theme.textTheme.displayMedium?.copyWith(
              color: textColor,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}

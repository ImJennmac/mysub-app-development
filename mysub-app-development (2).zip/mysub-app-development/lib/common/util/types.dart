import 'package:fpdart/fpdart.dart';
import 'package:mysub/common/exceptions/backend_exception_mapping.dart';
import 'package:mysub/common/models/user_model.dart';

typedef FutureResult<T> = Future<Either<String, T>>;
typedef OptionalUser = Option<UserModel>;
typedef BackendResult<T> = Either<BackendError, T>;

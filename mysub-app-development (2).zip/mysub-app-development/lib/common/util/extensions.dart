import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fpdart/fpdart.dart';
import 'package:mysub/common/exceptions/backend_errors.dart';
import 'package:mysub/common/identifier.dart';
import 'package:mysub/common/models/user_model.dart';
import 'package:mysub/common/util/backend_constants.dart';

extension OptionalUtils<T> on Option<T> {
  T unwrap() {
    return getOrElse(() => throw Exception("called `Optional.unwrap()` on a `None` value"));
  }
}

extension FirebaseUserID on User {
  Identifier toIdentifier() {
    return Identifier.fromUUID(uid);
  }
}

extension DatabaseHelper on FirebaseFirestore {
  /// Reads a user document from the database. The returned json is automatically
  /// converted into a [UserModel] object. If for some reason the json data does
  /// not exists, it will throw a [NullDocumentError] and the application will crash.
  DocumentReference<UserModel> referenceDocument(Identifier identifier) {
    return collection(DatabaseCollections.usersCollectionID).doc(identifier.value).withConverter(
      fromFirestore: (snapshot, options) {
        final json = snapshot.data();
        if (json == null) {
          throw NullDocumentError();
        }
        return UserModel.fromJson(json);
      },
      toFirestore: (value, options) {
        return value.toJson();
      },
    );
  }
}

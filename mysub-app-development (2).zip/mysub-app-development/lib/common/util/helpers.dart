import 'package:flutter/material.dart';
import 'package:mysub/common/widgets/circular_dots_loading_indicator.dart';
import 'package:mysub/common/widgets/primary_snackbar.dart';
import 'package:mysub/theme/colors.dart';
import 'package:mysub/theme/styles.dart';
import 'package:url_launcher/url_launcher.dart';

SizedBox vSpace({int multiplier = 1, double base = 20.0}) {
  return SizedBox(
    height: base * multiplier,
  );
}

Future<bool> launchBrowserWithUrl(BuildContext context, String url) async {
  try {
    final Uri uri = Uri.parse(url);
    final canLaunch = await canLaunchUrl(uri);
    if (!canLaunch && context.mounted) {
      showErrorSnackbar(context: context, text: "Cannot launch URL");
      return false;
    }
    return launchUrl(uri, mode: LaunchMode.externalApplication);
  } catch (e) {
    if (context.mounted) {
      showErrorSnackbar(context: context, text: e.toString());
    }
    return false;
  }
}

BorderRadius circularRadius(double radius) {
  return BorderRadius.all(
    Radius.circular(radius),
  );
}

SnackBar buildDecoratedSnackbar({
  required String text,
  bool error = false,
}) {
  return SnackBar(
    content: PrimarySnackBar(
      text,
      isError: error,
    ),
    behavior: SnackBarBehavior.floating,
    backgroundColor: Colors.transparent,
    elevation: 0.0,
  );
}

void showSnackbar({
  required BuildContext context,
  required String text,
}) {
  ScaffoldMessenger.of(context).showSnackBar(
    buildDecoratedSnackbar(
      text: text,
    ),
  );
}

void showErrorSnackbar({
  required BuildContext context,
  required String text,
}) {
  ScaffoldMessenger.of(context).showSnackBar(
    buildDecoratedSnackbar(
      text: text,
      error: true,
    ),
  );
}

void showMessage({
  required BuildContext context,
  required String message,
  VoidCallback? onPreClose,
  VoidCallback? onPostClose,
  Widget? content,
  bool isError = false,
}) {
  showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        backgroundColor: kPrimaryColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (isError)
              Text(
                "Oh no!",
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            Text(
              message,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.white),
            ),
          ],
        ),
        content: content != null
            ? DefaultTextStyle(
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.white) ?? const TextStyle(color: Colors.white),
          child: content,
        )
            : null,
        actions: [
          TextButton(
            style: kPrimaryTextButton.copyWith(
              foregroundColor: WidgetStateProperty.all(Colors.white),
            ),
            onPressed: () {
              onPreClose?.call();
              Navigator.pop(context);
              onPostClose?.call();
            },
            child: const Text("OK"),
          ),
        ],
      );
    },
  );
}

Scaffold buildLoadingPage() {
  return const Scaffold(
    body: DotsLoadingIndicator(),
  );
}

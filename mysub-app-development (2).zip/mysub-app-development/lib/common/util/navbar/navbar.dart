import 'package:flutter/material.dart';
import 'package:mysub/common/util/assets.dart';
import 'package:mysub/features/explore/habits/habits_view.dart';
import 'package:mysub/features/explore/notes/noteshome_view.dart';
import 'package:mysub/features/explore/punishments/punishments_view.dart';
import 'package:mysub/features/explore/rewards/rewards_view.dart';

class NavBar extends StatefulWidget {
  static const String id = 'navbar';
  const NavBar({
    super.key,
  });

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  int _selectedIndex = 0;

  void _onItemTap(int index) {
    setState(() {
      _selectedIndex = index;
    });
    switch (index) {
      case 0:
        Navigator.pushNamed(context, HabitsView.id);
      case 1:
        Navigator.pushNamed(context, RewardsView.id);
      case 2:
        Navigator.pushNamed(context, PunishmentsView.id);
      case 3:
        Navigator.pushNamed(context, NotesHomeView.id);
      default:
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex,
        onTap: _onItemTap,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: ImageIcon(AssetImage(habitsIcon)),
            label: 'Habits',
          ),
          BottomNavigationBarItem(
            icon: ImageIcon(AssetImage(rewards)),
            label: 'Rewards',
          ),
          BottomNavigationBarItem(
            icon: ImageIcon(AssetImage(punishments)),
            label: 'Punishments',
          ),
          BottomNavigationBarItem(
            icon: ImageIcon(AssetImage(notes)),
            label: 'Notes',
          ),
        ],
        unselectedFontSize: 14.0,
      ),
    );
  }
}

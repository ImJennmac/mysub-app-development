const int kTabletMinWidth = 600;

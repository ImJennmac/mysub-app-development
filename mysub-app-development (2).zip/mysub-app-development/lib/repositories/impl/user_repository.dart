import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fpdart/fpdart.dart';
import 'package:logger/logger.dart';
import 'package:mysub/common/exceptions/backend_exception_mapping.dart';
import 'package:mysub/common/identifier.dart';
import 'package:mysub/common/models/user_model.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/backend_constants.dart';
import 'package:mysub/common/util/extensions.dart';
import 'package:mysub/common/util/logger/logger.dart';
import 'package:mysub/common/util/types.dart';
import 'package:mysub/repositories/interface/user_repository_facade.dart';

final userRepositoryProvider = Provider((ref) {
  return UserRepositoryImpl(
    logger: MySubLogger.getLogger((UserRepositoryImpl).toString()),
    firestore: ref.watch(databaseProvider),
    ref: ref,
  );
});

class UserRepositoryImpl implements IUserRepositoryFacade {
  final Logger _logger;
  final FirebaseFirestore _database;
  final Ref _ref;
  UserRepositoryImpl({
    required Logger logger,
    required FirebaseFirestore firestore,
    required Ref ref,
  })  : _logger = logger,
        _ref = ref,
        _database = firestore;

  void setActiveUser(UserModel user) {
    _ref.watch(userProvider.notifier).state = Option.of(user);
  }

  @override
  Future<BackendResult<void>> create(UserModel userModel) async {
    try {
      _logger.d("Attempting to create document with data: $userModel");
      final usernameRef =
          _database.collection('usernames').doc(userModel.usernameValue);
      await usernameRef.set({"id": userModel.id.value});
      final doc = _database.referenceDocument(userModel.id);
      await doc.set(userModel);
      setActiveUser(userModel);
      _logger.d("User created succesfully.");
      return right(null);
    } on FirebaseException catch (e) {
      _logger.e(e.code);
      return left(DatabaseError.mapCode(e.code));
    } catch (e) {
      _logger.e(e.toString());
      return left(DatabaseError.unknown);
    }
  }

  @override
  Future<BackendResult<UserModel>> read(Identifier id) async {
    try {
      _logger.d("Reading user document with id: $id");
      final json = await _database.referenceDocument(id).get();
      _logger.d("Found user data: ${json.data()}");
      return right(json.data()!);
    } on FirebaseException catch (e) {
      _logger.e(e.message);
      return left(DatabaseError.mapCode(e.code));
    } catch (e) {
      _logger.e(e.toString());
      return left(DatabaseError.unknown);
    }
  }

  @override
  Future<BackendResult<void>> update(UserModel model) async {
    try {
      _logger.d("Setting user document with data: $model");
      final json = _database.referenceDocument(model.id);
      await json.set(model);
      _logger.d("Set new user document successfully");
      setActiveUser(model);
      return right(null);
    } on FirebaseException catch (e) {
      _logger.e(e.message);
      return left(DatabaseError.mapCode(e.code));
    } catch (e) {
      _logger.e(e.toString());
      return left(DatabaseError.unknown);
    }
  }

  /// Deletes the user document with the given [Identifier].
  ///
  /// Throws a [DatabaseError] if the operation fails.
  ///
  /// Returns a [BackendResult] with a `null` value if the operation is successful.
  @override
  Future<BackendResult<void>> delete(Identifier id) async {
    try {
      _logger.d("Deleting user document with id: $id");
      await _database.referenceDocument(id).delete();
      _logger.d("User document deleted successfully.");
      return right(null);
    } on FirebaseException catch (e) {
      _logger.e(e.message);
      return left(DatabaseError.mapCode(e.code));
    } catch (e) {
      _logger.e(e.toString());
      return left(DatabaseError.unknown);
    }
  }

  Future<void> updateUserAvatarUrl(String userId, String avatarUrl) async {
    try {
      _logger.d("Updating user avatarUrl with id: $userId");
      final userRef = _database.collection('users').doc(userId);
      await userRef.update({'avatarUrl': avatarUrl});
      _logger.d("User avatarUrl updated successfully.");
    } on FirebaseException catch (e) {
      _logger.e("Failed to update user avatarUrl: ${e.message}");
      throw Exception("Failed to update user avatarUrl");
    }
  }

  CollectionReference get _rawUsersCollection => _database.collection(
        DatabaseCollections.usersCollectionID,
      );

  CollectionReference<Option<UserModel>> getUsersCollection() {
    return _rawUsersCollection.withConverter<Option<UserModel>>(
      fromFirestore: (snapshot, options) {
        if (snapshot.data() == null) {
          return const Option.none();
        } else {
          return Option.of(UserModel.fromJson(snapshot.data()!));
        }
      },
      toFirestore: (value, options) {
        return value.match(
          () => throw "Data does not exists",
          (model) => model.toJson(),
        );
      },
    );
  }
}

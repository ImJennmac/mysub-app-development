import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fpdart/fpdart.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:logger/logger.dart';
import 'package:mysub/common/exceptions/backend_errors.dart';
import 'package:mysub/common/exceptions/backend_exception_mapping.dart';
import 'package:mysub/common/identifier.dart';
import 'package:mysub/common/models/signup_request.dart';
import 'package:mysub/common/models/user_model.dart';
import 'package:mysub/common/providers.dart';
import 'package:mysub/common/util/extensions.dart';
import 'package:mysub/common/util/logger/logger.dart';
import 'package:mysub/common/util/types.dart';
import 'package:mysub/common/value/email_address_value.dart';
import 'package:mysub/common/value/password_value.dart';
import 'package:mysub/repositories/impl/user_repository.dart';
import 'package:mysub/repositories/interface/auth_repository_facade.dart';
import 'package:mysub/repositories/interface/user_repository_facade.dart';

final authStateChangesProvider = StreamProvider((ref) {
  return ref.watch(authRepositoryProvider).authStateChanges();
});

final authRepositoryProvider = Provider((ref) {
  return AuthRepositoryImpl(
    auth: ref.watch(authProvider),
    database: ref.watch(databaseProvider),
    repository: ref.watch(userRepositoryProvider),
    logger: MySubLogger.getLogger((AuthRepositoryImpl).toString()),
  );
});

class AuthRepositoryImpl implements IAuthRepositoryFacade {
  final FirebaseAuth _auth;
  final FirebaseFirestore _database;
  final IUserRepositoryFacade _userInterface;
  final Logger _logger;

  const AuthRepositoryImpl({
    required FirebaseAuth auth,
    required FirebaseFirestore database,
    required IUserRepositoryFacade repository,
    required Logger logger,
  })  : _auth = auth,
        _database = database,
        _userInterface = repository,
        _logger = logger;

  @override
  Future<BackendResult<void>> register(SignUpRequest request) async {
    try {
      _logger.d("Registering user with email ${request.email}...");
      final email = request.email;
      final password = request.password;

      final usernameExist = await _database
          .collection("usernames")
          .doc(request.username.value)
          .get();

      if (usernameExist.exists) {
        return left(AuthError.usernameAlreadyInUse);
      }

      final credentials = await _auth.createUserWithEmailAndPassword(
        email: email.value,
        password: password.value,
      );
      final firebaseUser = credentials.user;
      if (firebaseUser == null) {
        return left(AuthError.unknown);
      }
      // Create new user record in the database
      final Identifier id = firebaseUser.toIdentifier();
      final UserModel model = UserModel(
        id: id,
        username: request.username,
        fullName: request.fullName,
        position: request.position,
        birthDay: request.birthday,
      );
      final result = await createUserRecord(model);
      if (result.isRight()) {
        _logger.d("The user was successfully registered!");
      }
      return result;
    } on FirebaseException catch (e) {
      _logger.d("Thrown exception with code[${e.code}]");
      return left(AuthError.mapCode(e.code));
    } catch (e) {
      _logger.d("Thrown exception [$e]");
      return left(AuthError.unknown);
    }
  }

  @override
  Future<BackendResult<User>> signIn({
    required EmailAddressValue email,
    required PasswordValue password,
  }) async {
    try {
      _logger.d("Signing in user with email ${email.value}...");
      final credentials = await _auth.signInWithEmailAndPassword(
        email: email.value,
        password: password.value,
      );

      final user = credentials.user;
      if (user == null) {
        return left(AuthError.unknown);
      }
      return right(user);
    } on FirebaseException catch (e) {
      return left(AuthError.mapCode(e.code));
    } catch (e) {
      return left(AuthError.unknown);
    }
  }

  @override
  Future<BackendResult<void>> signOut() async {
    try {
      _logger.d("Signing out current user...");
      await _auth.signOut();
      _logger.d("User was signed out successfully");
      return right(null);
    } on FirebaseException catch (e) {
      logException(e);
      return left(AuthError.mapCode(e.code));
    } catch (e) {
      _logger.e(e.toString());
      return left(AuthError.unknown);
    }
  }

  FutureResult<void> sendPasswordResetEmail({
    required String email,
  }) async {
    try {
      _logger.d("Sending password reset email...");
      await _auth.sendPasswordResetEmail(email: email);
      _logger.d("Password reset email was sent!");
      return right(null);
    } on FirebaseException catch (e) {
      logException(e);
      return left(e.message!);
    } catch (e) {
      _logger.e(e.toString());
      return left(e.toString());
    }
  }

  FutureResult<void> sendUserVerificationEmail() async {
    final user = currentUser;
    return user.match(
      () => right(null),
      (userAccount) async {
        if (userAccount.emailVerified) {
          return right(null);
        }
        try {
          _logger.d("Sending email verification...");
          await userAccount.sendEmailVerification();
          _logger.d("Email verification was sent!");
        } on FirebaseAuthException catch (e) {
          logException(e);
          _logger.e(e.toString());
          return left(e.message!);
        } catch (e) {
          _logger.e(e.toString());
          return left(e.toString());
        }

        return right(null);
      },
    );
  }

  @override
  Option<User> get currentUser => Option.fromNullable(_auth.currentUser);

  Option<Identifier> get currentUserId {
    return currentUser.map((user) => user.toIdentifier());
  }

  Option<String> get currentUserEmail {
    return currentUser.map((user) => user.email!);
  }

  Stream<Option<User>> authStateChanges() {
    return _auth.authStateChanges().map((user) {
      return Option.fromNullable(user);
    });
  }

  void logException(FirebaseException e) {
    _logger.d("Thrown exception with code[${e.code}]");
  }

  Future<BackendResult<void>> createUserRecord(UserModel user) async {
    final result = await _userInterface.create(user);
    return result;
  }

  @override
  Future<BackendResult<void>> updatePasword({
    required PasswordValue oldPassword,
    required PasswordValue newPassword,
  }) async {
    final optionalUser = currentUser;
    final user = optionalUser.getOrElse(() => throw NotAuthenticatedError());
    final AuthCredential cred = EmailAuthProvider.credential(
      email: user.email!,
      password: oldPassword.value,
    );
    try {
      await user.reauthenticateWithCredential(cred);
      await user.updatePassword(newPassword.value);
      return right(null);
    } on FirebaseException catch (e) {
      logException(e);
      return left(AuthError.mapCode(e.code));
    } catch (e) {
      return left(AuthError.unknown);
    }
  }

  @override
  Future<BackendResult<bool>> validatePassword(PasswordValue password) async {
    final user = currentUser;
    return user.match(
      () => left(AuthError.unauthenticated),
      (user) async {
        final creds = EmailAuthProvider.credential(
          email: user.email!,
          password: password.value,
        );
        try {
          final authResult = await user.reauthenticateWithCredential(creds);
          return right(authResult.user != null);
        } catch (e) {
          return right(false);
        }
      },
    );
  }

  @override
  Future<BackendResult<void>> deleteAccount() async {
    final maybeUser = currentUser;
    if (!maybeUser.isSome()) {
      return left(AuthError.unauthenticated);
    }
    final user = currentUser.unwrap();
    try {
      await user.delete(); // Delete the user from Firebase Auth
      // Delete all the data associated with the user
      final deleted = await _userInterface.delete(user.toIdentifier());
      return deleted;
    } on FirebaseException catch (e) {
      logException(e);
      return left(AuthError.mapCode(e.code));
    } catch (e) {
      return left(AuthError.unknown);
    }
  }

  @override
  Future<BackendResult<void>> updateEmail(
    EmailAddressValue newEmail,
    PasswordValue password,
  ) async {
    final optionUser = currentUser;
    if (optionUser.isNone()) {
      return left(AuthError.unauthenticated);
    }
    try {
      _logger.i("Attempting to update email to ${newEmail.value}...");
      final user = optionUser.unwrap();

      if (user.email == newEmail.value) {
        _logger.e("The new email is the same as the current one.");
        return right(null);
      }

      final creds = EmailAuthProvider.credential(
        email: user.email!,
        password: password.value,
      );
      await user.reauthenticateWithCredential(creds);
      _logger.i("User was re-authenticated successfully");
      await user.verifyBeforeUpdateEmail(newEmail.value);
      _logger.i("Email was updated successfully!");

      return right(null);
    } on FirebaseException catch (e) {
      logException(e);
      return left(AuthError.mapCode(e.code));
    } catch (e) {
      _logger.e(e.toString());
      return left(AuthError.unknown);
    }
  }
}

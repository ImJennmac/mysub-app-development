import 'package:firebase_auth/firebase_auth.dart';
import 'package:fpdart/fpdart.dart';
import 'package:mysub/common/exceptions/backend_exception_mapping.dart';
import 'package:mysub/common/models/signup_request.dart';
import 'package:mysub/common/util/types.dart';
import 'package:mysub/common/value/email_address_value.dart';
import 'package:mysub/common/value/password_value.dart';
import 'package:mysub/repositories/impl/auth_repository.dart';

/// Represents an abstract AuthenticationRepository.
/// See the implementation for the details: [AuthRepositoryImpl]
abstract class IAuthRepositoryFacade {
  const IAuthRepositoryFacade();

  /// This function will attempt to register a new user if
  /// the [SignUpRequest] containts valid data.
  ///
  /// In case of any error, the Left instance will return a [BackendError].
  /// Otherwise a [VoidCallback] is executed, as a success handler.
  Future<BackendResult<void>> register(SignUpRequest request);

  /// This function will atempt to sign in the user with the given
  /// [EmailAddressValue] and [PasswordValue]. If any error occurs the
  /// a [BackendError] will be returned. Otherwise the a Right instance
  /// with A [VoidCallback] will be returned.
  Future<BackendResult<User>> signIn({
    required EmailAddressValue email,
    required PasswordValue password,
  });

  /// Updates the password of the active user.
  /// [BackendError] may be returned.
  Future<BackendResult<void>> updatePasword({
    required PasswordValue oldPassword,
    required PasswordValue newPassword,
  });

  /// Updates the email of the active user.
  /// [BackendError] may be returned.
  Future<BackendResult<void>> updateEmail(
    EmailAddressValue newEmail,
    PasswordValue password,
  );

  /// Signs out the active user.
  /// [BackendError] may be returned.
  Future<BackendResult<void>> signOut();

  /// Validates that the given password belongs to the current logged in user.
  /// [BackendError] may be returned.
  Future<BackendResult<bool>> validatePassword(PasswordValue password);

  /// Deletes the account of the current logged in user.
  Future<BackendResult<void>> deleteAccount();

  Option<User> get currentUser;
}

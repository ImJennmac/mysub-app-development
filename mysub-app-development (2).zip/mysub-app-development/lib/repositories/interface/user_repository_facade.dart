import 'package:mysub/common/identifier.dart';
import 'package:mysub/common/models/user_model.dart';
import 'package:mysub/common/util/types.dart';

/// A repository for dealing with user data.
abstract class IUserRepositoryFacade {
  const IUserRepositoryFacade();

  /// Creates a new user record
  Future<BackendResult<void>> create(UserModel userModel);

  /// Requests the data of the document with the given [Identifier].
  Future<BackendResult<UserModel>> read(Identifier id);

  /// Updates the data of the user using the [UserModel.id].
  Future<BackendResult<void>> update(UserModel userModel);

  /// Deletes the user document with the given [Identifier].
  Future<BackendResult<void>> delete(Identifier id);
}

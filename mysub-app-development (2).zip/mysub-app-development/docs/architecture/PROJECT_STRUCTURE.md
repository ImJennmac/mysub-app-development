MySub Project Structure
What is a "feature"?

A feature is a functional requirement of the project that helps the user to complete a given task.
Feature-first based project structure

The feature-first project structure approach allows us to structure the project around the functional requirements of it.

Here is an example:

- lib/
    - src/
        - misc/
        - models/
        - features
            - auth
            - orders
            - reviews
            - sell

This project structure demands that we create a new folder for each feature of the app. And inside that folder we have the layers of communication as shown below:

	- auth/
		- views/
		- controllers/
		- repositories/
	- feature1/
		- views/
		- controllers/
		- services/
	- featureN/
		- views/
		- controllers/
		- services/
		- repositories/
		- models/ --> models used only within this feature

Advantages of this approach:

    Whenever we are working on X feature, we can just focus on a single folder
    If we need to delete a feature, there's only one folder to remove.
    Everything is organized based on the functional requirements of the system.
    Scales very well for large projects

Disadvantages:

    You may be tempted to create a folder for a screen instead of the feature.

Here is an explanation of our project structure:

- src/
    - lib/


# MySub Mobile Architecture

This document is intented to be a brief overview of the layer-based architecture used
by the MySub mobile app.

## What is software architecture?

Software architecture is the logical way we organize our projects and how the various components communicate with each other to fulfill the business requirements.

## Layers

Now that we have an idea about what is an architecture let's define layers.

A layer is a component of the architecture. Each of these is assigned to
a specific responsibility and isolated to achieve a mantainable codebase.

The MySub mobile architecture at the core have 2 main layers:

<b> - UI Layer:</b> This layer is the actual presentation of the app and triggers the
events that modify the application state.

<b> - Communication Layer:</b> This layer is where all the logic behind the events are
processed and communicate to the UI layer about the updated state. It is composed of
various entities, each of them isolated with a single responsibility:

![](/docs/diagrams/architecture.png)

- <b> Controller </b>: This kind of controller is the same as you would use in the <b> MVVM </b>
  pattern if you've worked with it. They are meant to be used to manage the state of the View,
  hold widget-related business logic and communicate with the service and repository layers.
- <b> Model </b>: A model is the definition of the data to be presented on the <b> View</b>.
  It is meant to be immutable in all cases.
- <b> Service </b>: This component is optional. There are cases where you may find yourself writing logic
  that depends on multiple repositories and needs to be shared across multiple views, and that is where a service
  comes into play. Unlike controllers that typically extend `StateNotifier`, services don't need to manage any state,
  as they hold logic that is not widget/view-specific.
- <b> Repository </b>: The repository component its used to isolate the various REST APIs, local or remote databases and
  device specific APIs from the rest of the app. The best advatange of this is that we'll have to deal with one place when
  breaking-changes come.

Here is an example of all the components in action:

Let's start by defining the repository that will allow us to access our device storage.

```dart
enum StorageFormat {
    GB, MB, KB,
}
class StorageRepository {
    // Raw storage calls
    final InternalStorageAPI api;
    StorageRepository({
        required this.api,
    });

    Future<Option<StorageSpace>> getAvailableSpaceIn(format: StorageFormat) {
        // TODO: send request, parse it, return storage space object.
        // Note: the Option comes from the fpdart package.
    }
}
```

We also need a definition for our storage space

```dart
@immutable
class StorageSpace {
    // declare all properties that define your storage space
    final Partition partition;
    final RawSpace rawSpace;

    const StorageSpace({
        required this.partition,
        required this.rawSpace,
    });

    factory StorageSpace.fromJson(Map<String, dynamic> json) {
        // TODO: parse JSON and return a valid StorageSpace.
    }
}
```

Note that the model is <b> immutable</b> meaning we are not allow to change its state.

Now we need a way to access the repository on the view, but we don't want to create a new instance
of our internal apis every time we want to access them as it would be very time consuming. For this, among
many other reasons, we use the <b> provider </b> package.

```dart
final storageRepositoryProvider = Provider((ref) {
    // TODO: pass in the instance of the storage API.
    return StorageRepository();
})
@immutable
class StorageRepository {
    //...
}
```

Now we are ready to use this repository via controllers.

```dart
final storageControllerProvider = Provider((ref) {
    // TODO: pass in parameters
    return StorageViewController();
})
class StorageViewController {
    final StorageRepository repository;

    StorageSpace getSpace(BuildContext ctx) async {
        final response = await repository.getAvailableSpaceIn(StorageFormat.MB);
        return response.match(
            () => notifyError(ctx), // or whatever you want to do in case of empty value
            (space) => space,
        );
    }
}
```

```dart
class StorageView extends ConsumerWidget {

    Widget build(BuildContext context, WidgetRef ref) {
        // deep in the widget tree..
        StorageButton(
            onPressed: () {
                ref.read(storageControllerProvider).getSpace(ctx);
            }
        )
    }
}
```

As usual, keeping things simple is always a good idea. So don't get too wound up overthinking the APIs.

## Test Directory Structure

We have the same folder structure as `lib/` in the test folder. That way tests are much easier to track.

Here is an example:

```
    lib/features/auth/views/login_view.dart
    tests/features/auth/views/login_view_test.dart
```

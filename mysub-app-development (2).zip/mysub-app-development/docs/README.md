# MySub — The MySub Mobile App

## General Information

MySub is a BDSM habit tracker for long-distance couples & sex workers alike. Built to allow people to track their sex lives as well as allowing sex workers to keep their identities hidden but offer a new service.

The official website:

- https://mysub.beenhamow.xyz/ (Just temporary while under development)

## Building and installing

in order to build MySub you will need:

- Android SDK bundled with [Android Studio](https://developer.android.com/studio)
- The Dart Compiler bundled with the [Flutter SDK](https://docs.flutter.dev/get-started/install)

## Cloning From Github

To clone the repository, either can either use a git GUI if you have one installed or enter the following commands:

```bash
git clone https://github.com/notsuitablegroup/mysub-app.git
cd MySub-App
```

Once you have all the required dependencies, you can build MySub by using
the Flutter cli tool:

```bash
flutter pub get
flutter run
```

To get started, I recommend you to look at the [Coding Style](CODING-STYLE.md) and [Coding Practices](CODING-PRACTICES.md) documents.

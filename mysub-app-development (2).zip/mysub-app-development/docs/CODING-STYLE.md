# MySub Coding Style

This document is intended to be a short description of the preferred coding style to be used for the MySub source code. It was strongly inspired by Flutter's Community coding style but with some changes.

Coding style is a matter of consistency, readability and maintenance. This document will use examples at the very least to provide authoritative and consistent answers to common questions regarding the coding style, and will also try to identify the allowed exceptions.

## Line Width

The maximum length of a line of code is 100 characters, which is used by the document formatter. Longer lines are usually an indication that you need a function.

## Indentation

Indentation refers to the number of spaces at the beginning of a code line.\
Each code block is indented 2 spaces more than the previous level:

```dart
  foo() {
    if (condition) {
      bar();
    }
  }
```

## Braces

Curly braces should always be put, starting on the same level of the statement:

```dart
  if (!condition) {
    foo();
  } else {
    bar();
  }
```

There only exception to this is when we have a single if statement block:

```dart
if (!condition) statement();
```

## Conditions

Do NOT check boolean values for equality:

```dart
  if (condition == true) foo();
```

In case of conditions split over multiple lines, the logical operators should always go at the end of the line:

```dart
  // BAD
  if (condition
      && condition2
      || condition3) {

      }
  // GOOD
  if (condition &&
      condition2 ||
      condition3) {

      }
```

## Functions

Functions should be declared by placing the returned value, name, parentheses and starting brace on the same line:

```dart
void myFunction() {

}
```

If it has more than 2 parameters, named parameters should be used instead:

```dart
// GOOD
void myFunction(int x) {

}
// GOOD
void myFunction(int x, int y) {

}
// BAD
void myFunction(int x, int y, int z) {

}
// GOOD
void myFunction({
  int x,
  int y,
  int z
}) {

}
```

When calling a function with named parameters, use trailing comma

```dart
  // GOOD
  myFuction(
    x: 0,
    y: 0,
    z: 0,
  );
  // BAD
  myFunction(x: 0, y: 0, z: 0);
```

## Whitespace

- Never use empty lines at the beginning or at the end of a file.\
  Always put a space before a parenthesis but never after:

```dart
  // GOOD
  if (condition) foo();
  // BAD
  switch (condition) {
     {

     }
  }
  // BAD
  if ( condition ) {

  }
  // BAD
  if (condition) {
    foo ();
  }
```

When declaring a class type use newlines to separate logical sections of the object:

```dart
  class Window {
    Orientation orientation;

    int width;
    int height;

    String name;

    List<Widget> widgets;
  }
```

Do not eliminate whitespace and newlines just because something would fit on 100 characters:

```dart
  // BAD
  for (condition) foo[i] = bar; update();

  // GOOD
  for (condition) {
    foo[i] = bar;
    update();
  }
```

## Naming

### Variable Names

Variable names are written in "lowerCamelCase" and they should have a meaningful name:

```dart
  // BAD:
  int x = 0;
  while (x != 100) {

  }
  // GOOD:
  int signInCounter = 0;
  if (signInCounter != 100) {

  }
```

The only exception to this is with a for loop, since "i" It's pretty much used everywhere
meaning index:

```dart
  const N = 20; // BAD
  const DEFAULT_NUMBER = 20 // GOOD
  // GOOD:
  for (int i = 0; i < DEFAULT_NUMBER; i++) {

  }
  // BAD:
  for (int r = 0; r < 3; r++) {
    for (int c = 0; c < 3; c++) {

    }
  }
  // GOOD:
  for (int row = 0; row < 3; row++) {
    for (int column = 0; column < 3; column++) {

    }
  }
```

### Class Names

Class names are written in "UpperCamelCase" and they are typically nouns or noun phrases.
Example:

```dart
  class User {}
  class Identifier {}
```

A view class has a name that ends with View.\
A view model class ends with ViewModel
Example:

```dart
  class WelcomeView {};
  class LoginViewModel {};
```

### Function/Method Names

Function Names are written in "lowerCamelCase".\
They are typically verbs or verb phrases:

```dart
  stop();
  sendMessage();
```

### Declare static global and/or constant variable names with "SCREAMING_SNAKE_CASE"

Examples:

```dart
  const double DEFAULT_SPACING = 3.0;
```

However, where possible avoid global constants.

### Avoid anonymous parameters names

Provide full type information and names even for parameters that are otherwise unused. This makes it easier for people reading the code to tell what is actually going on (e.g. what is being ignored). For example:

```dart
  statement(onUpdate: _); // BAD
  statement(onUpdate: name); // BAD
  statement(onUpdate: String name); // GOOD
```

## Double Quotes for Strings

Always use double quotes for strings:

```dart
print("Welcome ${user}!");
```

## Use double literals for double constants

To make it clearer when something is a double or an integer, even if the number is a round number, include a decimal point in double literals. For example, if a function foo takes a double, write `foo(1.0)` rather than ` foo(1)` because the latter makes it look like the function takes an integer.

## Constructor Syntax

This is how you would declare a constructor:

```dart
// One-line Constructor
class Foo extends Bar {
  final int number;
  const Foo(this.number, {Property property}) : super(property: property);
  // ...

  // Fully Expanded Constructor
  const Foo(
    this.number, {
      Property property
    }
  ) : super(
    property: property
  )
}
```

Always declare fields before the constructor.

## Comments and Documentation

If commenting on a workaround due to a bug, also leave a link to the issue and a TODO to clean it up when the bug is fixed.

```dart
  // BAD:
  void process() {
    // fails if value is not between 0 and 1
    draw(1.0) // this is a workaround;
  }

  // GOOD:
  void process() {
    // According to this specification, this should be 0, but according to that
    // specification, it should be 1.0. We split the difference and went with
    // 0.5, because we didn't know what else to do.

    // TODO(username): Converting color to RGB because class Color doesn't support
    //                 hex yet. See http://link/to/a/bug/123
    draw(0.5);
  }
```

TODOs should include the string TODO in all caps, followed by the GitHub username of the person with the best context about the problem referenced by the TODO in parenthesis.
Including an issue link in a TODO description is required.

All APIs must have doc comments. For functions, these should be placed in the source file, directly above the function.

```dart

  /// Displays a Material dialog above the current contents of the app, with
  /// Material entrance and exit animations, modal barrier color, and modal
  /// barrier behavior (dialog is dismissible with a tap on the barrier).
  void showDialog() {

  }
```

## About old code

New code that is being added to MySub should adhere to the style explained above. Existing MySub code does largely follow these conventions, but there are some differences, e.g. occurrences of tabs, etc.

It is ok to update the style of a code block or function when you are touching it anyway, but sweeping whitespace changes obscure the source revision history, and should be avoided.

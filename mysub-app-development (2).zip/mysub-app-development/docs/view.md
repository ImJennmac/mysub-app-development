# View (UI)

A view is a collection of visible elements.  
This includes the UI, animations and text.


## Steps to create a view

1. Create the a new file on lib/ui/view with the _view suffix.
2. Create a Stateless Widget with the View suffix.
3. Declare a static variable called ***id*** at the top level.
4. Return a new ViewBuilder instance from the build method.
5. Annotate the it with your model type. 
6. Make sure you trigger the model #onInitialize() and #remove() functions from the builder.
7. Register the view on lib/router.
8. Build your widget tree using the *builder* function.


# ViewModel (LOGIC)

Object that retrieves data from Model and exposes it to the View.

## Steps to create a ViewModel
1. Create a file on lib/ui/viewmodel with the _viewmodel suffix
2. Create a class extending ViewModelBase with the ViewModel suffix.
3. Declare an init() and remove() functions.
4. Make sure they get triggered from the ViewBuilder
5. Register the ViewModel factory on lib/locator.
6. Start building your view state.

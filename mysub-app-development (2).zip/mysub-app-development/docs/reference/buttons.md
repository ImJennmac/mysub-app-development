# Primary and Secondary Buttons

## Primary Button

It's used for primary actions, or things that we want the user to do as often as possible.\
Buttons that execute primary actions—primary buttons—should be as visible as possible.


## Secondary Button

Some actions that are available to the user are counterproductive, like canceling, skipping, resetting, declining an offer, and so on. They remove or stop the creation of new things. Those are secondary actions, or things we don’t want the user to do, but we provide the option for the sake of usability.

Therefore, buttons that execute secondary options—secondary ...
